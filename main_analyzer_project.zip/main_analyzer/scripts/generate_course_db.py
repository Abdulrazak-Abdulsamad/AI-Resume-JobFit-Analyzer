#!/usr/bin/env python3
"""Generate data/course_db.json from the existing COURSE_CATALOG with RAG metadata."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from course_recommender.course_catalog import COURSE_CATALOG  # noqa: E402

SKILL_TO_ROLES = {
    "Python": ["Software Engineer", "Data Scientist", "Machine Learning Engineer", "Backend Engineer", "Data Engineer"],
    "Java": ["Software Engineer", "Backend Engineer"],
    "JavaScript": ["Frontend Developer", "Full Stack Developer", "Software Engineer"],
    "TypeScript": ["Frontend Developer", "Full Stack Developer"],
    "SQL": ["Data Engineer", "Data Scientist", "Backend Engineer", "Database Administrator"],
    "PostgreSQL": ["Backend Engineer", "Database Administrator"],
    "MongoDB": ["Backend Engineer", "Full Stack Developer"],
    "Pandas": ["Data Scientist", "Data Engineer"],
    "NumPy": ["Data Scientist", "Data Engineer", "Machine Learning Engineer"],
    "Scikit-Learn": ["Data Scientist", "Machine Learning Engineer"],
    "Machine Learning": ["Machine Learning Engineer", "Data Scientist", "AI Engineer"],
    "TensorFlow": ["Machine Learning Engineer", "AI Engineer"],
    "PyTorch": ["Machine Learning Engineer", "AI Engineer"],
    "Natural Language Processing": ["AI Engineer", "Data Scientist", "Machine Learning Engineer"],
    "Computer Vision": ["AI Engineer", "Machine Learning Engineer"],
    "Docker": ["DevOps Engineer", "Backend Engineer", "Site Reliability Engineer"],
    "Kubernetes": ["DevOps Engineer", "Site Reliability Engineer", "Cloud Architect"],
    "CI/CD": ["DevOps Engineer", "Site Reliability Engineer"],
    "GitHub Actions": ["DevOps Engineer", "Site Reliability Engineer"],
    "Jenkins": ["DevOps Engineer", "Site Reliability Engineer"],
    "Linux": ["DevOps Engineer", "Site Reliability Engineer", "Cloud Architect"],
    "Git": ["Software Engineer", "DevOps Engineer", "Full Stack Developer"],
    "AWS": ["Cloud Architect", "DevOps Engineer", "Site Reliability Engineer"],
    "Azure": ["Cloud Architect", "DevOps Engineer"],
    "GCP": ["Cloud Architect", "DevOps Engineer"],
    "Terraform": ["DevOps Engineer", "Cloud Architect"],
    "React": ["Frontend Developer", "Full Stack Developer"],
    "Vue.js": ["Frontend Developer", "Full Stack Developer"],
    "Node.js": ["Backend Engineer", "Full Stack Developer"],
    "HTML5": ["Frontend Developer", "Full Stack Developer"],
    "CSS3": ["Frontend Developer", "Full Stack Developer", "UI/UX Designer"],
    "FastAPI": ["Backend Engineer", "Full Stack Developer", "Machine Learning Engineer"],
    "System Design": ["Software Engineer", "Backend Engineer", "Cloud Architect"],
    "Tableau": ["Data Scientist", "Data Analyst"],
    "PowerBI": ["Data Scientist", "Data Analyst"],
    "Data Analysis": ["Data Scientist", "Data Analyst", "Data Engineer"],
    "Agile": ["Project Manager", "Product Manager", "Software Engineer"],
    "Scrum": ["Project Manager", "Product Manager"],
    "Network Security": ["Cybersecurity Analyst", "Penetration Tester", "Information Security Manager"],
    "Penetration Testing": ["Penetration Tester", "Cybersecurity Analyst"],
    "Figma": ["UI/UX Designer", "Frontend Developer", "Product Designer"],
}

SKILL_TO_SECTORS = {
    "Python": ["Information Technology"],
    "Java": ["Information Technology"],
    "JavaScript": ["Information Technology"],
    "TypeScript": ["Information Technology"],
    "SQL": ["Information Technology", "Business & Finance"],
    "PostgreSQL": ["Information Technology"],
    "MongoDB": ["Information Technology"],
    "Pandas": ["Information Technology", "Business & Finance"],
    "NumPy": ["Information Technology", "Business & Finance"],
    "Scikit-Learn": ["Information Technology"],
    "Machine Learning": ["Information Technology"],
    "TensorFlow": ["Information Technology"],
    "PyTorch": ["Information Technology"],
    "Natural Language Processing": ["Information Technology"],
    "Computer Vision": ["Information Technology"],
    "Docker": ["Information Technology"],
    "Kubernetes": ["Information Technology"],
    "CI/CD": ["Information Technology"],
    "GitHub Actions": ["Information Technology"],
    "Jenkins": ["Information Technology"],
    "Linux": ["Information Technology"],
    "Git": ["Information Technology"],
    "AWS": ["Information Technology"],
    "Azure": ["Information Technology"],
    "GCP": ["Information Technology"],
    "Terraform": ["Information Technology"],
    "React": ["Information Technology"],
    "Vue.js": ["Information Technology"],
    "Node.js": ["Information Technology"],
    "HTML5": ["Information Technology"],
    "CSS3": ["Information Technology"],
    "FastAPI": ["Information Technology"],
    "System Design": ["Information Technology"],
    "Tableau": ["Information Technology", "Business & Finance"],
    "PowerBI": ["Information Technology", "Business & Finance"],
    "Data Analysis": ["Information Technology", "Business & Finance"],
    "Agile": ["Information Technology", "Business & Finance"],
    "Scrum": ["Information Technology", "Business & Finance"],
    "Network Security": ["Information Technology"],
    "Penetration Testing": ["Information Technology"],
    "Figma": ["Information Technology", "Marketing & Sales"],
}

DESCRIPTIONS = {
    "Python": "Master Python programming from basics to advanced applications in software development, data science, and machine learning.",
    "Java": "Learn Java programming fundamentals and software engineering principles for building robust applications.",
    "JavaScript": "Build interactive web applications with JavaScript, from DOM manipulation to modern ES6+ features.",
    "TypeScript": "Add type safety to JavaScript with TypeScript for scalable, maintainable frontend and backend applications.",
    "SQL": "Query and manage relational databases with SQL, essential for data analysis and backend development.",
    "PostgreSQL": "Master PostgreSQL database administration, optimization, and advanced querying techniques.",
    "MongoDB": "Learn MongoDB NoSQL database design, CRUD operations, and aggregation pipelines for modern applications.",
    "Pandas": "Manipulate and analyze structured data efficiently with Pandas, the core Python data analysis library.",
    "NumPy": "Perform numerical computing in Python with NumPy arrays, linear algebra, and mathematical operations.",
    "Scikit-Learn": "Implement machine learning algorithms with scikit-learn for classification, regression, and clustering tasks.",
    "Machine Learning": "Understand core machine learning concepts, algorithms, and practical applications across industries.",
    "TensorFlow": "Build and deploy deep learning models with TensorFlow for computer vision, NLP, and production systems.",
    "PyTorch": "Develop neural networks and deep learning systems with PyTorch, favored by researchers and practitioners.",
    "Natural Language Processing": "Process and analyze text data with NLP techniques including transformers, sentiment analysis, and chatbots.",
    "Computer Vision": "Enable machines to interpret visual data using CNNs, object detection, and image segmentation models.",
    "Docker": "Containerize applications with Docker for consistent development, testing, and deployment environments.",
    "Kubernetes": "Orchestrate containerized applications at scale with Kubernetes for production-grade deployments.",
    "CI/CD": "Implement continuous integration and deployment pipelines to automate testing, building, and releasing software.",
    "GitHub Actions": "Automate workflows, CI/CD, and DevOps tasks using GitHub Actions integrated with your repository.",
    "Jenkins": "Set up Jenkins for continuous integration, automating builds, tests, and deployments in enterprise environments.",
    "Linux": "Master Linux system administration, shell scripting, and command-line tools for server and cloud environments.",
    "Git": "Track code changes, collaborate with teams, and manage versions using Git and GitHub workflows.",
    "AWS": "Design and deploy scalable cloud solutions on AWS, covering compute, storage, networking, and security.",
    "Azure": "Build cloud solutions on Microsoft Azure with focus on infrastructure, data services, and identity management.",
    "GCP": "Leverage Google Cloud Platform for data analytics, machine learning, and scalable application hosting.",
    "Terraform": "Infrastructure as Code with Terraform for provisioning and managing cloud resources across providers.",
    "React": "Build modern, component-based user interfaces with React, including hooks, state management, and performance optimization.",
    "Vue.js": "Create reactive web applications with Vue.js using its approachable component model and ecosystem.",
    "Node.js": "Develop server-side JavaScript applications with Node.js, Express, and modern backend patterns.",
    "HTML5": "Structure web content with semantic HTML5 elements, forms, and accessibility best practices.",
    "CSS3": "Style responsive web layouts with CSS3 including Flexbox, Grid, animations, and responsive design principles.",
    "FastAPI": "Build high-performance Python APIs with FastAPI, async support, automatic docs, and type validation.",
    "System Design": "Learn to design scalable, reliable systems including APIs, databases, caching, and distributed architectures.",
    "Tableau": "Create interactive data visualizations and dashboards with Tableau for business intelligence and analytics.",
    "PowerBI": "Transform data into insights with Microsoft Power BI through reports, dashboards, and data modeling.",
    "Data Analysis": "Apply statistical methods and analytical thinking to extract actionable insights from raw data.",
    "Agile": "Adopt Agile methodologies to improve team collaboration, iterative delivery, and project adaptability.",
    "Scrum": "Implement Scrum frameworks with sprints, standups, and retrospectives to deliver value incrementally.",
    "Network Security": "Protect networks and systems from threats with firewalls, monitoring, and security best practices.",
    "Penetration Testing": "Identify and exploit security vulnerabilities ethically to strengthen organizational defenses.",
    "Figma": "Design user interfaces and prototypes with Figma, collaborating across design and development teams.",
}

courses = []
course_id = 1

for skill, skill_courses in COURSE_CATALOG.items():
    roles = SKILL_TO_ROLES.get(skill, ["Software Engineer"])
    sectors = SKILL_TO_SECTORS.get(skill, ["Information Technology"])
    description = DESCRIPTIONS.get(skill, f"Learn {skill} through structured coursework and hands-on practice.")

    for course in skill_courses:
        title_lower = course["course_title"].lower()
        is_cert = (
            "professional certificate" in title_lower
            or "certificate" in title_lower
            or "certification" in title_lower
            or "certified" in title_lower
        )
        courses.append({
            "id": f"course_{course_id}",
            "title": course["course_title"],
            "provider": course["platform"],
            "skills_covered": [skill],
            "difficulty": course["difficulty"],
            "duration": course["estimated_duration"],
            "url": course["url"],
            "certificate": is_cert,
            "description": description,
            "target_roles": roles,
            "target_sectors": sectors,
        })
        course_id += 1

output_path = Path(__file__).resolve().parent.parent / "data" / "course_db.json"
with output_path.open("w", encoding="utf-8") as fh:
    json.dump(courses, fh, indent=2)

print(f"Generated {len(courses)} courses to {output_path}")
