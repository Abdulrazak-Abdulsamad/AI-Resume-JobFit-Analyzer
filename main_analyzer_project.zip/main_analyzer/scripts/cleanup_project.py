#!/usr/bin/env python3
"""
cleanup_project.py

Removes generated, cached, and rebuildable artifacts from the project
to reduce its size for distribution.

Safe to run before zipping or committing the project. All removed items
can be restored by running setup commands documented in README.md.
"""
from __future__ import annotations

import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

SAFE_TO_REMOVE = [
    ROOT / ".pytest_cache",
    ROOT / ".venv",
    ROOT / "__pycache__",
    ROOT / "course_recommender" / "__pycache__",
    ROOT / "database" / "__pycache__",
    ROOT / "frontend" / "dist",
    ROOT / "frontend" / "node_modules",
    ROOT / "job_analyzer" / "__pycache__",
    ROOT / "rag" / "__pycache__",
    ROOT / "resume_parsing" / "__pycache__",
    ROOT / "services" / "__pycache__",
    ROOT / "tests" / "__pycache__",
    ROOT / "utils" / "__pycache__",
    ROOT / "data" / "vectordb",
]

SAFE_FILES = [
    ROOT / ".DS_Store",
    ROOT / "frontend" / ".DS_Store",
    ROOT / "frontend" / "node_modules" / ".DS_Store",
    ROOT / "frontend" / "src" / ".DS_Store",
    ROOT / ".venv" / ".DS_Store",
    ROOT / ".venv" / "lib" / ".DS_Store",
]


def remove_path(path: Path) -> None:
    if not path.exists():
        return
    if path.is_dir():
        shutil.rmtree(path)
        print(f"Removed directory: {path}")
    else:
        path.unlink()
        print(f"Removed file: {path}")


def main() -> None:
    print("Cleaning up generated/cached artifacts...")
    for path in SAFE_FILES + SAFE_TO_REMOVE:
        remove_path(path)
    print("Cleanup complete.")
    print("\nTo restore the project for development:")
    print("  1. python -m venv .venv")
    print("  2. source .venv/bin/activate  (or .venv\\Scripts\\activate on Windows)")
    print("  3. pip install -r requirements.txt")
    print("  4. cd frontend && npm install")
    print("  5. python build_vector_db.py")
    print("  6. python tests/test_pipeline_smoke.py")


if __name__ == "__main__":
    main()
