"""
json_repository.py

Generic base class for "load a JSON array from disk once, serve it from
memory forever" repositories. `JobRepository` and `CourseRepository` were
previously two independent, near-identical implementations of exactly this
pattern (load -> apply defaults -> log -> serve by id). This base class
holds that shared behavior in one place; the two concrete repositories only
need to describe *their* record's id field and default values.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Generic, List, TypeVar

from utils.logging_config import get_logger

logger = get_logger(__name__)

TRecord = TypeVar("TRecord", bound=Dict[str, Any])


class JsonRepository(Generic[TRecord]):
    """
    Loads and serves records from a single JSON array on disk.

    Subclasses configure the behavior by setting three class attributes:
      - `record_cls`: the dict-subclass to wrap each raw record in.
      - `id_field`: the field used as the record's unique identifier.
      - `id_prefix`: prefix used to synthesize an id when one is missing
        (e.g. "job" -> "job_1", "job_2", ...).
      - `defaults`: a dict of field -> default value applied via
        `setdefault` to every loaded record.
    """

    record_cls: type = dict
    id_field: str = "id"
    id_prefix: str = "record"
    defaults: Dict[str, Any] = {}

    def __init__(self, db_path: Path, kind: str) -> None:
        self.db_path = db_path
        self._kind = kind
        self._records: List[TRecord] = self._load()

    def _load(self) -> List[TRecord]:
        if not self.db_path.exists():
            raise FileNotFoundError(f"{self._kind.capitalize()} database not found at: {self.db_path}")

        with self.db_path.open("r", encoding="utf-8") as fh:
            raw_records = json.load(fh)

        records: List[TRecord] = []
        for index, raw in enumerate(raw_records, start=1):
            record = self.record_cls(raw)
            record.setdefault(self.id_field, f"{self.id_prefix}_{index}")
            for field_name, default_value in self.defaults.items():
                record.setdefault(field_name, default_value() if callable(default_value) else default_value)
            records.append(record)

        logger.info("Loaded %d %s records from %s", len(records), self._kind, self.db_path)
        return records

    def all(self) -> List[TRecord]:
        """Return every record."""
        return list(self._records)

    def get_by_id(self, record_id: str) -> TRecord | None:
        for record in self._records:
            if record[self.id_field] == record_id:
                return record
        return None
