"""
course_repository.py

Centralized access to the course database (data/course_db.json).

This is the ONE place in the codebase that reads course data from disk. The RAG
module ingests courses through this repository (instead of reading the file
itself), and nothing else in the application is allowed to read course_db.json
directly. This guarantees a single source of truth and makes it trivial to
swap the backing store later (e.g. for a real database) without touching
the RAG or Course Recommender modules.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List

from config import settings
from database.json_repository import JsonRepository


class CourseRecord(Dict[str, Any]):
    """
    A course record, structurally shaped like:
        {
            "id": str,
            "title": str,
            "provider": str,
            "skills_covered": List[str],
            "difficulty": str,
            "duration": str,
            "url": str,
            "certificate": bool,
            "description": str,
            "target_roles": List[str],
            "target_sectors": List[str],
        }
    Kept as a plain dict subclass for easy passthrough to vector store / retriever layers.
    """


class CourseRepository(JsonRepository[CourseRecord]):
    """Loads and serves course records from the single JSON source of truth."""

    record_cls = CourseRecord
    id_field = "id"
    id_prefix = "course"
    defaults = {
        "skills_covered": list,
        "target_roles": list,
        "target_sectors": list,
        "certificate": False,
    }

    def __init__(self, db_path: Path | None = None) -> None:
        super().__init__(db_path or settings.course_db_path, kind="course")

    def all_courses(self) -> List[CourseRecord]:
        """Return every course record."""
        return self.all()

    def get_by_skill(self, skill: str) -> List[CourseRecord]:
        """Return courses covering a specific skill (case-insensitive)."""
        skill_lower = skill.lower()
        return [c for c in self.all() if any(s.lower() == skill_lower for s in c.get("skills_covered", []))]


@lru_cache(maxsize=1)
def get_course_repository() -> CourseRepository:
    """Process-wide singleton so course_db.json is parsed from disk exactly once."""
    return CourseRepository()
