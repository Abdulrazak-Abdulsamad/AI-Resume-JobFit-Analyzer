"""
job_repository.py

Centralized access to the job database (`data/job_db.json`).

This is the ONE place in the codebase that reads job data from disk. The RAG
module ingests jobs through this repository (instead of reading the file
itself), and nothing else in the application is allowed to read job_db.json
directly. This guarantees a single source of truth and makes it trivial to
swap the backing store later (e.g. for a real database) without touching
the RAG or Job Analyzer modules.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List

from config import settings
from database.json_repository import JsonRepository


class JobRecord(Dict[str, Any]):
    """
    A job record, structurally shaped like:
        {
            "job_id": str,
            "title": str,
            "required_skills": List[str],
            "minimum_work_experience_years": int,
        }
    Kept as a plain dict subclass (rather than a heavier model) since it is
    passed straight through to the vector store / retriever layers.
    """


class JobRepository(JsonRepository[JobRecord]):
    """Loads and serves job records from the single JSON source of truth."""

    record_cls = JobRecord
    id_field = "job_id"
    id_prefix = "job"
    defaults = {
        "required_skills": list,
        "minimum_work_experience_years": 0,
    }

    def __init__(self, db_path: Path | None = None) -> None:
        super().__init__(db_path or settings.job_db_path, kind="job")

    def all_jobs(self) -> List[JobRecord]:
        """Return every job record."""
        return self.all()

    def get_by_title(self, title: str) -> JobRecord | None:
        if not title:
            return None
        target_title = title.strip().lower()
        for job in self.all():
            job_title = str(job.get("title") or "").strip().lower()
            if job_title == target_title:
                return job
        return None


@lru_cache(maxsize=1)
def get_job_repository() -> JobRepository:
    """Process-wide singleton so job_db.json is parsed from disk exactly once."""
    return JobRepository()
