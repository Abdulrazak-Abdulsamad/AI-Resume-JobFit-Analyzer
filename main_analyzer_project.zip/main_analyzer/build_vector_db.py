#!/usr/bin/env python3
"""
build_vector_db.py

Rebuilds the ChromaDB vector database from the canonical data sources:
  - data/job_db.json
  - data/course_db.json

Run this script after pulling the repository or whenever the underlying
JSON databases are updated.

Usage:
    python build_vector_db.py
"""
from __future__ import annotations

import shutil
from pathlib import Path

from config import settings
from database.course_repository import CourseRepository
from database.job_repository import JobRepository
from rag.vector_store import VectorStoreManager
from services.embedding_service import get_embedding_service
from utils.logging_config import get_logger

logger = get_logger(__name__)


def rebuild_vector_db() -> None:
    persist_directory = Path(settings.vector_store.persist_directory)

    if persist_directory.exists():
        logger.info("Removing existing vector store at %s", persist_directory)
        shutil.rmtree(persist_directory)

    persist_directory.mkdir(parents=True, exist_ok=True)

    job_repository = JobRepository()
    course_repository = CourseRepository()
    embedding_service = get_embedding_service()

    logger.info("Rebuilding vector store with %d jobs and %d courses...",
                len(job_repository.all_jobs()),
                len(course_repository.all_courses()))

    vector_store = VectorStoreManager(
        job_repository=job_repository,
        course_repository=course_repository,
        embedding_service=embedding_service,
    )

    logger.info("Vector store rebuilt successfully.")
    logger.info("Jobs indexed: %d", vector_store.count())
    logger.info("Courses indexed: %d", vector_store.count_courses())


if __name__ == "__main__":
    rebuild_vector_db()
