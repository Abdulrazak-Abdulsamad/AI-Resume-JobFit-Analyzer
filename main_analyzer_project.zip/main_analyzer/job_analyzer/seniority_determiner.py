"""
seniority_determiner.py (job_analyzer)

Step 7: Determine Seniority.

Determines the candidate's seniority based on relevant role experience,
responsibility level, leadership, project complexity, and scope of work.
Never uses total career years alone.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from job_analyzer.schemas import SeniorityResult


def _detect_leadership(achievements: List[str], responsibilities: List[str]) -> List[str]:
    leadership_keywords = ["led", "managed", "directed", "supervised", "mentored", "coached", "headed", "coordinated"]
    indicators = []
    all_text = " ".join(achievements + responsibilities).lower()
    for keyword in leadership_keywords:
        if keyword in all_text:
            indicators.append(keyword.capitalize())
    return indicators


def _assess_project_complexity(projects: List[str], tools: List[str]) -> str:
    complexity_indicators = ["enterprise", "distributed", "microservice", "cloud", "ml", "ai", "large-scale"]
    text = " ".join(projects + tools).lower()
    matches = sum(1 for ind in complexity_indicators if ind in text)
    if matches >= 3:
        return "High"
    if matches >= 1:
        return "Medium"
    return "Low"


def determine_seniority(
    target_role_years: float,
    responsibilities: List[str],
    achievements: List[str],
    projects: List[str],
    tools: List[str],
    target_job_seniority: str,
) -> SeniorityResult:
    leadership_indicators = _detect_leadership(achievements, responsibilities)
    project_complexity = _assess_project_complexity(projects, tools)

    if target_role_years >= 8 or len(leadership_indicators) >= 3:
        level = "Lead"
        reasoning = "Extensive relevant experience with strong leadership indicators."
    elif target_role_years >= 5 or len(leadership_indicators) >= 2:
        level = "Senior"
        reasoning = "Solid relevant experience with some leadership responsibilities."
    elif target_role_years >= 3:
        level = "Mid"
        reasoning = "Moderate relevant experience with growing responsibilities."
    elif target_role_years >= 1:
        level = "Junior"
        reasoning = "Early career experience in relevant roles."
    else:
        level = "Entry"
        reasoning = "Limited or no directly relevant experience."

    return SeniorityResult(
        level=level,
        reasoning=reasoning,
        relevant_role_experience_years=round(target_role_years, 1),
        responsibility_level=level,
        leadership_indicators=leadership_indicators,
        project_complexity=project_complexity,
        scope_of_work="Medium" if project_complexity != "Low" else "Low",
    )
