"""
similarity.py (job_analyzer)

Computes resume-vs-job textual similarity using two complementary signals:
  1. TF-IDF cosine similarity (keyword overlap).
  2. Semantic embedding cosine similarity (meaning overlap), via the shared
     EmbeddingService rather than a private SentenceTransformer instance.
"""
from __future__ import annotations

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from job_analyzer.schemas import SimilarityResult
from services.embedding_service import EmbeddingService, get_embedding_service

_TFIDF_WEIGHT = 0.4
_SEMANTIC_WEIGHT = 0.6


class SimilarityCalculator:
    def __init__(self, embedding_service: EmbeddingService | None = None) -> None:
        self.embedding_service = embedding_service or get_embedding_service()

    @staticmethod
    def _tfidf_similarity(resume_text: str, job_text: str) -> float:
        if not (resume_text or "").strip() or not (job_text or "").strip():
            return 0.0
        try:
            vectorizer = TfidfVectorizer(stop_words="english")
            tfidf_matrix = vectorizer.fit_transform([resume_text, job_text])
            return float(cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0])
        except ValueError:
            return 0.0

    def _semantic_similarity(self, resume_text: str, job_text: str) -> float:
        resume_vec, job_vec = self.embedding_service.encode_many([resume_text, job_text])
        return float(cosine_similarity([resume_vec], [job_vec])[0][0])

    def calculate(self, resume_text: str, job_text: str) -> SimilarityResult:
        tfidf_score = self._tfidf_similarity(resume_text, job_text)
        semantic_score = self._semantic_similarity(resume_text, job_text)
        combined = tfidf_score * _TFIDF_WEIGHT + semantic_score * _SEMANTIC_WEIGHT

        return SimilarityResult(
            tfidf_score=round(tfidf_score * 100, 2),
            semantic_score=round(semantic_score * 100, 2),
            combined_score=round(combined * 100, 2),
        )
