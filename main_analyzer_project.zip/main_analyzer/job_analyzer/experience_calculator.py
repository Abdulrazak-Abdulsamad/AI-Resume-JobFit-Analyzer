"""
experience_calculator.py (job_analyzer)

Step 4: Calculate Relevant Experience.

Calculates Total Career Experience, Target Industry Experience, and
Target Role Experience separately, never assuming cross-industry transfer.
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Dict, List, Optional

from job_analyzer.industry_classifier import classify_industries
from job_analyzer.schemas import ExperienceCalculation, PositionClassification


def _parse_date(date_str: str) -> Optional[datetime]:
    normalized = date_str.strip().lower()
    ongoing = {"present", "current", "now"}
    if normalized in ongoing:
        return datetime.now()
    for fmt in ("%B %Y", "%b %Y", "%Y"):
        try:
            return datetime.strptime(normalized, fmt)
        except ValueError:
            continue
    return None


def _estimate_position_years(dates: str, fallback: float) -> float:
    if not dates:
        return fallback
    pattern = re.compile(
        r"([a-zA-Z]+\s\d{4}|\d{4})\s*[-\u2013to]+\s*([a-zA-Z]+\s\d{4}|\d{4}|present|current|now)",
        re.IGNORECASE,
    )
    matches = pattern.findall(dates)
    total_months = 0
    for start_str, end_str in matches:
        start_date = _parse_date(start_str)
        end_date = _parse_date(end_str)
        if start_date and end_date and end_date >= start_date:
            months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_months += months
    if total_months > 0:
        return round(total_months / 12, 1)
    return fallback


def calculate_relevant_experience(
    experience_entries: List[Dict[str, Optional[str]]],
    target_role: str,
    target_sector: str,
    total_career_years: int,
) -> ExperienceCalculation:
    if not experience_entries:
        return ExperienceCalculation(
            total_career_experience=total_career_years,
            target_industry_experience=0.0,
            target_role_experience=0.0,
            reasoning="No experience entries found in resume.",
        )

    role_tokens = set(re.sub(r"[^a-z0-9+#.\-]", " ", target_role.lower()).split())
    sector_keywords = {
        "technology": ["software", "developer", "engineer", "cloud", "data", "ml", "ai", "devops"],
        "healthcare": ["patient", "clinical", "medical", "health", "nurse", "doctor", "hospital"],
        "finance": ["finance", "accounting", "audit", "tax", "investment", "banking"],
        "education": ["teaching", "curriculum", "instruction", "classroom", "student", "learning"],
        "marketing": ["marketing", "advertising", "campaign", "brand", "seo", "sem"],
        "sales": ["sales", "account", "client", "deal", "negotiation", "pipeline", "quota"],
        "manufacturing": ["manufacturing", "production", "quality", "lean", "six sigma"],
        "logistics": ["logistics", "supply chain", "warehouse", "inventory", "procurement"],
        "government": ["government", "federal", "state", "policy", "regulation"],
        "construction": ["construction", "building", "project management", "site", "contractor"],
    }
    target_sector_lower = target_sector.lower()
    target_keywords = sector_keywords.get(target_sector_lower, [])

    classifications = classify_industries(experience_entries)
    estimated_years_per_position = total_career_years / len(experience_entries) if experience_entries else 0

    positions_counted = []
    positions_excluded = []
    target_role_years = 0.0
    target_industry_years = 0.0
    industry_breakdown = []
    reasons = []

    for idx, entry in enumerate(experience_entries):
        if hasattr(entry, "company"):
            company = entry.company or f"Position {idx + 1}"
            role_text = entry.role or ""
            dates = entry.dates or ""
        else:
            company = entry.get("company") or f"Position {idx + 1}" if isinstance(entry, dict) else f"Position {idx + 1}"
            role_text = entry.get("role") or "" if isinstance(entry, dict) else ""
            dates = entry.get("dates") or "" if isinstance(entry, dict) else ""
        position_years = _estimate_position_years(dates, estimated_years_per_position)
        classification = classifications[idx] if idx < len(classifications) else None
        combined_text = f"{company} {role_text}".lower()

        role_token_matches = role_tokens & set(re.sub(r"[^a-z0-9+#.\-]", " ", combined_text).split())
        role_similarity = len(role_token_matches) / max(len(role_tokens), 1) if role_tokens else 0.0

        industry_match = 0.0
        if classification and classification.primary_industry.lower() == target_sector_lower:
            industry_match = classification.relevance_score / 100.0
        elif target_keywords:
            text_tokens = set(re.sub(r"[^a-z0-9+#.\-]", " ", combined_text).split())
            industry_match = len(text_tokens & set(target_keywords)) / max(len(target_keywords), 1)

        relevance_score = min(1.0, role_similarity * 0.6 + industry_match * 0.4)
        relevance_percentage = relevance_score * 100

        if relevance_percentage >= 70:
            classification_label = "Directly Relevant"
            multiplier = 1.0
        elif relevance_percentage >= 40:
            classification_label = "Partially Relevant"
            multiplier = relevance_score
        else:
            classification_label = "Not Relevant"
            multiplier = 0.0

        counted_years = position_years * multiplier

        reasons.append(
            f"[{company}] Role similarity: {round(role_similarity * 100, 1)}%, "
            f"Industry match: {round(industry_match * 100, 1)}% "
            f"=> Relevance: {round(relevance_percentage, 1)}% ({classification_label}). "
            f"Counting {round(counted_years, 1)} of {round(position_years, 1)} years."
        )

        position_data = {
            "company": company,
            "role_title": role_text,
            "classification": classification_label,
            "relevance_score": round(relevance_percentage, 1),
            "years": round(position_years, 1),
            "target_role_years": round(counted_years, 1),
        }

        if classification_label == "Not Relevant":
            positions_excluded.append(position_data)
        else:
            positions_counted.append(position_data)
            target_role_years += counted_years
            target_industry_years += position_years if classification_label == "Directly Relevant" else position_years * 0.7
            if classification:
                industry_breakdown.append({
                    "industry": classification.primary_industry,
                    "years": round(position_years, 1),
                    "relevance_score": round(relevance_percentage, 1),
                })

    target_role_years = round(target_role_years, 1)
    target_industry_years = round(target_industry_years, 1)

    reasoning = "\n".join(reasons)
    reasoning += (
        f"\n\nSummary: {len(positions_counted)} positions counted, {len(positions_excluded)} excluded. "
        f"Target role experience: {target_role_years} years. "
        f"Target industry experience: {target_industry_years} years."
    )

    return ExperienceCalculation(
        total_career_experience=total_career_years,
        target_industry_experience=target_industry_years,
        target_role_experience=target_role_years,
        industry_breakdown=industry_breakdown,
        positions_counted=positions_counted,
        positions_excluded=positions_excluded,
        reasoning=reasoning,
    )
