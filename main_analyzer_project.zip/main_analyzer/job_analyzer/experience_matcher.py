"""
experience_matcher.py (job_analyzer)

Compares a candidate's work experience against a target role using the
new experience calculator.
"""
from __future__ import annotations

from typing import Any, Dict, List

from job_analyzer.experience_calculator import calculate_relevant_experience
from job_analyzer.schemas import ExperienceMatchResult


class ExperienceMatcher:
    def match(
        self,
        experience_entries: List[Dict[str, Any]],
        target_role: Dict[str, Any],
        target_sector: str,
        total_experience_years: int,
    ) -> ExperienceMatchResult:
        result = calculate_relevant_experience(
            experience_entries=experience_entries,
            target_role=target_role.get("title", ""),
            target_sector=target_sector,
            total_career_years=total_experience_years,
        )

        raw_years = target_role.get("minimum_work_experience_years", 0)
        try:
            required_years = float(raw_years) if raw_years is not None else 0.0
        except (ValueError, TypeError):
            required_years = 0.0

        target_role_years = result.target_role_experience
        meets_requirement = target_role_years >= required_years if required_years > 0 else True
        match_percentage = min(100.0, (target_role_years / required_years * 100)) if required_years > 0 else 100.0

        return ExperienceMatchResult(
            candidate_years=total_experience_years,
            required_years=required_years,
            meets_requirement=meets_requirement,
            match_percentage=round(match_percentage, 2),
            target_role_years=target_role_years,
            target_sector_years=result.target_industry_experience,
            role_relevance_score=100.0 if target_role_years >= required_years else (target_role_years / max(required_years, 1)) * 100,
            positions_counted=result.positions_counted,
            positions_excluded=result.positions_excluded,
            reasoning=result.reasoning,
        )
