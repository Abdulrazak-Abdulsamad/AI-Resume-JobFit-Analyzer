"""
schemas.py (job_analyzer)

Output data contracts for the 8-step ATS Resume Analyzer.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel

from course_recommender.schemas import CourseRecommendationBundle


# ---------------------------------------------------------------------------
# Step 1: Target Job
# ---------------------------------------------------------------------------

class TargetJobProfile(BaseModel):
    title: str
    role: str
    sector: str
    seniority_level: str
    required_skills: List[str] = []
    preferred_skills: List[str] = []
    required_experience_years: int = 0
    required_education: List[str] = []
    required_certifications: List[str] = []
    responsibilities: List[str] = []
    tools_technologies: List[str] = []


# ---------------------------------------------------------------------------
# Step 2: Resume Analysis
# ---------------------------------------------------------------------------

class ResumeAnalysis(BaseModel):
    total_career_experience: float = 0.0
    industry_experience: Dict[str, float] = {}
    role_specific_experience: Dict[str, float] = {}
    skills: List[str] = []
    education: List[Dict[str, Optional[str]]] = []
    certifications: List[str] = []
    projects: List[str] = []
    achievements: List[str] = []
    responsibilities: List[str] = []
    tools_technologies: List[str] = []


# ---------------------------------------------------------------------------
# Step 3: Industry Classification
# ---------------------------------------------------------------------------

class IndustryClassification(BaseModel):
    industry: str
    relevance_score: float
    reasoning: str


class PositionClassification(BaseModel):
    company: str
    role_title: str
    industries: List[IndustryClassification]
    primary_industry: str
    relevance_score: float


# ---------------------------------------------------------------------------
# Step 4: Experience Calculation
# ---------------------------------------------------------------------------

class ExperienceCalculation(BaseModel):
    total_career_experience: float
    target_industry_experience: float
    target_role_experience: float
    industry_breakdown: List[Dict[str, Any]] = []
    positions_counted: List[Dict[str, Any]] = []
    positions_excluded: List[Dict[str, Any]] = []
    reasoning: str


# ---------------------------------------------------------------------------
# Step 5: Category Scores
# ---------------------------------------------------------------------------

class CategoryScores(BaseModel):
    ats_score: float
    skill_match_score: float
    experience_match_score: float
    industry_match_score: float
    education_match_score: float
    certification_match_score: float
    achievement_score: float
    resume_quality_score: float


# ---------------------------------------------------------------------------
# Step 6: Job Match Score
# ---------------------------------------------------------------------------

class JobMatchScore(BaseModel):
    score: float
    weights: Dict[str, float]
    components: CategoryScores


# ---------------------------------------------------------------------------
# Step 7: Seniority
# ---------------------------------------------------------------------------

class SeniorityResult(BaseModel):
    level: str
    reasoning: str
    relevant_role_experience_years: float
    responsibility_level: str
    leadership_indicators: List[str] = []
    project_complexity: str
    scope_of_work: str


# ---------------------------------------------------------------------------
# Step 8: Score Explanations
# ---------------------------------------------------------------------------

class ScoreExplanation(BaseModel):
    category: str
    score: float
    awarded_points: str
    deducted_points: str
    influencing_sections: List[str] = []
    improvements: List[str] = []


class FullAnalysisResult(BaseModel):
    # Step 1
    target_job: TargetJobProfile
    # Step 2
    resume_analysis: ResumeAnalysis
    # Step 3
    position_classifications: List[PositionClassification] = []
    # Step 4
    experience_calculation: ExperienceCalculation
    # Step 5-6
    category_scores: CategoryScores
    job_match_score: JobMatchScore
    # Step 7
    seniority: SeniorityResult
    # Step 8
    score_explanations: List[ScoreExplanation] = []
    # Legacy compatibility
    ats_score: float = 0.0
    job_match_score_legacy: float = 0.0
    skill_match_score: float = 0.0
    experience_match_score: float = 0.0
    final_fit_score: float = 0.0
    rating: str = ""


# ---------------------------------------------------------------------------
# Legacy schemas (kept for backward compatibility)
# ---------------------------------------------------------------------------

class SimilarityResult(BaseModel):
    tfidf_score: float
    semantic_score: float
    combined_score: float


class SkillGapResult(BaseModel):
    resume_skills: List[str]
    job_required_skills: List[str]
    matching_skills: List[str]
    missing_skills: List[str]
    skill_match_percentage: float


class ExperienceMatchResult(BaseModel):
    candidate_years: int
    required_years: int
    meets_requirement: bool
    match_percentage: float
    target_role_years: float = 0.0
    target_sector_years: float = 0.0
    role_relevance_score: float = 0.0
    positions_counted: List[Dict[str, Any]] = []
    positions_excluded: List[Dict[str, Any]] = []
    reasoning: str = ""


class ScoreResult(BaseModel):
    similarity_score: float
    skill_match_score: float
    experience_match_score: float
    final_fit_score: float
    rating: str


class JobAnalysisResult(BaseModel):
    job_id: str
    job_title: str
    retrieval_similarity: float
    similarity: SimilarityResult
    skills: SkillGapResult
    experience: ExperienceMatchResult
    score: ScoreResult
    strengths: List[str]
    weaknesses: List[str]
    improvement_suggestions: List[str]
    course_recommendations: CourseRecommendationBundle
