"""
engine.py (job_analyzer)

The Job Analyzer's public entry point. Given a parsed resume, it:
  1. Identifies the target job profile.
  2. Analyzes the resume.
  3. Classifies industries for each position.
  4. Calculates relevant experience.
  5. Scores each category independently.
  6. Calculates the Job Match Score.
  7. Determines seniority.
  8. Explains every score.

All expensive resources are constructed once and reused across every call.
"""
from __future__ import annotations

from typing import Any, Dict, List

from course_recommender.recommender_service import CourseRecommendationService
from course_recommender.roadmap_builder import RoadmapBuilder
from job_analyzer.experience_calculator import calculate_relevant_experience
from job_analyzer.experience_matcher import ExperienceMatcher
from job_analyzer.industry_classifier import classify_industries
from job_analyzer.resume_analyzer import analyze_resume
from job_analyzer.schemas import CategoryScores, FullAnalysisResult, JobAnalysisResult
from job_analyzer.score_explainer import generate_score_explanations
from job_analyzer.scoring import (
    calculate_job_match_score,
    calculate_legacy_scores,
    score_achievements,
    score_ats_compatibility,
    score_certification_match,
    score_education_match,
    score_experience_match,
    score_industry_match,
    score_resume_quality,
    score_skill_match,
)
from job_analyzer.seniority_determiner import determine_seniority
from job_analyzer.target_job_analyzer import analyze_target_job
from job_analyzer.insights import InsightGenerator
from job_analyzer.skill_gap import SkillGapAnalyzer
from job_analyzer.similarity import SimilarityCalculator
from rag.course_retriever import CourseRetriever
from rag.retriever import JobRetriever
from resume_parsing.schema import ParsedResume
from utils.logging_config import get_logger

logger = get_logger(__name__)


def _resume_to_text(resume: ParsedResume) -> str:
    """Flatten the parsed resume into free text for similarity scoring."""
    experience_text = " ".join(f"{e.company or ''} {e.role or ''}" for e in resume.experience)
    education_text = " ".join(f"{e.institution or ''} {e.degree or ''}" for e in resume.education)
    return " ".join([
        resume.name or "",
        ", ".join(resume.skills),
        education_text,
        experience_text,
    ]).strip()


class JobAnalyzer:
    """Orchestrates the full 8-step ATS analysis pipeline."""

    def __init__(
        self,
        retriever: JobRetriever,
        similarity_calculator: SimilarityCalculator | None = None,
        skill_gap_analyzer: SkillGapAnalyzer | None = None,
        experience_matcher: ExperienceMatcher | None = None,
        insight_generator: InsightGenerator | None = None,
        course_recommendation_service: CourseRecommendationService | None = None,
    ) -> None:
        self.retriever = retriever
        self.similarity_calculator = similarity_calculator or SimilarityCalculator()
        self.skill_gap_analyzer = skill_gap_analyzer or SkillGapAnalyzer()
        self.experience_matcher = experience_matcher or ExperienceMatcher()
        self.insight_generator = insight_generator or InsightGenerator()

        if course_recommendation_service is None:
            course_retriever = CourseRetriever(vector_store=retriever.vector_store)
            course_recommendation_service = CourseRecommendationService(
                course_retriever=course_retriever,
                roadmap_builder=RoadmapBuilder(),
            )
        self.course_recommendation_service = course_recommendation_service

    def analyze(self, resume: ParsedResume, top_k: int | None = None) -> List[JobAnalysisResult]:
        retrieved_jobs = self.retriever.retrieve_top_jobs(resume, top_k=top_k)
        if not retrieved_jobs:
            logger.warning("RAG pipeline returned no candidate jobs for this resume.")
            return []

        resume_text = _resume_to_text(resume)
        results: List[JobAnalysisResult] = []

        for job in retrieved_jobs:
            full_result = self._analyze_single_job(resume, resume_text, job)
            if full_result is None:
                continue

            similarity = self.similarity_calculator.calculate(resume_text, job.context_text)
            skills = self.skill_gap_analyzer.analyze(resume.skills, job.required_skills)
            experience = self.experience_matcher.match(
                resume.experience or [],
                {
                    "title": job.title,
                    "minimum_work_experience_years": job.minimum_work_experience_years,
                },
                job.sector or "",
                resume.total_experience_years or 0,
            )
            legacy_score = calculate_legacy_scores(full_result.category_scores, full_result.job_match_score)
            strengths, weaknesses, suggestions = self.insight_generator.generate(skills, experience, legacy_score)
            course_recommendations = self.course_recommendation_service.recommend_for_job(
                job_title=job.title or "",
                sector=job.sector or "",
                missing_skills=skills.missing_skills,
                experience_years=resume.total_experience_years or 0,
            )

            results.append(JobAnalysisResult(
                job_id=job.job_id,
                job_title=job.title,
                retrieval_similarity=job.similarity_score,
                similarity=similarity,
                skills=skills,
                experience=experience,
                score=legacy_score,
                strengths=strengths,
                weaknesses=weaknesses,
                improvement_suggestions=suggestions,
                course_recommendations=course_recommendations,
            ))

        results.sort(key=lambda r: r.score.final_fit_score, reverse=True)
        return results

    def analyze_full(self, resume: ParsedResume, job_record: Dict[str, Any], context_text: str = "") -> FullAnalysisResult:
        """Run the full 8-step analysis for a single target job."""
        # Step 1
        target_job = analyze_target_job(job_record, context_text)

        # Step 2
        resume_analysis = analyze_resume(resume)

        # Step 3
        position_classifications = classify_industries(resume.experience or [])

        # Step 4
        experience_calculation = calculate_relevant_experience(
            experience_entries=resume.experience or [],
            target_role=target_job.title,
            target_sector=target_job.sector,
            total_career_years=resume.total_experience_years or 0,
        )

        # Step 5-6
        ats_score = score_ats_compatibility(resume_analysis)
        skill_match_score, matched_skills, missing_skills = score_skill_match(
            resume_analysis["skills"], target_job.required_skills, target_job.preferred_skills
        )
        experience_match_score = score_experience_match(
            experience_calculation.target_role_experience, target_job.required_experience_years
        )
        industry_match_score = score_industry_match(
            experience_calculation.target_industry_experience, resume_analysis["total_career_experience"]
        )
        education_match_score = score_education_match(
            resume_analysis["education"], target_job.required_education
        )
        certification_match_score = score_certification_match(
            resume_analysis["certifications"], target_job.required_certifications
        )
        achievement_score = score_achievements(resume_analysis["achievements"])
        resume_quality_score = score_resume_quality(resume_analysis)

        category_scores = CategoryScores(
            ats_score=round(ats_score, 2),
            skill_match_score=round(skill_match_score, 2),
            experience_match_score=round(experience_match_score, 2),
            industry_match_score=round(industry_match_score, 2),
            education_match_score=round(education_match_score, 2),
            certification_match_score=round(certification_match_score, 2),
            achievement_score=round(achievement_score, 2),
            resume_quality_score=round(resume_quality_score, 2),
        )

        job_match_score = calculate_job_match_score(category_scores)

        # Step 7
        seniority = determine_seniority(
            target_role_years=experience_calculation.target_role_experience,
            responsibilities=resume_analysis["responsibilities"],
            achievements=resume_analysis["achievements"],
            projects=resume_analysis["projects"],
            tools=resume_analysis["tools_technologies"],
            target_job_seniority=target_job.seniority_level,
        )

        # Step 8
        score_explanations = generate_score_explanations(
            category_scores=category_scores,
            resume=resume_analysis,
            matched_skills=matched_skills,
            missing_skills=missing_skills,
            target_role_years=experience_calculation.target_role_experience,
            required_years=target_job.required_experience_years,
            target_industry_years=experience_calculation.target_industry_experience,
            certifications=resume_analysis["certifications"],
            required_certifications=target_job.required_certifications,
        )

        legacy_score = calculate_legacy_scores(category_scores, job_match_score)

        return FullAnalysisResult(
            target_job=target_job,
            resume_analysis=resume_analysis,
            position_classifications=position_classifications,
            experience_calculation=experience_calculation,
            category_scores=category_scores,
            job_match_score=job_match_score,
            seniority=seniority,
            score_explanations=score_explanations,
            ats_score=category_scores.ats_score,
            job_match_score_legacy=job_match_score.score,
            skill_match_score=category_scores.skill_match_score,
            experience_match_score=category_scores.experience_match_score,
            final_fit_score=legacy_score.final_fit_score,
            rating=legacy_score.rating,
        )

    def _analyze_single_job(self, resume: ParsedResume, resume_text: str, job: Any) -> FullAnalysisResult | None:
        job_record = {
            "title": getattr(job, "title", ""),
            "sector": getattr(job, "sector", ""),
            "required_skills": getattr(job, "required_skills", []),
            "minimum_work_experience_years": getattr(job, "minimum_work_experience_years", 0),
        }
        return self.analyze_full(resume, job_record, getattr(job, "context_text", ""))
