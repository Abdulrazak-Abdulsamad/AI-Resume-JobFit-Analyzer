"""
target_job_analyzer.py (job_analyzer)

Step 1: Identify the Target Job.

Extracts and structures the target job profile from a retrieved job record.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from job_analyzer.schemas import TargetJobProfile


def _infer_seniority(title: str, required_years: int) -> str:
    title_lower = title.lower()
    if any(level in title_lower for level in ["executive", "chief", "director", "vp", "vice president"]):
        return "Executive"
    if any(level in title_lower for level in ["manager", "lead", "principal", "staff"]):
        return "Manager"
    if any(level in title_lower for level in ["senior", "sr.", "sr ", "lead"]):
        return "Senior"
    if required_years >= 5:
        return "Senior"
    if required_years >= 3:
        return "Mid"
    if required_years >= 1:
        return "Junior"
    return "Entry"


def _extract_tools_technologies(required_skills: List[str], context_text: str) -> List[str]:
    tech_keywords = [
        "python", "java", "javascript", "react", "node.js", "sql", "git", "docker",
        "kubernetes", "aws", "azure", "gcp", "terraform", "jenkins", "ci/cd",
        "postgresql", "mongodb", "redis", "kafka", "graphql", "rest api",
        "tensorflow", "pytorch", "pandas", "numpy", "spark", "hadoop",
        "figma", "sketch", "adobe", "photoshop", "illustrator",
        "salesforce", "hubspot", "sap", "oracle", "servicenow",
    ]
    text = f"{' '.join(required_skills)} {context_text}".lower()
    found = []
    for tool in tech_keywords:
        if tool in text and tool not in found:
            found.append(tool)
    return found


def analyze_target_job(job_record: Dict[str, Any], context_text: str = "") -> TargetJobProfile:
    title = job_record.get("title", "Unknown Position")
    sector = job_record.get("sector", "General")
    required_skills = job_record.get("required_skills", [])
    min_years = job_record.get("minimum_work_experience_years", 0)

    seniority = _infer_seniority(title, min_years)
    tools = _extract_tools_technologies(required_skills, context_text)

    return TargetJobProfile(
        title=title,
        role=title,
        sector=sector,
        seniority_level=seniority,
        required_skills=required_skills,
        preferred_skills=[],
        required_experience_years=min_years,
        required_education=[],
        required_certifications=[],
        responsibilities=[],
        tools_technologies=tools,
    )
