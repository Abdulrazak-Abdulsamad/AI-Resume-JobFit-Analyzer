"""
industry_classifier.py (job_analyzer)

Step 3: Industry & Role Classification.

Classifies each work experience entry into one or more industries using
semantic analysis of responsibilities, skills, and technologies.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from job_analyzer.schemas import IndustryClassification, PositionClassification


_INDUSTRY_KEYWORDS: Dict[str, List[str]] = {
    "Technology": [
        "software", "developer", "engineer", "programming", "cloud", "aws", "azure",
        "gcp", "devops", "sre", "backend", "frontend", "fullstack", "data", "ml",
        "ai", "cybersecurity", "network", "database", "api", "microservice",
        "container", "docker", "kubernetes", "terraform", "jenkins", "ci/cd",
        "python", "java", "javascript", "react", "node", "sql", "git", "linux",
        "security", "infrastructure", "platform",
    ],
    "Healthcare": [
        "patient", "clinical", "nurse", "physician", "doctor", "medical", "hospital",
        "health", "diagnosis", "treatment", "surgery", "ehr", "emr", "pharmacy",
        "therapy", "rehabilitation", "dental", "lab", "pathology", "radiology",
        "surgical", "sterile", "dialysis", "coding", "billing", "compliance",
        "hipaa", "infection", "nursing", "care", "clinic",
    ],
    "Finance": [
        "finance", "accounting", "audit", "tax", "investment", "banking", "financial",
        "gaap", "budgeting", "forecasting", "payroll", "treasury", "fp&a",
        "controller", "equity", "portfolio", "risk", "compliance", "auditing",
        "modeling", "valuation", "ma", "due diligence", "revenue", "capital",
    ],
    "Education": [
        "teaching", "curriculum", "instruction", "classroom", "lesson", "pedagogy",
        "assessment", "student", "learning", "education", "school", "university",
        "faculty", "lecture", "tutoring", "mentoring", "training", "academic",
        "research", "campus", "enrollment", "counseling", "lms", "e-learning",
    ],
    "Marketing": [
        "marketing", "advertising", "campaign", "brand", "seo", "sem", "social media",
        "content", "copywriting", "crm", "hubspot", "salesforce", "lead",
        "conversion", "funnel", "roi", "analytics", "pr", "event", "proposal",
    ],
    "Sales": [
        "sales", "account", "client", "customer", "deal", "negotiation", "closing",
        "pipeline", "quota", "territory", "retention", "upsell", "cross-sell",
        "prospect", "lead generation", "cold calling",
    ],
    "Manufacturing": [
        "manufacturing", "production", "assembly", "quality control", "qc", "qa",
        "lean", "six sigma", "cnc", "machining", "welding", "tooling", "maintenance",
        "reliability", "oee", "supply chain",
    ],
    "Logistics": [
        "logistics", "supply chain", "warehouse", "inventory", "procurement",
        "distribution", "transportation", "shipping", "freight", "customs",
        "vendor", "supplier", "sourcing", "sla", "traceability",
    ],
    "Government": [
        "government", "federal", "state", "local", "public sector", "policy",
        "regulation", "compliance", "legislation", "agency", "department",
    ],
    "Construction": [
        "construction", "building", "project management", "site", "contractor",
        "architect", "engineering", "structural", "civil", "permits", "safety",
    ],
}


def _tokenize(text: str) -> List[str]:
    text = re.sub(r"[^a-z0-9+#.\-]", " ", text.lower())
    return [t for t in text.split() if len(t) > 1]


def classify_industries(experience_entries: List[Dict[str, Optional[str]]]) -> List[PositionClassification]:
    results = []
    for entry in experience_entries:
        if hasattr(entry, "company"):
            company = entry.company or ""
            role = entry.role or ""
        else:
            company = entry.get("company", "") if isinstance(entry, dict) else ""
            role = entry.get("role", "") if isinstance(entry, dict) else ""
        text = f"{company} {role}".lower()
        tokens = set(_tokenize(text))

        industry_scores = {}
        for industry, keywords in _INDUSTRY_KEYWORDS.items():
            matches = tokens & set(keywords)
            industry_scores[industry] = len(matches)

        sorted_industries = sorted(industry_scores.items(), key=lambda x: x[1], reverse=True)
        relevant_industries = [
            IndustryClassification(
                industry=industry,
                relevance_score=score,
                reasoning=f"Matched {score} industry keywords in position description.",
            )
            for industry, score in sorted_industries[:3]
            if score > 0
        ] or [
            IndustryClassification(
                industry="General",
                relevance_score=0.0,
                reasoning="No clear industry indicators found.",
            )
        ]

        primary = relevant_industries[0].industry if relevant_industries else "General"
        total_relevance = sum(ind.relevance_score for ind in relevant_industries)
        normalized_relevance = min(100.0, (total_relevance / max(len(_tokenize(text)), 1)) * 100)

        results.append(
            PositionClassification(
                company=company or "Unknown",
                role_title=role or "Unknown",
                industries=relevant_industries,
                primary_industry=primary,
                relevance_score=round(normalized_relevance, 1),
            )
        )
    return results
