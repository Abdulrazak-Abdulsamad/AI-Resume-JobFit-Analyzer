"""
scoring.py (job_analyzer)

Steps 5-6: Score Each Category Independently and Calculate Job Match Score.

Computes all category scores and the final weighted Job Match Score.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from config import settings
from job_analyzer.schemas import CategoryScores, JobMatchScore, ScoreResult


def _clamp(value: float, min_val: float = 0.0, max_val: float = 100.0) -> float:
    return max(min_val, min(max_val, value))


def _rating_for_score(score: float, bands: Any = None) -> str:
    """
    Classify a 0-100 score into a rating label using `bands` (defaults to
    `settings.rating_bands`). This is the single place that maps score ->
    rating; both the new scoring path (`calculate_legacy_scores`) and the
    legacy `ResumeScorer` used to each hardcode their own copy of these
    thresholds.
    """
    bands = bands or settings.rating_bands
    if score >= bands.excellent:
        return "Excellent Match"
    if score >= bands.very_good:
        return "Very Good Match"
    if score >= bands.good:
        return "Good Match"
    if score >= bands.average:
        return "Average Match"
    return "Poor Match"


def score_ats_compatibility(resume: Dict[str, Any]) -> float:
    score = 0.0
    if resume.get("name"):
        score += 15
    if resume.get("email"):
        score += 15
    if resume.get("phone"):
        score += 10
    skills = resume.get("skills", [])
    if len(skills) > 3:
        score += 25
    if resume.get("total_career_experience", 0) > 0:
        score += 20
    if resume.get("education"):
        score += 15
    return _clamp(score)


def score_skill_match(resume_skills: List[str], required_skills: List[str], preferred_skills: List[str]) -> tuple[float, List[str], List[str]]:
    if not required_skills and not preferred_skills:
        return 100.0, [], []

    all_required = required_skills + preferred_skills
    resume_lower = [s.lower().strip() for s in resume_skills]

    matched = []
    missing = []
    for skill in all_required:
        skill_lower = skill.lower().strip()
        found = any(skill_lower in rs or rs in skill_lower for rs in resume_lower)
        if found:
            matched.append(skill)
        else:
            missing.append(skill)

    score = (len(matched) / len(all_required)) * 100 if all_required else 100.0
    return _clamp(score), matched, missing


def score_experience_match(target_role_years: float, required_years: int) -> float:
    if required_years <= 0:
        return 100.0
    return _clamp((target_role_years / required_years) * 100)


def score_industry_match(target_industry_years: float, total_career_years: float) -> float:
    if total_career_years <= 0:
        return 0.0
    return _clamp((target_industry_years / total_career_years) * 100)


def score_education_match(resume_education: List[Any], required_education: List[str]) -> float:
    if not required_education:
        return 100.0
    degrees = []
    for e in resume_education or []:
        if isinstance(e, dict):
            degrees.append(str(e.get("degree", "")).lower())
        elif hasattr(e, "degree"):
            degrees.append(str(getattr(e, "degree", "") or "").lower())
        else:
            degrees.append(str(e).lower())
    resume_degrees = " ".join(degrees)
    matched = 0
    for req in required_education:
        if req and str(req).lower() in resume_degrees:
            matched += 1
    return _clamp((matched / len(required_education)) * 100) if required_education else 100.0


def score_certification_match(resume_certs: List[Any], required_certs: List[str]) -> float:
    if not required_certs:
        return 100.0
    matched = 0
    for req in required_certs:
        req_lower = str(req).lower()
        if any(req_lower in str(cert).lower() for cert in (resume_certs or []) if cert):
            matched += 1
    return _clamp((matched / len(required_certs)) * 100) if required_certs else 100.0


def score_achievements(achievements: List[Any]) -> float:
    ach_list = [str(a).lower() for a in (achievements or []) if a]
    if not ach_list:
        return 30.0
    quantified = sum(1 for a in ach_list if any(q in a for q in ["%", "increased", "reduced", "improved", "$", "million", "thousand"]))
    ratio = quantified / len(ach_list)
    return _clamp(30 + ratio * 70)


def score_resume_quality(resume: Dict[str, Any]) -> float:
    score = 50.0
    if resume.get("name"):
        score += 10
    if resume.get("email"):
        score += 10
    if resume.get("phone"):
        score += 5
    skills = resume.get("skills", [])
    if len(skills) >= 5:
        score += 10
    if resume.get("education"):
        score += 10
    if resume.get("achievements"):
        score += 5
    return _clamp(score)


def calculate_job_match_score(
    category_scores: CategoryScores,
    weights: Optional[Dict[str, float]] = None,
) -> JobMatchScore:
    w = weights or {
        "skills_match": settings.category_weights.skills_match,
        "experience_match": settings.category_weights.experience_match,
        "industry_match": settings.category_weights.industry_match,
        "education_match": settings.category_weights.education_match,
        "certification_match": settings.category_weights.certification_match,
        "achievement_score": settings.category_weights.achievement_score,
        "ats_compatibility": settings.category_weights.ats_compatibility,
        "resume_quality": settings.category_weights.resume_quality,
    }

    job_match_score = round(
        category_scores.skill_match_score * w["skills_match"]
        + category_scores.experience_match_score * w["experience_match"]
        + category_scores.industry_match_score * w["industry_match"]
        + category_scores.education_match_score * w["education_match"]
        + category_scores.certification_match_score * w["certification_match"]
        + category_scores.achievement_score * w["achievement_score"]
        + category_scores.ats_score * w["ats_compatibility"]
        + category_scores.resume_quality_score * w["resume_quality"],
        2,
    )

    return JobMatchScore(
        score=_clamp(job_match_score),
        weights=w,
        components=category_scores,
    )


def calculate_legacy_scores(category_scores: CategoryScores, job_match: JobMatchScore) -> ScoreResult:
    final_fit_score = round(job_match.score, 2)
    rating = _rating_for_score(final_fit_score)
    return ScoreResult(
        similarity_score=round((category_scores.skill_match_score + category_scores.experience_match_score) / 2, 2),
        skill_match_score=round(category_scores.skill_match_score, 2),
        experience_match_score=round(category_scores.experience_match_score, 2),
        final_fit_score=final_fit_score,
        rating=rating,
    )


class ResumeScorer:
    """Legacy wrapper for backward compatibility with existing tests."""
    def __init__(self) -> None:
        self.weights = settings.scoring_weights
        self.bands = settings.rating_bands

    def calculate_score(
        self,
        similarity_score: float,
        skill_match_percentage: float,
        experience_match_percentage: float,
    ) -> ScoreResult:
        final_score = (
            similarity_score * self.weights.semantic_similarity
            + skill_match_percentage * self.weights.skill_match
            + experience_match_percentage * self.weights.experience_match
        )
        return ScoreResult(
            similarity_score=round(similarity_score, 2),
            skill_match_score=round(skill_match_percentage, 2),
            experience_match_score=round(experience_match_percentage, 2),
            final_fit_score=round(final_score, 2),
            rating=_rating_for_score(final_score, self.bands),
        )
