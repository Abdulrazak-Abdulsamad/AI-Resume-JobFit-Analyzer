"""
resume_analyzer.py (job_analyzer)

Step 2: Analyze the Resume.

Extracts structured information from the parsed resume for scoring.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from resume_parsing.schema import ParsedResume


def analyze_resume(resume: ParsedResume) -> Dict[str, Any]:
    skills = list(resume.skills or [])
    education = [
        {
            "institution": entry.institution,
            "degree": entry.degree,
            "dates": entry.dates,
        }
        for entry in (resume.education or [])
    ]
    experience_entries = list(resume.experience or [])

    responsibilities = []
    tools_technologies = []
    achievements = []
    projects = []
    for entry in experience_entries:
        role_text = entry.role or ""
        company = entry.company or ""
        combined = f"{company} {role_text}".lower()
        responsibilities.append(role_text)
        if any(keyword in combined for keyword in ["project", "built", "developed", "launched", "implemented"]):
            projects.append(f"{company}: {role_text}")
        if any(keyword in combined for keyword in ["award", "recognition", "promoted", "led", "increased", "reduced", "improved"]):
            achievements.append(f"{company}: {role_text}")
        for tool in ["python", "java", "javascript", "react", "node.js", "sql", "git", "docker",
                     "kubernetes", "aws", "azure", "gcp", "tensorflow", "pytorch", "spark"]:
            if tool in combined and tool not in tools_technologies:
                tools_technologies.append(tool)

    return {
        "total_career_experience": resume.total_experience_years or 0,
        "industry_experience": {},
        "role_specific_experience": {},
        "skills": skills,
        "education": education,
        "certifications": [],
        "projects": projects,
        "achievements": achievements,
        "responsibilities": responsibilities,
        "tools_technologies": tools_technologies,
    }
