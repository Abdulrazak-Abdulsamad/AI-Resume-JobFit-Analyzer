"""
score_explainer.py (job_analyzer)

Step 8: Explain Every Score.

Generates transparent, explainable reasoning for each category score.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from job_analyzer.schemas import CategoryScores, ScoreExplanation


def explain_ats_score(score: float, resume: Dict[str, Any]) -> ScoreExplanation:
    awarded = []
    deducted = []
    sections = []

    if resume.get("name"):
        awarded.append("+15: Contact information present")
        sections.append("Header/Contact")
    else:
        deducted.append("-15: Missing contact information")

    if resume.get("email"):
        awarded.append("+15: Email address found")
    else:
        deducted.append("-15: Missing email")

    if resume.get("phone"):
        awarded.append("+10: Phone number found")
    else:
        deducted.append("-10: Missing phone")

    skills = resume.get("skills", [])
    if len(skills) > 3:
        awarded.append(f"+25: {len(skills)} skills listed (>3 threshold)")
        sections.append("Skills section")
    else:
        deducted.append(f"-25: Only {len(skills)} skills (need >3)")

    if resume.get("total_career_experience", 0) > 0:
        awarded.append("+20: Work experience present")
        sections.append("Experience section")
    else:
        deducted.append("-20: Missing work experience")

    if resume.get("education"):
        awarded.append("+15: Education section present")
        sections.append("Education section")
    else:
        deducted.append("-15: Missing education section")

    improvements = []
    if not resume.get("name") or not resume.get("email") or not resume.get("phone"):
        improvements.append("Add complete contact information (name, email, phone)")
    if len(skills) <= 3:
        improvements.append("Expand skills section with more relevant keywords")
    if not resume.get("education"):
        improvements.append("Add education section")
    if not resume.get("total_career_experience"):
        improvements.append("Add work experience with dates")

    return ScoreExplanation(
        category="ATS Compatibility",
        score=score,
        awarded_points="; ".join(awarded) if awarded else "No points awarded",
        deducted_points="; ".join(deducted) if deducted else "No points deducted",
        influencing_sections=sections,
        improvements=improvements,
    )


def explain_skill_match(score: float, matched: List[str], missing: List[str]) -> ScoreExplanation:
    improvements = []
    if missing:
        improvements.append(f"Add missing skills: {', '.join(missing[:5])}")
    return ScoreExplanation(
        category="Skill Match",
        score=score,
        awarded_points=f"Matched {len(matched)} skills from job requirements",
        deducted_points=f"Missing {len(missing)} required/preferred skills",
        influencing_sections=["Skills section", "Experience bullets"],
        improvements=improvements,
    )


def explain_experience_match(score: float, target_years: float, required_years: int) -> ScoreExplanation:
    return ScoreExplanation(
        category="Experience Match",
        score=score,
        awarded_points=f"{round(target_years, 1)} years of target role experience",
        deducted_points=f"Requires {required_years} years, candidate has {round(target_years, 1)} relevant years",
        influencing_sections=["Experience section"],
        improvements=[f"Gain {required_years - round(target_years, 1)} more years in target role"] if target_years < required_years else [],
    )


def explain_industry_match(score: float, target_industry_years: float, total_years: float) -> ScoreExplanation:
    return ScoreExplanation(
        category="Industry Match",
        score=score,
        awarded_points=f"{round(target_industry_years, 1)} years in target industry",
        deducted_points=f"Only {round(target_industry_years, 1)} of {total_years} total years are in target industry",
        influencing_sections=["Experience section"],
        improvements=["Gain more experience in the target industry"] if target_industry_years < total_years * 0.5 else [],
    )


def explain_education_match(score: float, matched: bool, required: List[Any]) -> ScoreExplanation:
    req_strings = []
    for req in required or []:
        if isinstance(req, str):
            req_strings.append(req)
        elif isinstance(req, dict):
            degree = req.get("degree") or req.get("field") or ""
            if degree:
                req_strings.append(str(degree))
        elif hasattr(req, "degree"):
            degree = getattr(req, "degree", "")
            if degree:
                req_strings.append(str(degree))

    req_strings = [r for r in req_strings if r]

    return ScoreExplanation(
        category="Education Match",
        score=score,
        awarded_points="Education meets requirements" if matched else "Partial education match",
        deducted_points="Education does not fully match requirements" if not matched else "No deductions",
        influencing_sections=["Education section"],
        improvements=[f"Consider relevant education in: {', '.join(req_strings[:3])}"] if (req_strings and not matched) else [],
    )


def explain_certification_match(score: float, matched: int, total: int) -> ScoreExplanation:
    return ScoreExplanation(
        category="Certification Match",
        score=score,
        awarded_points=f"Matched {matched} of {total} required certifications",
        deducted_points=f"Missing {total - matched} certifications" if matched < total else "All certifications matched",
        influencing_sections=["Certifications section", "Education section"],
        improvements=["Obtain missing certifications"] if matched < total else [],
    )


def explain_achievements(score: float, achievements: List[str]) -> ScoreExplanation:
    return ScoreExplanation(
        category="Achievement Score",
        score=score,
        awarded_points=f"{len(achievements)} quantified achievements found" if achievements else "Some achievements present",
        deducted_points="Limited quantified results" if len(achievements) < 3 else "No major deductions",
        influencing_sections=["Experience bullets", "Achievements section"],
        improvements=["Add more quantified achievements with metrics (%, $, numbers)"] if len(achievements) < 3 else [],
    )


def explain_resume_quality(score: float, resume: Dict[str, Any]) -> ScoreExplanation:
    improvements = []
    if not resume.get("name"):
        improvements.append("Add full name")
    if not resume.get("email"):
        improvements.append("Add professional email")
    skills = resume.get("skills", [])
    if len(skills) < 5:
        improvements.append("Expand skills section")
    if not resume.get("achievements"):
        improvements.append("Add achievements with metrics")
    return ScoreExplanation(
        category="Resume Quality",
        score=score,
        awarded_points="Well-structured resume with key sections present",
        deducted_points="Missing some standard sections or formatting improvements needed",
        influencing_sections=["Overall resume structure"],
        improvements=improvements,
    )


def generate_score_explanations(
    category_scores: CategoryScores,
    resume: Dict[str, Any],
    matched_skills: List[str],
    missing_skills: List[str],
    target_role_years: float,
    required_years: int,
    target_industry_years: float,
    certifications: List[str],
    required_certifications: List[str],
) -> List[ScoreExplanation]:
    explanations = [
        explain_ats_score(category_scores.ats_score, resume),
        explain_skill_match(category_scores.skill_match_score, matched_skills, missing_skills),
        explain_experience_match(category_scores.experience_match_score, target_role_years, required_years),
        explain_industry_match(category_scores.industry_match_score, target_industry_years, resume.get("total_career_experience", 0)),
        explain_education_match(category_scores.education_match_score, category_scores.education_match_score >= 80, resume.get("education", [])),
        explain_certification_match(category_scores.certification_match_score, len(certifications), len(required_certifications)),
        explain_achievements(category_scores.achievement_score, resume.get("achievements", [])),
        explain_resume_quality(category_scores.resume_quality_score, resume),
    ]
    return explanations
