"""
nlp_insights/

Additive NLP layer. Nothing here is imported by resume_parsing/ or
job_analyzer/ - those pipelines are untouched. This package only feeds
EXTRA signals into the new `tutor/` module, on top of the existing score.

Techniques added here (on top of the NER + TF-IDF + embeddings the
project already had):
  - Unsupervised keyword extraction (YAKE) - statistical, no training data,
    picks out the phrases that best characterize the resume text.
  - Readability scoring (Flesch Reading Ease / Flesch-Kincaid Grade) - a
    classic NLP text-quality metric, applied to resume writing style.
"""
