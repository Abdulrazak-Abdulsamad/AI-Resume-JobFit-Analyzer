"""
keyword_extractor.py (nlp_insights)

Unsupervised statistical keyword extraction using YAKE (Yet Another Keyword
Extractor). This is a DIFFERENT technique from the existing TF-IDF used in
job_analyzer/similarity.py: YAKE looks at single-document statistical
features (term position, frequency, context diversity, casing) rather than
corpus-wide document frequency, so it works well on a single resume where
TF-IDF has nothing to compare against.

Kept separate from resume_parsing/skill_extractor.py on purpose - that
module extracts TAXONOMY skills (a closed vocabulary); this extracts
free-form KEYPHRASES (open vocabulary), which is a genuinely different
signal useful for the tutor's narrative ("your resume emphasizes X, Y, Z").
"""
from __future__ import annotations

from typing import List

try:
    import yake
    _YAKE_AVAILABLE = True
except ImportError:  # pragma: no cover - degrade gracefully if not installed
    _YAKE_AVAILABLE = False


def extract_keywords(text: str, max_keywords: int = 12) -> List[str]:
    """
    Return the top statistically-significant keyphrases in `text`.

    Lower YAKE scores = more relevant, so results are already sorted best
    first. Falls back to an empty list (never raises) if YAKE isn't
    installed or the text is too short - the tutor prompt builder treats
    an empty keyword list as "skip this section".
    """
    text = (text or "").strip()
    if not text or not _YAKE_AVAILABLE:
        return []

    try:
        extractor = yake.KeywordExtractor(
            lan="en",
            n=2,                # up to 2-word phrases
            dedupLim=0.9,       # dedupe near-identical phrases
            top=max_keywords,
        )
        pairs = extractor.extract_keywords(text)
        # yake returns (keyword, score) tuples, lower score = better
        return [kw for kw, _score in sorted(pairs, key=lambda p: p[1])]
    except Exception:  # noqa: BLE001 - never let this break the tutor flow
        return []
