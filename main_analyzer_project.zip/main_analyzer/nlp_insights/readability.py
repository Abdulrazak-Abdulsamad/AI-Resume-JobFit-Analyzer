"""
readability.py (nlp_insights)

Classic NLP text-quality metrics applied to resume writing style, via
`textstat`. This is a new signal - nothing upstream currently scores HOW
the resume is written, only WHAT is in it (skills, dates, sections).

  - Flesch Reading Ease: 0-100, higher = easier to read.
  - Flesch-Kincaid Grade: approximate US school grade level needed to
    understand the text.

These feed the tutor's narrative (e.g. "your bullet points are dense/
technical - here's how a recruiter skimming for 6 seconds will read them")
and are never used to change the ATS score itself.
"""
from __future__ import annotations

from typing import Dict

try:
    import textstat
    _TEXTSTAT_AVAILABLE = True
except ImportError:  # pragma: no cover - degrade gracefully if not installed
    _TEXTSTAT_AVAILABLE = False


def score_readability(text: str) -> Dict[str, float]:
    """
    Return readability metrics for `text`. Returns an empty dict (never
    raises) if textstat isn't installed or the text is too short to score.
    """
    text = (text or "").strip()
    if not text or not _TEXTSTAT_AVAILABLE or len(text.split()) < 10:
        return {}

    try:
        return {
            "flesch_reading_ease": round(textstat.flesch_reading_ease(text), 1),
            "flesch_kincaid_grade": round(textstat.flesch_kincaid_grade(text), 1),
        }
    except Exception:  # noqa: BLE001 - never let this break the tutor flow
        return {}
