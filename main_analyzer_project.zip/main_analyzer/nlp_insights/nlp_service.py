"""
nlp_service.py (nlp_insights)

Single facade the tutor module calls into, so it doesn't need to know
about YAKE or textstat individually. Mirrors the existing project pattern
of one entry point per module (see job_analyzer/engine.py, etc.).
"""
from __future__ import annotations

from typing import Any, Dict

from nlp_insights.keyword_extractor import extract_keywords
from nlp_insights.readability import score_readability


def analyze_text(text: str) -> Dict[str, Any]:
    """
    Run every additive NLP technique over free-form resume/job text and
    return a plain dict ready to drop into an LLM prompt or JSON response.
    """
    return {
        "keywords": extract_keywords(text),
        "readability": score_readability(text),
    }
