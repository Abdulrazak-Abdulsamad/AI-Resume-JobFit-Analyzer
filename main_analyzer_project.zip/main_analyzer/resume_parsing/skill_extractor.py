"""
skill_extractor.py

Extracts skills mentioned in resume text using three passes, in order:
  1. Exact taxonomy lookup (fast, precise, whole-word match).
  2. Alias resolution (fast, precise, deterministic) - resolves common
     abbreviations ("JS", "EHR", "SEO", "WMS", ...) across every sector to
     their canonical taxonomy term. This runs BEFORE the fuzzy embedding
     pass because embedding similarity is unreliable for short acronyms:
     there isn't enough semantic signal in two or three letters for a
     general-purpose sentence embedding model to reliably land close to the
     right canonical phrase, so a deterministic lookup is both cheaper and
     more accurate for the cases it covers. See utils/skills_taxonomy.py
     for the alias map and the reasoning behind each entry.
  3. Embedding-based fuzzy matching against the taxonomy for anything
     passes 1-2 missed (catches synonyms/variants not covered by an
     explicit alias).

Uses the shared `EmbeddingService` (see services/embedding_service.py)
instead of loading its own SentenceTransformer instance, and the shared
`SKILL_TAXONOMY` (see utils/skills_taxonomy.py) so the Job Analyzer matches
skills against the exact same vocabulary the parser extracts. As of the
sector-coverage fix, that taxonomy spans every sector in the job database
(Information Technology, Healthcare, Business & Finance, Engineering,
Marketing & Sales, Education, Operations & Logistics), not just tech - so
passes 1-2 below now do meaningful work for every sector, not only IT.

Patterns for both the exact-match and alias passes are compiled once per
`SkillExtractor` instance (in `__init__`) rather than rebuilt on every
`extract_skills()` call - worth doing now that the taxonomy is ~2,000
entries rather than ~60, since re-building ~2,000 regexes per resume parsed
would be wasted, repeated work.
"""
from __future__ import annotations

import re
from typing import List, Pattern, Tuple

import numpy as np

from config import settings
from services.embedding_service import EmbeddingService, get_embedding_service
from utils.skills_taxonomy import SKILL_ALIASES, SKILL_TAXONOMY


def _compile_whole_word_pattern(term: str) -> Pattern[str]:
    return re.compile(r"\b" + re.escape(term.lower()) + r"\b")


class SkillExtractor:
    def __init__(self, embedding_service: EmbeddingService | None = None) -> None:
        self.embedding_service = embedding_service or get_embedding_service()
        self._taxonomy_embeddings = np.array(
            self.embedding_service.encode_many(SKILL_TAXONOMY)
        )

        # Precompiled (pattern, canonical_skill) pairs for the exact pass.
        self._exact_patterns: List[Tuple[Pattern[str], str]] = [
            (_compile_whole_word_pattern(skill), skill) for skill in SKILL_TAXONOMY
        ]

        # Precompiled (pattern, canonical_skill) pairs for the alias pass.
        # Longer alias keys are matched first (e.g. "pen testing" before a
        # hypothetical shorter overlapping key) so the most specific phrase
        # wins if two aliases could both match the same span.
        sorted_aliases = sorted(SKILL_ALIASES.items(), key=lambda kv: -len(kv[0]))
        self._alias_patterns: List[Tuple[Pattern[str], str]] = [
            (_compile_whole_word_pattern(alias), canonical)
            for alias, canonical in sorted_aliases
        ]

    def extract_skills(self, text: str, similarity_threshold: float | None = None) -> List[str]:
        threshold = similarity_threshold or settings.skill_extraction.similarity_threshold
        text_lower = text.lower()
        found_skills: set[str] = set()

        # 1. Exact taxonomy lookup.
        for pattern, skill in self._exact_patterns:
            if pattern.search(text_lower):
                found_skills.add(skill)

        # 2. Alias resolution (deterministic, covers every sector - see
        # utils/skills_taxonomy.py::SKILL_ALIASES). Runs regardless of
        # whether pass 1 already found the canonical term, which is
        # harmless (found_skills is a set) and keeps this pass simple.
        for pattern, canonical_skill in self._alias_patterns:
            if pattern.search(text_lower):
                found_skills.add(canonical_skill)

        # 3. Embedding-based fuzzy matching for anything passes 1-2 missed.
        # Note: words are stripped of surrounding punctuation BEFORE the
        # length check now (previously the length check ran on the
        # unstripped word, so e.g. "js," - 3 characters including the
        # comma - passed the filter while a bare "js" - 2 characters -
        # didn't, an inconsistency now moot in practice since "js" is
        # handled by the alias pass above, but fixed here for correctness
        # of the fuzzy pass generally).
        stripped_words = (w.strip(",.()") for w in text_lower.split())
        words = list({w for w in stripped_words if len(w) > 2})
        if words:
            word_embeddings = np.array(self.embedding_service.encode_many(words))
            similarity_matrix = _cosine_similarity(word_embeddings, self._taxonomy_embeddings)

            for idx, _word in enumerate(words):
                best_idx = int(np.argmax(similarity_matrix[idx]))
                best_score = float(similarity_matrix[idx][best_idx])
                if best_score >= threshold:
                    found_skills.add(SKILL_TAXONOMY[best_idx])

        return sorted(found_skills)


def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Lightweight cosine-similarity matrix, avoids pulling in sklearn here."""
    a_norm = a / (np.linalg.norm(a, axis=1, keepdims=True) + 1e-10)
    b_norm = b / (np.linalg.norm(b, axis=1, keepdims=True) + 1e-10)
    return a_norm @ b_norm.T
