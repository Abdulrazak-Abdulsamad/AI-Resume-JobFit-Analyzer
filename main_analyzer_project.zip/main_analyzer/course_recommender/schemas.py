"""
schemas.py (course_recommender)

Output data contracts for the Course Recommendation stage. Mirrors the style
of `job_analyzer/schemas.py`: plain pydantic models, no business logic.
"""
from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import BaseModel


class DifficultyLevel(str, Enum):
    BEGINNER = "Beginner"
    INTERMEDIATE = "Intermediate"
    ADVANCED = "Advanced"


class CourseRecommendation(BaseModel):
    """A single recommended learning resource for one missing skill."""

    skill: str
    course_title: str
    platform: str
    difficulty: DifficultyLevel
    estimated_duration: str
    url: str
    recommended_order: int
    skills_covered: List[str] = []
    certificate: bool = False
    reason: str = ""


class SkillCourseRecommendations(BaseModel):
    """All recommended courses for a single missing skill, already ordered."""

    skill: str
    courses: List[CourseRecommendation]


class RoadmapPhase(BaseModel):
    """One stage of the overall roadmap."""

    phase_number: int
    title: str
    objective: str
    difficulty: DifficultyLevel | None = None
    courses: List[CourseRecommendation] = []
    focus_skills: List[str] = []
    milestones: List[str] = []
    expected_outcome: str = ""


class LearningRoadmap(BaseModel):
    """
    The full personalized roadmap: every recommended course for every
    missing skill, grouped into dynamic phases.
    """

    phases: List[RoadmapPhase]
    skills_covered: List[str]
    total_courses: int


class CourseRecommendationBundle(BaseModel):
    """
    Everything the Course Recommendation stage produces for one job match:
    the per-skill recommendation lists plus the derived roadmap. Keeping
    both together avoids computing the roadmap twice (once for display,
    once for export) - DRY.
    """

    skill_recommendations: List[SkillCourseRecommendations]
    roadmap: LearningRoadmap
