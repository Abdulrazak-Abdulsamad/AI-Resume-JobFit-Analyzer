"""
recommender_service.py (course_recommender)

The single entry point the rest of the app should use for course
recommendations - mirrors the facade pattern already used by
`job_analyzer.engine.JobAnalyzer` and `services.resume_analysis_service`.

Workflow position:

    Skill Gap Detection -> **Course Recommendations** -> Learning Roadmap

Given the missing skills and target job profile, this service:
   1. Queries the course vector store via RAG to retrieve relevant courses.
   2. Wraps each raw course dict into a `CourseRecommendation`.
   3. Delegates roadmap assembly to `RoadmapBuilder`.
"""
from __future__ import annotations

from typing import List

from course_recommender.roadmap_builder import RoadmapBuilder
from course_recommender.schemas import (
    CourseRecommendation,
    CourseRecommendationBundle,
    SkillCourseRecommendations,
)
from rag.course_retriever import CourseRetriever
from utils.logging_config import get_logger

logger = get_logger(__name__)


class CourseRecommendationService:
    """Facade turning missing skills + job context into recommendations + a roadmap."""

    def __init__(
        self,
        course_retriever: CourseRetriever | None = None,
        roadmap_builder: RoadmapBuilder | None = None,
    ) -> None:
        self.course_retriever = course_retriever or CourseRetriever()
        self.roadmap_builder = roadmap_builder or RoadmapBuilder()

    def recommend_for_job(
        self,
        job_title: str = "",
        sector: str = "",
        missing_skills: List[str] | None = None,
        experience_years: int = 0,
    ) -> CourseRecommendationBundle:
        """
        Build the full recommendation bundle (per-skill courses + roadmap)
        for the given job profile and missing skills, using RAG retrieval.
        """
        if not missing_skills:
            logger.info("No missing skills detected; skipping course recommendations.")
            return CourseRecommendationBundle(
                skill_recommendations=[],
                roadmap=self.roadmap_builder.build([]),
            )

        retrieved_courses = self.course_retriever.retrieve_courses(
            job_title=job_title,
            sector=sector,
            missing_skills=missing_skills,
            experience_years=experience_years,
        )

        seen_titles = set()
        unique_courses = []
        for course in retrieved_courses:
            title = course.get("title", "")
            if title and title not in seen_titles:
                seen_titles.add(title)
                unique_courses.append(course)

        skill_recommendations: List[SkillCourseRecommendations] = []
        skill_course_map: dict[str, List[dict]] = {}

        for course in unique_courses:
            for skill in course.get("skills_covered", []):
                sk_lower = skill.strip().lower()
                if sk_lower not in skill_course_map:
                    skill_course_map[sk_lower] = []
                skill_course_map[sk_lower].append(course)

        for skill in missing_skills:
            sk_lower = skill.strip().lower()
            matching_courses = skill_course_map.get(sk_lower, [])

            # Fall back to curated course catalog if vector store yielded no match
            if not matching_courses:
                from course_recommender.course_catalog import get_courses_for_skill
                raw_catalog = get_courses_for_skill(skill)
                matching_courses = [
                    {
                        "title": c["course_title"],
                        "provider": c["platform"],
                        "difficulty": c["difficulty"],
                        "duration": c["estimated_duration"],
                        "url": c["url"],
                        "skills_covered": [skill],
                    }
                    for c in raw_catalog
                ]

            courses = [
                CourseRecommendation(
                    skill=skill,
                    course_title=c.get("title", c.get("course_title", "Course")),
                    platform=c.get("provider", c.get("platform", "Coursera")),
                    difficulty=c.get("difficulty", "Beginner"),
                    estimated_duration=c.get("duration", c.get("estimated_duration", "Varies")),
                    url=c.get("url", "#"),
                    recommended_order=order + 1,
                    skills_covered=c.get("skills_covered", [skill]),
                    certificate=c.get("certificate", False),
                    reason=self._generate_reason(c, skill, job_title, sector),
                )
                for order, c in enumerate(matching_courses[:3])
            ]
            skill_recommendations.append(SkillCourseRecommendations(skill=skill, courses=courses))

        all_courses = [c for group in skill_recommendations for c in group.courses]
        roadmap = self.roadmap_builder.build(skill_recommendations, all_courses)

        return CourseRecommendationBundle(
            skill_recommendations=skill_recommendations,
            roadmap=roadmap,
        )

    def recommend_for_missing_skills(self, missing_skills: List[str]) -> CourseRecommendationBundle:
        """
        Backward-compatible wrapper for `recommend_for_job` when only missing
        skills are available (no job context). Uses generic query text.
        """
        return self.recommend_for_job(
            job_title="",
            sector="",
            missing_skills=missing_skills,
            experience_years=0,
        )

    @staticmethod
    def _generate_reason(course: dict, skill: str, job_title: str, sector: str) -> str:
        reasons = []
        target_roles = course.get("target_roles", [])
        if job_title:
            if any(role.lower() == job_title.lower() for role in target_roles):
                reasons.append(f"directly aligned with {job_title}")
            elif any(role.lower() in job_title.lower() or job_title.lower() in role.lower() for role in target_roles):
                reasons.append(f"relevant to {job_title}")

        if sector and any(s.lower() == sector.lower() for s in course.get("target_sectors", [])):
            reasons.append(f"targeted for the {sector} sector")

        covered = course.get("skills_covered", [])
        if skill in covered:
            reasons.append(f"covers the missing skill '{skill}'")

        if course.get("certificate"):
            reasons.append("includes a professional certificate")

        difficulty = course.get("difficulty", "")
        if difficulty == "Beginner":
            reasons.append("beginner-friendly pacing")
        elif difficulty == "Advanced":
            reasons.append("advanced-level depth")

        if reasons:
            return "Selected because it is " + ", ".join(reasons) + "."
        return f"Selected to help you learn {skill} for your target role."


def get_course_recommendation_service() -> CourseRecommendationService:
    """Factory kept for symmetry with the rest of the app's service getters."""
    return CourseRecommendationService()
