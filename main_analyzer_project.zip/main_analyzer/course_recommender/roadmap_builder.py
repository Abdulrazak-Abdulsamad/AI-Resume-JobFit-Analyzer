"""
roadmap_builder.py (course_recommender)

Turns a flat collection of per-skill course recommendations into a single
ordered `LearningRoadmap`: dynamically groups courses into phases based on
difficulty, content type, and learning progression.

Phases are generated dynamically based on the retrieved courses:
  - Phase 1: Foundation (Beginner courses for fundamental skills)
  - Phase 2: Core Skills (Intermediate courses for core technical skills)
  - Phase 3: Advanced Skills (Advanced courses for specialized topics)
  - Phase 4: Practical Projects (Project-focused learning)
  - Phase 5: Certification & Interview Preparation (Cert courses + interview prep)

Phases with no courses are automatically skipped, so the roadmap adapts to
any job role or skill set without hardcoded industry-specific logic.
"""
from __future__ import annotations

from typing import List

from course_recommender.schemas import (
    CourseRecommendation,
    DifficultyLevel,
    LearningRoadmap,
    RoadmapPhase,
    SkillCourseRecommendations,
)


def _phase_sort_key(course: CourseRecommendation) -> tuple:
    return (course.skill.lower(), course.recommended_order)


def _make_phase(
    phase_number: int,
    title: str,
    objective: str,
    difficulty: DifficultyLevel | None,
    courses: List[CourseRecommendation],
    milestone_fn,
    expected_outcome: str,
) -> RoadmapPhase:
    """Build one `RoadmapPhase`, deriving its focus skills from its courses
    and its milestones from `milestone_fn(focus_skills)`. Shared by every
    phase definition below so a phase's shape only has to be described once."""
    focus_skills = list({c.skill for c in courses})
    return RoadmapPhase(
        phase_number=phase_number,
        title=title,
        objective=objective,
        difficulty=difficulty,
        courses=courses,
        focus_skills=focus_skills,
        milestones=milestone_fn(focus_skills),
        expected_outcome=expected_outcome,
    )


class RoadmapBuilder:
    @staticmethod
    def build(
        skill_recommendations: List[SkillCourseRecommendations],
        all_courses: List[CourseRecommendation] | None = None,
    ) -> LearningRoadmap:
        if all_courses is None:
            all_courses = [
                course for group in skill_recommendations for course in group.courses
            ]

        if not all_courses:
            return LearningRoadmap(
                phases=[],
                skills_covered=[],
                total_courses=0,
            )

        skills_covered = list({group.skill for group in skill_recommendations})

        beginner = sorted(
            [c for c in all_courses if c.difficulty == DifficultyLevel.BEGINNER], key=_phase_sort_key
        )
        intermediate = sorted(
            [c for c in all_courses if c.difficulty == DifficultyLevel.INTERMEDIATE], key=_phase_sort_key
        )
        advanced = sorted(
            [c for c in all_courses if c.difficulty == DifficultyLevel.ADVANCED], key=_phase_sort_key
        )
        project_courses = [c for c in all_courses if _is_project_course(c)]
        cert_courses = [c for c in all_courses if _is_certification_course(c)]

        # Each entry describes one potential roadmap phase: its course list,
        # and how to phrase milestones from that phase's focus skills. Phases
        # whose course list is empty are skipped, so the roadmap adapts to
        # whatever courses were actually retrieved.
        phase_definitions = [
            (
                "Foundation",
                "Build fundamental knowledge and core concepts required for the target role.",
                DifficultyLevel.BEGINNER,
                beginner,
                lambda skills: [f"Complete all beginner courses for {skill}" for skill in skills[:5]],
                "Solid grasp of fundamental concepts and terminology.",
            ),
            (
                "Core Skills",
                "Develop intermediate proficiency in the core technical skills for the target role.",
                DifficultyLevel.INTERMEDIATE,
                intermediate,
                lambda skills: [f"Complete intermediate coursework for {skill}" for skill in skills[:5]],
                "Hands-on competence with core tools, frameworks, and workflows.",
            ),
            (
                "Advanced Skills",
                "Master advanced topics and specialized skills that distinguish top candidates.",
                DifficultyLevel.ADVANCED,
                advanced,
                lambda skills: [f"Complete advanced training for {skill}" for skill in skills[:5]],
                "Deep expertise in advanced concepts and production-grade practices.",
            ),
            (
                "Practical Projects",
                "Apply learned skills through hands-on projects to build a strong portfolio.",
                None,
                project_courses,
                lambda skills: [f"Complete portfolio project using {skill}" for skill in skills[:5]],
                "Portfolio-ready projects demonstrating practical application of skills.",
            ),
            (
                "Certification & Interview Preparation",
                "Earn industry-recognized certifications and prepare for job interviews.",
                None,
                cert_courses,
                lambda skills: [f"Obtain certification for {skill}" for skill in skills[:5]]
                + ["Practice behavioral and technical interview questions", "Prepare resume and LinkedIn profile"],
                "Industry credentials and interview readiness for the target role.",
            ),
        ]

        phases: List[RoadmapPhase] = []
        for title, objective, difficulty, phase_courses, milestone_fn, expected_outcome in phase_definitions:
            if not phase_courses:
                continue
            phases.append(_make_phase(
                phase_number=len(phases) + 1,
                title=title,
                objective=objective,
                difficulty=difficulty,
                courses=phase_courses,
                milestone_fn=milestone_fn,
                expected_outcome=expected_outcome,
            ))

        return LearningRoadmap(
            phases=phases,
            skills_covered=skills_covered,
            total_courses=len(all_courses),
        )


def _is_project_course(course: CourseRecommendation) -> bool:
    title_lower = course.course_title.lower()
    return any(keyword in title_lower for keyword in [
        "project", "portfolio", "build", "create", "develop", "hands-on",
        "practical", "real-world", "capstone",
    ])


def _is_certification_course(course: CourseRecommendation) -> bool:
    title_lower = course.course_title.lower()
    return any(keyword in title_lower for keyword in [
        "certificate", "certification", "certified", "prep", "interview",
    ])
