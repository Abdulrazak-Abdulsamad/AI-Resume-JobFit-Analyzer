# AI Tutor Setup (new, additive feature)

Nothing existing was changed - the pipeline (Resume Parsing -> RAG ->
Job Analyzer -> Course Recommender) runs exactly as before. This adds:

- `tutor/` - LLM tutor: personalized explanation + chat, on top of the
  existing analysis JSON.
- `nlp_insights/` - two new NLP techniques (YAKE keyword extraction,
  Flesch readability scoring) that feed the tutor.
- Two new backend routes, mounted with one added line in `api.py`:
  `POST /api/tutor/explain`, `POST /api/tutor/chat`.
- One new frontend tab ("AI Tutor") in the existing Dashboard tab bar.

## 1. Install the new dependencies

```bash
pip install requests yake textstat --break-system-packages   # or just: pip install -r requirements.txt
```

## 2. Local LLM Setup (Ollama / LM Studio)

The AI Tutor module connects to a local LLM running on your system (no cloud API keys needed):

1. **Ensure Ollama or your preferred local LLM server is running:**
   ```bash
   ollama serve
   ollama run llama3.1   # or your preferred model
   ```
2. **(Optional) Override local settings via environment variables:**
   - `TUTOR_LLM_BASE_URL`: default is `http://localhost:11434/v1` (Ollama OpenAI-compatible endpoint)
   - `TUTOR_LLM_MODEL`: default is `llama3.1`

   ```bash
   export TUTOR_LLM_BASE_URL="http://localhost:11434/v1"
   export TUTOR_LLM_MODEL="llama3.1"
   ```

## 3. Run as usual

```bash
./run_backend.sh    # or: uvicorn api:app --reload
./run_frontend.sh
```

Open the app, run an analysis, and click the **"AI Tutor"** tab.

## If the local LLM is unreachable

If your local LLM server is not running on `http://localhost:11434`, the tutor endpoints return a clean `503` explaining that the local LLM server could not be reached — it won't crash the rest of the app, and the main analysis flow (`/api/analyze`) continues to work normally.

## For your write-up

- **LLM tutor**: `/api/tutor/explain` turns the existing score/skill-gap/
  experience JSON into a grounded natural-language narrative (the LLM is
  only allowed to reference facts present in that JSON - see
  `tutor/prompt_builder.py`). `/api/tutor/chat` holds a multi-turn
  conversation with the same JSON as context.
- **New NLP techniques**: `nlp_insights/keyword_extractor.py` (YAKE -
  unsupervised statistical keyphrase extraction, different from the
  existing TF-IDF since it works on a single document) and
  `nlp_insights/readability.py` (Flesch Reading Ease / Flesch-Kincaid
  Grade). Both are on top of the resume parser's existing spaCy NER,
  TF-IDF, and sentence-embedding pipeline - nothing there changed.
