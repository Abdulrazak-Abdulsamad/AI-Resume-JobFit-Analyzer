import sys
from pptx import Presentation

def update_presentation():
    # Load the exact template presentation provided by the user
    template_path = 'C:/Users/adams/Downloads/Final_AI_Resume_Analyzer.pptx'
    prs = Presentation(template_path)

    # 10-Speaker Notes Scripts (1 Minute / 60 seconds per speaker)
    speaker_notes = [
        "Speaker 1 Pitch (1 Min / 60s):\n- Welcome everyone! We present the AI Resume Analyzer & Local AI Tutor.\n- Matching a resume to a job is usually a black box. Our system turns that guesswork into an explainable per-category score for candidates, recruiters, and hiring teams alike.\n- Best of all, it runs 100% offline using local LLMs (Ollama / LLaMA 3.1) for total privacy.",
        "Speaker 2 Pitch (1 Min / 60s):\n- Our application runs across a 7-stage unified pipeline.\n- From raw PDF/DOCX resume file upload ➔ spaCy NER parsing ➔ ChromaDB RAG job retrieval ➔ 8-category ATS scoring ➔ skill gap detection ➔ upskilling course recommendations ➔ interactive local AI Tutor.",
        "Speaker 3 Pitch (1 Min / 60s):\n- Here is our complete end-to-end information flow.\n- Every arrow represents a real module boundary in the codebase: resume_parsing ➔ rag ➔ job_analyzer ➔ course_recommender ➔ tutor.\n- Each stage exposes a single facade entry point for clean, decoupled architecture.",
        "Speaker 4 Pitch (1 Min / 60s):\n- Our AI capabilities rely on grounded RAG retrieval with zero cloud dependencies.\n- We use a shared SentenceTransformer singleton ('all-MiniLM-L6-v2') cached in RAM to power ChromaDB vector retrieval.\n- Scores are transparently itemized with awarded and deducted points linked to candidate resume sections.",
        "Speaker 5 Pitch (1 Min / 60s):\n- Candidate fit is calculated across an 8-category weighted scoring model.\n- Skills match (30%) and experience match (25%) form 55% of the headline signal.\n- Seniority is determined by responsibility level, project scope, and leadership signals—not raw years of experience alone.",
        "Speaker 6 Pitch (1 Min / 60s):\n- Here is our under-the-hood architecture: React SPA frontend communicating with a FastAPI REST backend (api.py).\n- The backend mounts specialized modules including tutor/ (Ollama LLaMA 3.1) and nlp_insights/ (YAKE keyphrases & Flesch readability).\n- Everything runs locally without external cloud API keys.",
        "Speaker 7 Pitch (1 Min / 60s):\n- Candidates experience a seamless five-screen journey: Landing ➔ Upload Resume ➔ Select Target Role ➔ Analyzing ➔ Results Dashboard + AI Tutor.\n- The analysis runs live, generating transparent category breakdowns and personalized upskilling roadmaps.",
        "Speaker 8 Pitch (1 Min / 60s):\n- Inside the Results Dashboard, candidates see score gauges, category radar charts, strengths, weaknesses, and course roadmaps.\n- With our new AI Tutor tab, candidates can chat directly with local LLaMA 3.1 to ask follow-up questions about their match results.",
        "Speaker 9 Pitch (1 Min / 60s):\n- Why is our solution different?\n- 100% Offline Local AI Tutor via Ollama LLaMA 3.1, unsupervised YAKE keyphrase extraction, Flesch readability scoring, explainable ATS points, and dynamic dynamic course roadmaps.",
        "Speaker 10 Pitch (1 Min / 60s):\n- In summary: Every fit score should explain itself.\n- Our application is fully verified, operational, and runs 100% offline with zero cloud API costs.\n- Thank you for your time, and we open the floor for any questions!"
    ]

    # Specific text updates for slides to ensure all new features (AI Tutor, Ollama, LLaMA 3.1, YAKE, Flesch) are explicitly covered
    slide_updates = {
        0: { # Slide 1
            3: "Matching a resume to a job is usually a black box. This tool turns that guesswork into an explainable, per-category score and interactive Local AI Tutor — 100% offline and private.",
            14: "AI Resume Analyzer & Local AI Tutor  |  Product Overview"
        },
        1: { # Slide 2
            1: "Seven stages, one pipeline",
            2: "From raw resume file to a personalized learning plan and interactive Local AI Tutor.",
            25: "Local AI Tutor",
            26: "Interactive Q&A powered by local Ollama & LLaMA 3.1."
        },
        2: { # Slide 3
            44: "Every arrow is a real module boundary in the codebase (resume_parsing, rag, job_analyzer, course_recommender, tutor, nlp_insights) — each stage has a clean facade entry point."
        },
        3: { # Slide 4
            6: "Shared embedding model: all-MiniLM-L6-v2  +  ChromaDB  +  Local Ollama LLaMA 3.1",
            62: "Recommendations and tutor responses are grounded in real local data — 100% private with zero external cloud API keys."
        },
        5: { # Slide 6
            9: "FastAPI Backend  —  api.py",
            10: "GET /api/health   ·   POST /api/analyze   ·   POST /api/tutor/explain   ·   POST /api/tutor/chat"
        },
        7: { # Slide 8
            14: "AI Tutor",
            141: "Interactive Q&A with local LLaMA 3.1."
        },
        8: { # Slide 9
            4: "100% Offline Local AI Tutor",
            5: "Interactive Q&A powered by local Ollama server (LLaMA 3.1) — zero cloud API keys required.",
            12: "NLP Insights: YAKE & Readability",
            13: "Statistical YAKE keyphrase extraction and Flesch readability scoring ground candidate feedback."
        },
        9: { # Slide 10
            4: "That's what the AI Resume Analyzer & Local AI Tutor delivers: grounded RAG retrieval, transparent category scoring, YAKE insights, and a 100% offline conversational tutor."
        }
    }

    # Apply slide updates and speaker notes
    for i, slide in enumerate(prs.slides):
        # Update text frames if specified
        if i in slide_updates:
            updates = slide_updates[i]
            for shape_idx, shape in enumerate(slide.shapes):
                if shape_idx in updates and shape.has_text_frame:
                    shape.text_frame.text = updates[shape_idx]

        # Attach Speaker Notes
        if i < len(speaker_notes):
            notes_slide = slide.notes_slide
            text_frame = notes_slide.notes_text_frame
            text_frame.text = speaker_notes[i]

    # Save updated presentation
    output_path1 = 'C:/Users/adams/Downloads/main_analyzer_with_tutor/main_analyzer_with_tutor/main_analyzer/AI_Resume_Analyzer_Presentation.pptx'
    output_path2 = 'C:/Users/adams/Downloads/Final_AI_Resume_Analyzer_Updated.pptx'

    prs.save(output_path1)
    prs.save(output_path2)
    print(f"Updated presentation saved to:\n  1. {output_path1}\n  2. {output_path2}")

if __name__ == '__main__':
    update_presentation()
