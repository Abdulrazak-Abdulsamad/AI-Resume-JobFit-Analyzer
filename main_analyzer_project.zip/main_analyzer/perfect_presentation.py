import sys
import pptx

def update_runs_in_shape(shape, old_text_substr, new_text):
    if not shape.has_text_frame:
        return False
    tf = shape.text_frame
    for p in tf.paragraphs:
        full_p_text = ''.join(r.text for r in p.runs) or p.text
        if old_text_substr in full_p_text:
            if len(p.runs) > 0:
                p.runs[0].text = new_text
                for r in p.runs[1:]:
                    r.text = ""
            else:
                p.text = new_text
            return True
    return False

def replace_exact_text_in_shape(shape, exact_text, new_text):
    if not shape.has_text_frame:
        return False
    tf = shape.text_frame
    for p in tf.paragraphs:
        full_p_text = ''.join(r.text for r in p.runs) or p.text
        if full_p_text.strip() == exact_text.strip():
            if len(p.runs) > 0:
                p.runs[0].text = new_text
                for r in p.runs[1:]:
                    r.text = ""
            else:
                p.text = new_text
            return True
    return False

def build_perfect_presentation():
    template_path = 'C:/Users/adams/Downloads/Final_AI_Resume_Analyzer.pptx'
    prs = pptx.Presentation(template_path)

    # 10-Speaker 60-Second Notes Scripts
    speaker_notes = [
        "Speaker 1 Pitch (1 Min / 60s):\n- Welcome everyone! We present the AI Resume Analyzer & Local AI Tutor.\n- Matching a resume to a job is usually a black box. Our system turns that guesswork into an explainable per-category score for candidates, recruiters, and hiring teams alike.\n- Best of all, it runs 100% offline using local LLMs (Ollama / LLaMA 3.1) for total privacy.",

        "Speaker 2 Pitch (1 Min / 60s):\n- Our application runs across a 7-stage unified pipeline.\n- From raw PDF/DOCX resume file upload -> spaCy NER parsing -> ChromaDB RAG job retrieval -> 8-category ATS scoring -> skill gap detection -> upskilling course recommendations -> interactive local AI Tutor.",

        "Speaker 3 Pitch (1 Min / 60s):\n- Here is our complete end-to-end information flow.\n- Every arrow represents a real module boundary in the codebase: resume_parsing -> rag -> job_analyzer -> course_recommender -> tutor -> nlp_insights.\n- Each stage exposes a single facade entry point for clean, decoupled architecture.",

        "Speaker 4 Pitch (1 Min / 60s):\n- Our AI capabilities rely on grounded RAG retrieval with zero cloud dependencies.\n- We use a shared SentenceTransformer singleton ('all-MiniLM-L6-v2') cached in RAM to power ChromaDB vector retrieval.\n- Scores are transparently itemized with awarded and deducted points linked to candidate resume sections.",

        "Speaker 5 Pitch (1 Min / 60s):\n- Candidate fit is calculated across an 8-category weighted scoring model.\n- Skills match (30%) and experience match (25%) form 55% of the headline signal.\n- Seniority is determined by responsibility level, project scope, and leadership signals—not raw years of experience alone.",

        "Speaker 6 Pitch (1 Min / 60s):\n- Here is our under-the-hood architecture: React SPA frontend communicating with a FastAPI REST backend (api.py).\n- The backend mounts specialized modules including tutor/ (Ollama LLaMA 3.1) and nlp_insights/ (YAKE keyphrases & Flesch readability).\n- Everything runs locally without external cloud API keys.",

        "Speaker 7 Pitch (1 Min / 60s):\n- Candidates experience a seamless five-screen journey: Landing -> Upload Resume -> Select Target Role -> Analyzing -> Results Dashboard + AI Tutor.\n- The analysis runs live, generating transparent category breakdowns and personalized upskilling roadmaps.",

        "Speaker 8 Pitch (1 Min / 60s):\n- Inside the Results Dashboard, candidates see score gauges, category radar charts, strengths, weaknesses, and course roadmaps.\n- With our new AI Tutor tab, candidates can chat directly with local LLaMA 3.1 to ask follow-up questions about their match results.",

        "Speaker 9 Pitch (1 Min / 60s):\n- Why is our solution different?\n- 100% Offline Local AI Tutor via Ollama LLaMA 3.1, unsupervised YAKE keyphrase extraction, Flesch readability scoring, explainable ATS points, and dynamic course roadmaps.",

        "Speaker 10 Pitch (1 Min / 60s):\n- In summary: Every fit score should explain itself.\n- Our application is fully verified, operational, and runs 100% offline with zero cloud API costs.\n- Thank you for your time, and we open the floor for any questions!"
    ]

    # Slide 1 modifications
    slide1 = prs.slides[0]
    for shape in slide1.shapes:
        if shape.has_text_frame:
            replace_exact_text_in_shape(shape, "AI RESUME ANALYZER", "AI RESUME ANALYZER & LOCAL AI TUTOR")
            replace_exact_text_in_shape(shape, "Resume-to-job fit, scored transparently.", "Resume-to-job fit, scored transparently with 100% local AI tutoring.")
            update_runs_in_shape(shape, "Matching a resume to a job is usually a black box.", "Matching a resume to a job is usually a black box. This tool turns that guesswork into an explainable score — plus an interactive Local AI Tutor (LLaMA 3.1) for candidates, recruiters, and hiring teams.")
            update_runs_in_shape(shape, "AI Resume Analyzer  |  Product Overview", "AI Resume Analyzer & Local AI Tutor  |  Product Overview")

    # Slide 2 modifications
    slide2 = prs.slides[1]
    for shape in slide2.shapes:
        if shape.has_text_frame:
            replace_exact_text_in_shape(shape, "Six stages, one pipeline", "Seven stages, one unified pipeline")
            replace_exact_text_in_shape(shape, "From raw resume file to a personalized learning plan.", "From raw resume file to a personalized learning plan and Local AI Tutor.")

    # Slide 3 modifications
    slide3 = prs.slides[2]
    for shape in slide3.shapes:
        if shape.has_text_frame:
            update_runs_in_shape(shape, "Every arrow is a real module boundary", "Every arrow is a real module boundary in the codebase (resume_parsing, rag, job_analyzer, course_recommender, tutor, nlp_insights) — each stage has a clean facade entry point.")

    # Slide 4 modifications
    slide4 = prs.slides[3]
    for shape in slide4.shapes:
        if shape.has_text_frame:
            replace_exact_text_in_shape(shape, "Shared embedding model: all-MiniLM-L6-v2  +  ChromaDB", "Shared embedding model: all-MiniLM-L6-v2  +  ChromaDB  +  Local Ollama LLaMA 3.1")
            update_runs_in_shape(shape, "Recommendations are always sourced from real, current data", "Recommendations and tutor responses are always sourced from real local data and local LLMs — 100% private with zero cloud API keys.")

    # Slide 5 modifications
    slide5 = prs.slides[4]
    for shape in slide5.shapes:
        if shape.has_text_frame:
            update_runs_in_shape(shape, "The remaining six categories add nuance", "The remaining six categories add nuance, complemented by YAKE keyphrase extraction and Flesch readability scoring.")

    # Slide 6 modifications
    slide6 = prs.slides[5]
    for shape in slide6.shapes:
        if shape.has_text_frame:
            replace_exact_text_in_shape(shape, "GET /api/health   ·   POST /api/analyze", "GET /api/health  ·  POST /api/analyze  ·  POST /api/tutor/explain  ·  POST /api/tutor/chat")
            replace_exact_text_in_shape(shape, "course_recommender/", "course_recommender/  ·  tutor/  ·  nlp_insights/")

    # Slide 7 modifications
    slide7 = prs.slides[6]
    for shape in slide7.shapes:
        if shape.has_text_frame:
            replace_exact_text_in_shape(shape, "Results Dashboard", "Results Dashboard & AI Tutor")
            replace_exact_text_in_shape(shape, "Scores, gaps, courses, and roadmap.", "Scores, gaps, courses, roadmap, and AI Tutor Q&A.")

    # Slide 8 modifications
    slide8 = prs.slides[7]
    for shape in slide8.shapes:
        if shape.has_text_frame:
            update_runs_in_shape(shape, "Wireframe of the actual Dashboard.jsx layout", "Wireframe of Dashboard.jsx — tabs, gauges, radar chart, summary cards, and AI Tutor panel render live data with zero mock content.")

    # Slide 9 modifications
    slide9 = prs.slides[8]
    for shape in slide9.shapes:
        if shape.has_text_frame:
            replace_exact_text_in_shape(shape, "Explainable, per-category scoring", "Explainable scoring & Local AI Tutor")
            replace_exact_text_in_shape(shape, "Every category shows awarded and deducted points, not just a final number.", "Every category shows awarded points, plus an interactive Local AI Tutor (Ollama LLaMA 3.1) for follow-up Q&A.")
            replace_exact_text_in_shape(shape, "Dual RAG grounding", "Dual RAG & NLP Insights")
            replace_exact_text_in_shape(shape, "Jobs and courses are each retrieved through their own RAG pipeline, sharing one embedding model.", "Jobs and courses are retrieved via RAG, enriched by YAKE keyphrases and Flesch readability scores.")

    # Slide 10 modifications
    slide10 = prs.slides[9]
    for shape in slide10.shapes:
        if shape.has_text_frame:
            update_runs_in_shape(shape, "That's what the AI Resume Analyzer delivers", "That's what the AI Resume Analyzer & Local AI Tutor delivers: grounded RAG retrieval, transparent category scoring, YAKE keyphrases, and a 100% offline conversational tutor.")

    # Attach Presenter Notes to each slide
    for i, slide in enumerate(prs.slides):
        if i < len(speaker_notes):
            notes_slide = slide.notes_slide
            text_frame = notes_slide.notes_text_frame
            text_frame.text = speaker_notes[i]

    # Save to both locations
    out1 = 'C:/Users/adams/Downloads/Final_AI_Resume_Analyzer_Updated.pptx'
    out2 = 'C:/Users/adams/Downloads/main_analyzer_with_tutor/main_analyzer_with_tutor/main_analyzer/AI_Resume_Analyzer_Presentation.pptx'

    prs.save(out1)
    prs.save(out2)
    print(f"Perfect presentation generated and saved to:\n  1. {out1}\n  2. {out2}")

if __name__ == '__main__':
    build_perfect_presentation()
