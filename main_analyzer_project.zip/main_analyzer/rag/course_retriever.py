"""
course_retriever.py

Turns a skill-gap analysis + target job profile into a query embedding and
retrieves the most relevant courses from the course vector store.

This is the ONLY way the Course Recommender is allowed to obtain course
information (per the integration requirement that course data flows exclusively
through the RAG pipeline).

For each retrieved match, the authoritative structured fields
(skills_covered, difficulty, certificate, url) are re-fetched from the
CourseRepository by course_id - the vector store's metadata is used only to
identify *which* course matched, never as the source of truth for its data.
"""
from __future__ import annotations

from typing import Any, Dict, List

from config import settings
from database.course_repository import CourseRepository, get_course_repository
from rag.vector_store import VectorStoreManager, build_course_document
from services.embedding_service import EmbeddingService, get_embedding_service
from utils.logging_config import get_logger

logger = get_logger(__name__)


def _course_result(course_record: Dict[str, Any], similarity_score: float, fallback_skill: str | None = None) -> Dict[str, Any]:
    """
    Build the standard course-result dict returned to callers, pulling every
    field from the authoritative `course_record` (falling back to sensible
    defaults). Shared by every place `CourseRetriever` produces a result so
    the same dict shape doesn't have to be re-typed at each call site.
    """
    return {
        "course_id": course_record.get("id"),
        "title": course_record.get("title", "Unknown Course"),
        "provider": course_record.get("provider", "Unknown"),
        "skills_covered": course_record.get("skills_covered", [fallback_skill] if fallback_skill else []),
        "difficulty": course_record.get("difficulty", "Beginner"),
        "duration": course_record.get("duration", "Varies"),
        "url": course_record.get("url", "#"),
        "certificate": course_record.get("certificate", False),
        "description": course_record.get("description", ""),
        "target_roles": course_record.get("target_roles", []),
        "target_sectors": course_record.get("target_sectors", []),
        "similarity_score": similarity_score,
    }


class CourseRetriever:
    """Retrieves the most relevant course(s) for a given skill gap and job profile."""

    def __init__(
        self,
        vector_store: VectorStoreManager | None = None,
        course_repository: CourseRepository | None = None,
        embedding_service: EmbeddingService | None = None,
    ) -> None:
        self.vector_store = vector_store or VectorStoreManager()
        self.course_repository = course_repository or get_course_repository()
        self.embedding_service = embedding_service or getattr(self.vector_store, 'embedding_service', None) or get_embedding_service()

    @staticmethod
    def _skill_gap_to_query_text(
        job_title: str = "",
        sector: str = "",
        missing_skills: List[str] | None = None,
        experience_years: int = 0,
    ) -> str:
        """Flatten skill gap + job context into a single descriptive text block used
        as the semantic search query."""
        skills_text = ", ".join(missing_skills or [])
        experience_level = "Junior"
        if experience_years >= 5:
            experience_level = "Senior"
        elif experience_years >= 3:
            experience_level = "Mid"
        elif experience_years >= 1:
            experience_level = "Entry"

        return "\n".join([
            f"Target Job: {job_title or 'Unknown'}",
            f"Target Sector: {sector or 'Unknown'}",
            f"Missing Skills: {skills_text or 'None specified'}",
            f"Candidate Experience Level: {experience_level} ({experience_years} years)",
        ])

    def retrieve_courses(
        self,
        job_title: str = "",
        sector: str = "",
        missing_skills: List[str] | None = None,
        experience_years: int = 0,
        top_k: int | None = None,
    ) -> List[Dict[str, Any]]:
        """Query the course vector store for the top-K courses matching this skill gap."""
        top_k = top_k or getattr(getattr(settings, 'retrieval', None), 'top_k', 6) or 6
        query_text = self._skill_gap_to_query_text(job_title, sector, missing_skills, experience_years)
        query_vector = self.embedding_service.encode(query_text)

        results = self.vector_store.course_collection.query(
            query_embeddings=[query_vector],
            n_results=top_k,
        )

        retrieved: List[Dict[str, Any]] = []
        metadatas = (results.get("metadatas") or [[]])[0]
        distances = (results.get("distances") or [[]])[0]

        for i, metadata in enumerate(metadatas):
            course_id = metadata.get("course_id", f"course_{i + 1}")
            course_record = self.course_repository.get_by_id(course_id) or {}

            distance = distances[i] if i < len(distances) else 0.0
            similarity_score = round(1.0 / (1.0 + float(distance)), 3)

            result = _course_result(course_record, similarity_score)
            # The metadata title/provider are only used when the record
            # itself came back empty (job_record fell through to `{}`).
            result["title"] = course_record.get("title", metadata.get("title", "Unknown Course"))
            result["provider"] = course_record.get("provider", metadata.get("provider", "Unknown"))
            retrieved.append(result)

        if not retrieved and missing_skills:
            for skill in missing_skills:
                for course_record in self.course_repository.get_by_skill(skill):
                    retrieved.append(_course_result(course_record, similarity_score=0.0, fallback_skill=skill))

        seen_titles = {c["title"] for c in retrieved}
        for skill in missing_skills:
            for course_record in self.course_repository.get_by_skill(skill):
                title = course_record.get("title", "")
                if title and title not in seen_titles:
                    seen_titles.add(title)
                    retrieved.append(_course_result(course_record, similarity_score=0.0, fallback_skill=skill))

        return retrieved
