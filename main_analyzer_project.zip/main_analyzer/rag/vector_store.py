"""
vector_store.py

Owns the RAG module's ChromaDB collections: builds rich text "documents"
per job and per course (document loading + context generation), embeds them
via the shared EmbeddingService, and stores them for later retrieval.

Job data is obtained exclusively through `database.job_repository`
(the single source of truth) rather than reading job_db.json directly, so
there is exactly one code path that touches the file on disk.

Course data is obtained exclusively through `database.course_repository`
(the single source of truth) rather than reading course_db.json directly.
"""
from __future__ import annotations

from typing import Any, Dict, List

import chromadb

from config import settings
from database.course_repository import CourseRepository, get_course_repository
from database.job_repository import JobRepository, get_job_repository
from services.embedding_service import EmbeddingService, get_embedding_service
from utils.logging_config import get_logger

logger = get_logger(__name__)


def build_job_document(job: Dict[str, Any]) -> str:
    """
    Build the rich text chunk used both for embedding and as the retrieved
    context passed to the Job Analyzer. This is the module's "context
    generation" responsibility.
    """
    title = job.get("title", "Unknown Position")
    skills = job.get("required_skills", [])
    skills_str = ", ".join(skills) if isinstance(skills, list) else str(skills)
    min_experience = job.get("minimum_work_experience_years", 0)

    if job.get("description"):
        return f"Job Title: {title}\nDescription: {job['description']}"

    return (
        f"Job Title: {title}\n"
        f"Required Skills: {skills_str}.\n"
        f"Minimum Experience: {min_experience} year(s)."
    )


def build_course_document(course: Dict[str, Any]) -> str:
    """
    Build the rich text chunk used for embedding courses for retrieval.
    """
    title = course.get("title", "Unknown Course")
    provider = course.get("provider", "Unknown Provider")
    skills = course.get("skills_covered", [])
    skills_str = ", ".join(skills) if isinstance(skills, list) else str(skills)
    difficulty = course.get("difficulty", "Beginner")
    description = course.get("description", "")
    target_roles = course.get("target_roles", [])
    target_sectors = course.get("target_sectors", [])
    roles_str = ", ".join(target_roles) if isinstance(target_roles, list) else str(target_roles)
    sectors_str = ", ".join(target_sectors) if isinstance(target_sectors, list) else str(target_sectors)

    return (
        f"Course Title: {title}\n"
        f"Provider: {provider}\n"
        f"Skills Covered: {skills_str}\n"
        f"Difficulty: {difficulty}\n"
        f"Description: {description}\n"
        f"Target Roles: {roles_str}\n"
        f"Target Sectors: {sectors_str}"
    )


class VectorStoreManager:
    """Manages the persistent ChromaDB collections for jobs and courses."""

    def __init__(
        self,
        job_repository: JobRepository | None = None,
        course_repository: CourseRepository | None = None,
        embedding_service: EmbeddingService | None = None,
    ) -> None:
        self.job_repository = job_repository or get_job_repository()
        self.course_repository = course_repository or get_course_repository()
        self.embedding_service = embedding_service or get_embedding_service()

        self.client = chromadb.PersistentClient(path=settings.vector_store.persist_directory)
        self.collection = self.client.get_or_create_collection(
            name=settings.vector_store.collection_name
        )
        self.course_collection = self.client.get_or_create_collection(
            name="courses"
        )
        self._seed_jobs_if_empty()
        self._seed_courses_if_empty()

    def _seed_jobs_if_empty(self) -> None:
        if self.collection.count() > 0:
            logger.info("Job vector store already populated (%d jobs). Skipping seed.", self.collection.count())
            return

        jobs = self.job_repository.all_jobs()
        if not jobs:
            logger.warning("Job repository returned no jobs; job vector store left empty.")
            return

        logger.info("Seeding job vector store from %d job records...", len(jobs))
        documents: List[str] = []
        metadatas: List[Dict[str, Any]] = []
        ids: List[str] = []

        for job in jobs:
            documents.append(build_job_document(job))
            ids.append(job["job_id"])
            req_skills = job.get("required_skills") or []
            skills_str = ", ".join(req_skills) if isinstance(req_skills, (list, tuple)) else str(req_skills)
            metadatas.append({
                "job_id": job["job_id"],
                "title": job["title"],
                "required_skills": skills_str,
                "minimum_work_experience_years": job.get("minimum_work_experience_years", 0),
            })

        embeddings = self.embedding_service.encode_many(documents)
        self.collection.add(ids=ids, embeddings=embeddings, metadatas=metadatas, documents=documents)
        logger.info("Job vector store seeded. Total indexed jobs: %d", self.collection.count())

    def _seed_courses_if_empty(self) -> None:
        if self.course_collection.count() > 0:
            logger.info("Course vector store already populated (%d courses). Skipping seed.", self.course_collection.count())
            return

        courses = self.course_repository.all_courses()
        if not courses:
            logger.warning("Course repository returned no courses; course vector store left empty.")
            return

        logger.info("Seeding course vector store from %d course records...", len(courses))
        documents: List[str] = []
        metadatas: List[Dict[str, Any]] = []
        ids: List[str] = []

        for course in courses:
            documents.append(build_course_document(course))
            ids.append(course["id"])
            cov_skills = course.get("skills_covered") or []
            cov_str = ", ".join(cov_skills) if isinstance(cov_skills, (list, tuple)) else str(cov_skills)
            metadatas.append({
                "course_id": course["id"],
                "title": course.get("title", "Unknown Course"),
                "provider": course.get("provider", "Unknown"),
                "skills_covered": cov_str,
                "difficulty": course.get("difficulty", "Beginner"),
                "certificate": course.get("certificate", False),
            })

        embeddings = self.embedding_service.encode_many(documents)
        self.course_collection.add(ids=ids, embeddings=embeddings, metadatas=metadatas, documents=documents)
        logger.info("Course vector store seeded. Total indexed courses: %d", self.course_collection.count())

    def count(self) -> int:
        return self.collection.count()

    def count_courses(self) -> int:
        return self.course_collection.count()
