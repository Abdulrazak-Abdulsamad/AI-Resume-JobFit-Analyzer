"""
retriever.py

Turns a parsed resume into a query embedding and retrieves the top-K
semantically closest jobs from the vector store. This is the ONLY way the
Job Analyzer is allowed to obtain job information (per the integration
requirement that job data flows exclusively through the RAG pipeline).

For each retrieved match, the authoritative structured fields
(required_skills, minimum_work_experience_years) are re-fetched from the
JobRepository by job_id - the vector store's metadata is used only to
identify *which* job matched, never as the source of truth for its data.
"""
from __future__ import annotations

from typing import Any, Dict, List

from config import settings
from database.job_repository import JobRepository, get_job_repository
from rag.schemas import RetrievedJob
from rag.vector_store import VectorStoreManager, build_job_document
from resume_parsing.schema import ParsedResume
from services.embedding_service import EmbeddingService, get_embedding_service
from utils.logging_config import get_logger

logger = get_logger(__name__)


class JobRetriever:
    """Retrieves the most relevant job(s) for a given parsed resume."""

    def __init__(
        self,
        vector_store: VectorStoreManager,
        job_repository: JobRepository | None = None,
        embedding_service: EmbeddingService | None = None,
    ) -> None:
        self.vector_store = vector_store
        self.job_repository = job_repository or get_job_repository()
        self.embedding_service = embedding_service or get_embedding_service()

    @staticmethod
    def _resume_to_query_text(resume: ParsedResume) -> str:
        """Flatten a ParsedResume into a single descriptive text block used
        as the semantic search query."""
        experience_lines = [
            f"  - {entry.company or 'Role'}: {entry.role or ''}"
            for entry in resume.experience
        ]
        education_lines = [
            f"  - {entry.institution or ''} {entry.degree or ''}".strip()
            for entry in resume.education
        ]

        return "\n".join([
            f"Candidate: {resume.name or 'Unknown'}",
            f"Total Experience: {resume.total_experience_years} year(s)",
            f"Skills: {', '.join(resume.skills)}",
            "Education:",
            *(education_lines or ["  - Not specified"]),
            "Experience:",
            *(experience_lines or ["  - Not specified"]),
        ])

    def retrieve_top_jobs(self, resume: ParsedResume, top_k: int | None = None) -> List[RetrievedJob]:
        """Query the vector store for the top-K jobs matching this resume."""
        top_k = top_k or settings.retrieval.top_k
        query_text = self._resume_to_query_text(resume)
        query_vector = self.embedding_service.encode(query_text)

        results = self.vector_store.collection.query(
            query_embeddings=[query_vector],
            n_results=top_k,
        )

        retrieved: List[RetrievedJob] = []
        metadatas = (results.get("metadatas") or [[]])[0]
        distances = (results.get("distances") or [[]])[0]

        for i, metadata in enumerate(metadatas):
            job_id = metadata.get("job_id", f"job_{i + 1}")
            job_record = self.job_repository.get_by_id(job_id) or {}

            distance = distances[i] if i < len(distances) else 0.0
            similarity_score = round(1.0 / (1.0 + float(distance)), 3)

            retrieved.append(RetrievedJob(
                job_id=job_id,
                title=job_record.get("title", metadata.get("title", "Unknown Position")),
                sector=job_record.get("sector"),
                required_skills=job_record.get("required_skills", []),
                minimum_work_experience_years=job_record.get("minimum_work_experience_years", 0),
                context_text=build_job_document(job_record) if job_record else "No description available.",
                similarity_score=similarity_score,
            ))

        return retrieved
