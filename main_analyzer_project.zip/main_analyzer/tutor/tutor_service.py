"""
tutor_service.py (tutor)

Facade the API routes call into. Mirrors the existing project pattern
(one facade per feature, see services/resume_analysis_service.py).
"""
from __future__ import annotations

from typing import Any, Dict, List

from nlp_insights.nlp_service import analyze_text
from tutor import llm_client
from tutor.prompt_builder import build_chat_messages, build_explanation_messages


def _resume_text_for_nlp(job_match: Dict[str, Any], resume_text: str | None) -> str:
    if resume_text:
        return resume_text
    # Fall back to whatever free text is already in the job_match payload
    # (strengths/weaknesses/suggestions read naturally as prose).
    parts: List[str] = []
    for key in ("strengths", "weaknesses", "improvement_suggestions"):
        value = job_match.get(key)
        if isinstance(value, list):
            parts.extend(str(v) for v in value)
    return " ".join(parts)


def generate_explanation(
    job_match: Dict[str, Any],
    resume_text: str | None,
    candidate_name: str | None,
) -> Dict[str, Any]:
    nlp_signals = analyze_text(_resume_text_for_nlp(job_match, resume_text))
    messages = build_explanation_messages(job_match, nlp_signals, candidate_name)
    explanation = llm_client.chat_completion(messages)
    return {
        "explanation": explanation,
        "keywords": nlp_signals.get("keywords", []),
        "readability": nlp_signals.get("readability", {}),
    }


def generate_chat_reply(
    job_match: Dict[str, Any],
    conversation: List[Dict[str, str]],
    message: str,
    candidate_name: str | None,
) -> str:
    nlp_signals = analyze_text(_resume_text_for_nlp(job_match, None))
    messages = build_chat_messages(job_match, nlp_signals, conversation, message, candidate_name)
    return llm_client.chat_completion(messages, temperature=0.5)
