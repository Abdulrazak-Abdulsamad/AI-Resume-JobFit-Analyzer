"""
schemas.py (tutor)

Request/response contracts for the new /api/tutor/* endpoints. Kept
separate from job_analyzer/schemas.py on purpose - the tutor accepts
whatever analysis JSON the frontend already has in state (real backend
output or the current mock-data shape) rather than assuming one exact
shape, so it doesn't need job_analyzer's schema to change.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class ChatMessage(BaseModel):
    role: str  # "user" | "assistant"
    content: str


class TutorExplainRequest(BaseModel):
    job_match: Dict[str, Any]
    resume_text: Optional[str] = None
    candidate_name: Optional[str] = None


class TutorExplainResponse(BaseModel):
    explanation: str
    keywords: List[str] = []
    readability: Dict[str, float] = {}


class TutorChatRequest(BaseModel):
    job_match: Dict[str, Any]
    message: str
    conversation: List[ChatMessage] = []
    candidate_name: Optional[str] = None


class TutorChatResponse(BaseModel):
    reply: str
