"""
tutor/

The LLM-powered "resume tutor" layer, added on top of the existing,
unchanged pipeline (Resume Parsing -> RAG -> Job Analyzer -> Course
Recommender). Nothing in this package is imported by any existing module;
it only READS the JSON that /api/analyze already produces and turns it
into (a) a personalized natural-language explanation and (b) a follow-up
chat the user can hold about their results.
"""
