"""
llm_client.py (tutor)

Thin wrapper around a local LLM chat-completions endpoint (e.g., Ollama or LM Studio).
Defaults to local server running at http://localhost:11434/v1 using llama3.2.

Env vars (optional overrides):
  TUTOR_LLM_BASE_URL  - default: http://localhost:11434/v1
  TUTOR_LLM_MODEL     - default: llama3.2
  TUTOR_LLM_API_KEY   - default: ollama (optional for local servers)
"""
from __future__ import annotations

import os
from typing import List, Dict

from dotenv import load_dotenv

load_dotenv()

import requests

from utils.logging_config import get_logger

logger = get_logger(__name__)

_DEFAULT_BASE_URL = "http://localhost:11434/v1"
_DEFAULT_MODEL = "llama3.1"
_TIMEOUT_SECONDS = int(os.getenv("TUTOR_LLM_TIMEOUT", "180"))


class LLMNotConfiguredError(RuntimeError):
    """Raised when local LLM server is unreachable or not configured."""


def _config() -> tuple[str, str, str]:
    api_key = os.getenv("TUTOR_LLM_API_KEY", "ollama").strip()
    base_url = os.getenv("TUTOR_LLM_BASE_URL", _DEFAULT_BASE_URL).rstrip("/")
    model = os.getenv("TUTOR_LLM_MODEL", _DEFAULT_MODEL)
    return api_key, base_url, model


def is_configured() -> bool:
    """Check whether local LLM endpoint is set up."""
    _, base_url, _ = _config()
    return bool(base_url)


def chat_completion(messages: List[Dict[str, str]], temperature: float = 0.4) -> str:
    """
    Send a chat-style message list ([{"role": "system"|"user"|"assistant",
    "content": str}, ...]) to the configured local LLM and return reply text.
    """
    api_key, base_url, model = _config()

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    try:
        response = requests.post(
            f"{base_url}/chat/completions",
            headers=headers,
            json={
                "model": model,
                "messages": messages,
                "temperature": 0.3,
                "max_tokens": 300,
            },
            timeout=_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        data = response.json()
        content = data["choices"][0]["message"]["content"].strip()
        # Post-process: strip all double asterisks (**) so output is clean
        cleaned_content = content.replace("**", "")
        return cleaned_content
    except requests.exceptions.ConnectionError as exc:
        logger.error("Local LLM connection failed: %s", exc)
        raise LLMNotConfiguredError(
            f"Could not connect to local LLM server at {base_url}. "
            "Please ensure Ollama or your local LLM service is running."
        ) from exc
    except requests.exceptions.Timeout as exc:
        logger.error("Local LLM request timed out: %s", exc)
        raise LLMNotConfiguredError(
            f"The local LLM server ({model}) took longer than {_TIMEOUT_SECONDS} seconds to respond. "
            "Your system may be actively loading or generating text. Please try again."
        ) from exc
    except requests.RequestException as exc:
        logger.error("LLM request failed: %s", exc)
        raise RuntimeError(f"The local tutor LLM request failed: {exc}") from exc
    except (KeyError, IndexError) as exc:
        logger.error("Unexpected LLM response shape: %s", exc)
        raise RuntimeError("The local tutor LLM returned an unexpected response.") from exc

