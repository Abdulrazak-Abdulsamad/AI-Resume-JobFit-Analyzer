
"""
prompt_builder.py (tutor)

Turns the existing analysis JSON (scores, matched/missing skills,
strengths/weaknesses, course recommendations - already computed by the
unchanged job_analyzer/course_recommender pipeline) plus the new
nlp_insights signals into prompts for the LLM. This is where "just score
percentages" becomes a grounded, personalized narrative: the LLM is never
given free rein - it is only allowed to talk about the numbers/lists we
hand it, so it can't hallucinate a score that doesn't exist.
"""
from __future__ import annotations

import json
from typing import Any, Dict, List

_MAX_CONTEXT_CHARS = 3000

_SYSTEM_PROMPT = (
    "You are a friendly, concise career resume tutor inside a resume analysis app. "
    "You are given key candidate analysis findings (scores, matched/missing skills, "
    "top matches, recommended courses, and learning roadmap).\n\n"
    "Rules:\n"
    "- Never invent scores, skills, courses, or job titles not in the context.\n"
    "- Refer to the candidate's actual matched and missing skills by name.\n"
    "- Keep responses brief, direct, and conversational (under 150 words).\n"
    "- CRITICAL FORMATTING RULE: Do NOT use double asterisks (**) anywhere in your output."
)


def _truncate(text: str, limit: int = _MAX_CONTEXT_CHARS) -> str:
    return text if len(text) <= limit else text[:limit] + " ...[truncated]"


def _context_block(job_match: Dict[str, Any], nlp_signals: Dict[str, Any]) -> str:
    # Build a compact, lightweight representation for fast LLM processing
    score = job_match.get("score") or {}
    skills = job_match.get("skills") or {}
    courses = job_match.get("course_recommendations") or {}

    compact_payload = {
        "job_title": job_match.get("job_title", "Target Role"),
        "sector": job_match.get("sector", "General"),
        "final_fit_score": score.get("final_fit_score", 0),
        "rating": score.get("rating", "Match"),
        "matched_skills": skills.get("matching_skills", []),
        "missing_skills": skills.get("missing_skills", []),
        "top_matches": [
            {
                "title": m.get("job_title", m.get("title")),
                "fit_score": m.get("score", {}).get("final_fit_score", m.get("jobMatchScore")),
            }
            for m in (job_match.get("jobMatches") or [])[:3]
        ],
        "courses": [
            {
                "skill": g.get("skill"),
                "titles": [c.get("course_title", c.get("title")) for c in (g.get("courses") or [])[:2]],
            }
            for g in (courses.get("skill_recommendations") or [])[:3]
        ],
        "nlp_signals": nlp_signals,
    }
    return _truncate(json.dumps(compact_payload, default=str, ensure_ascii=False))


def build_explanation_messages(
    job_match: Dict[str, Any],
    nlp_signals: Dict[str, Any],
    candidate_name: str | None,
) -> List[Dict[str, str]]:
    name = candidate_name or "the candidate"
    user_prompt = (
        f"Here is the full analysis JSON for {name} against one job match:\n\n"
        f"{_context_block(job_match, nlp_signals)}\n\n"
        "Write a personalized explanation covering: (1) an honest overall "
        "read on fit, (2) why the scores landed where they did - referencing "
        "specific matched and missing skills, experience gap, and any "
        "readability/keyword signals if present, (3) the 2-3 highest-impact "
        "things to improve first, in priority order. End by inviting them to "
        "ask you anything about the results."
    )
    return [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt},
    ]


def build_chat_messages(
    job_match: Dict[str, Any],
    nlp_signals: Dict[str, Any],
    conversation: List[Dict[str, str]],
    message: str,
    candidate_name: str | None,
) -> List[Dict[str, str]]:
    name = candidate_name or "the candidate"
    context_msg = (
        f"[Context for this conversation - {name}'s full analysis JSON, do "
        f"not repeat it verbatim, just use it to answer accurately]\n\n"
        f"{_context_block(job_match, nlp_signals)}"
    )
    messages: List[Dict[str, str]] = [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": context_msg},
        {"role": "assistant", "content": "Got it - I have the full analysis. What would you like to know?"},
    ]
    for turn in conversation:
        role = turn.get("role") if isinstance(turn, dict) else turn.role
        content = turn.get("content") if isinstance(turn, dict) else turn.content
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": message})
    return messages