"""
routes.py (tutor)

New, additive API routes. Imported and mounted by api.py with a single
`app.include_router(tutor_router)` line - none of the existing routes
(`/api/analyze`, `/api/health`) are touched.
"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from tutor import tutor_service
from tutor.llm_client import LLMNotConfiguredError
from tutor.schemas import (
    TutorChatRequest,
    TutorChatResponse,
    TutorExplainRequest,
    TutorExplainResponse,
)
from utils.logging_config import get_logger

logger = get_logger(__name__)

router = APIRouter(prefix="/api/tutor", tags=["tutor"])


@router.post("/explain", response_model=TutorExplainResponse)
def explain(request: TutorExplainRequest) -> TutorExplainResponse:
    """Turn an already-computed job match analysis into a personalized,
    LLM-generated explanation (instead of raw score percentages)."""
    try:
        result = tutor_service.generate_explanation(
            job_match=request.job_match,
            resume_text=request.resume_text,
            candidate_name=request.candidate_name,
        )
        return TutorExplainResponse(**result)
    except LLMNotConfiguredError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        logger.error("Tutor explain failed: %s", exc)
        raise HTTPException(status_code=500, detail="Tutor failed to generate an explanation.") from exc


@router.post("/chat", response_model=TutorChatResponse)
def chat(request: TutorChatRequest) -> TutorChatResponse:
    """Answer a follow-up question about a job match analysis, with the
    conversation history the frontend has been keeping in state."""
    try:
        reply = tutor_service.generate_chat_reply(
            job_match=request.job_match,
            conversation=[m.model_dump() for m in request.conversation],
            message=request.message,
            candidate_name=request.candidate_name,
        )
        return TutorChatResponse(reply=reply)
    except LLMNotConfiguredError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        logger.error("Tutor chat failed: %s", exc)
        raise HTTPException(status_code=500, detail="Tutor failed to respond.") from exc
