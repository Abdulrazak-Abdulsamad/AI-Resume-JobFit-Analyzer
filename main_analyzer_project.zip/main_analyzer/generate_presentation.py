import sys
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

def create_presentation():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # Color Palette
    DARK_BG = RGBColor(15, 23, 42)      # Slate 900
    ACCENT_PURPLE = RGBColor(99, 102, 241) # Indigo 500
    TEXT_DARK = RGBColor(30, 41, 59)     # Slate 800
    TEXT_LIGHT = RGBColor(248, 250, 252) # Slate 50
    CARD_BG = RGBColor(241, 245, 249)    # Slate 100
    BORDER_COLOR = RGBColor(203, 213, 225)

    slides_data = [
        {
            "slide_num": 1,
            "speaker": "Team Member 1",
            "title": "AI Resume Analyzer & Local AI Tutor",
            "subtitle": "Project Overview & Vision (10 Mins Total Presentation)",
            "points": [
                "AI Career Assistant: Combines Resume Parsing, RAG Job Matching, Course Recommendations, and an Interactive Local AI Tutor.",
                "Solves ATS Black-Box: Provides candidate transparency, skill gap detection, and personalized learning roadmaps.",
                "100% Offline & Private: Employs local vector embeddings and local LLMs (Ollama / LLaMA 3.1) with zero cloud dependencies.",
                "Modular Design: Decouples text extraction, vector retrieval, scoring, course generation, and natural-language tutoring."
            ],
            "notes": "Speaker 1 Pitch (1 Min / 60s):\n- Welcome everyone! We built an AI Resume Analyzer and Local AI Tutor that demystifies ATS resume screeners.\n- Our application parses candidate resumes, matches them against real job databases via vector search, generates customized learning roadmaps, and provides an interactive AI Tutor.\n- Best of all, it runs 100% offline using local LLMs for complete privacy."
        },
        {
            "slide_num": 2,
            "speaker": "Team Member 2",
            "title": "System Architecture & Data Pipeline",
            "subtitle": "Modular End-to-End Information Flow",
            "points": [
                "Pipeline Flow: Parsing -> RAG Search -> Weighted Scoring -> Upskilling Roadmap -> Local AI Tutor.",
                "Decoupled Architecture: FastAPI REST backend (api.py) serving a high-performance React (Vite + Tailwind) SPA.",
                "Facade Pattern: Unified service facades (ResumeAnalysisService, TutorService) orchestrate internal NLP & RAG modules.",
                "Single Source of Truth: JobRepository caches job_db.json once to serve both vector indexing and scoring."
            ],
            "notes": "Speaker 2 Pitch (1 Min / 60s):\n- Our system follows a strict modular pipeline from file upload down to interactive tutoring.\n- We separated the backend into FastAPI REST endpoints and built a modern React SPA frontend.\n- Using the Facade design pattern, all internal complex NLP operations are unified into clean service calls."
        },
        {
            "slide_num": 3,
            "speaker": "Team Member 3",
            "title": "Resume Parsing & Text Extraction",
            "subtitle": "Document Ingestion & spaCy NER",
            "points": [
                "Multi-Format Extraction: Extracts clean text from PDF and DOCX files with OCR fallback for scanned documents.",
                "spaCy NER Pipeline: Automatically identifies candidate name, email, phone, education, and career experience.",
                "YOE Calculation Engine: Merges overlapping employment dates to calculate true net years of professional experience.",
                "Unified Skills Taxonomy: Canonical skills dictionary (skills_taxonomy.py) prevents vocabulary mismatch with job postings."
            ],
            "notes": "Speaker 3 Pitch (1 Min / 60s):\n- The resume parsing engine ingests PDF and DOCX files using spaCy Named Entity Recognition.\n- It accurately extracts contact details, education, and calculates exact years of experience by deduplicating overlapping work dates.\n- A canonical skills taxonomy ensures candidate skills match job requirements cleanly."
        },
        {
            "slide_num": 4,
            "speaker": "Team Member 4",
            "title": "Retrieval-Augmented Generation (RAG) & Vector Search",
            "subtitle": "ChromaDB & Shared Embeddings",
            "points": [
                "Shared Embedding Singleton: Single cached SentenceTransformer ('all-MiniLM-L6-v2') shared across all modules.",
                "ChromaDB Vector Store: Indexes job postings into 384-dimensional dense vectors for sub-second semantic search.",
                "Top-K Retrieval: Converts candidate profile into vector query to retrieve top K matching job descriptions.",
                "Context Builder: Formats retrieved job vectors into structured payloads for scoring engines and LLM prompts."
            ],
            "notes": "Speaker 4 Pitch (1 Min / 60s):\n- Instead of rigid hardcoded job matching, we use Retrieval-Augmented Generation (RAG).\n- Job postings are indexed into a ChromaDB vector store using 384-dimensional embeddings from SentenceTransformers.\n- We retrieve top-K semantic job matches in milliseconds to feed our scoring and tutoring engines."
        },
        {
            "slide_num": 5,
            "speaker": "Team Member 5",
            "title": "Weighted ATS Scoring Engine & Insights",
            "subtitle": "Multi-Dimensional Fit Analysis",
            "points": [
                "Category Weights: Skills Match (30%), Experience (25%), Industry (15%), Education (10%), Quality & ATS (20%).",
                "Hybrid Similarity: Combines keyword TF-IDF metrics with sentence-level vector cosine similarity.",
                "Experience Matcher: Quantitative evaluation of candidate YOE against minimum job experience criteria.",
                "Dynamic Feedback: Automatically generates candidate strengths, weaknesses, and actionable improvement tips."
            ],
            "notes": "Speaker 5 Pitch (1 Min / 60s):\n- Our ATS scoring engine evaluates candidates across an 8-category weighted scoring model.\n- It combines TF-IDF keyword frequency with semantic cosine similarity and evaluates experience gaps.\n- The engine automatically outputs explicit strengths, weaknesses, and actionable tips for resume enhancement."
        },
        {
            "slide_num": 6,
            "speaker": "Team Member 6",
            "title": "Course Recommendations & Upskilling Roadmap",
            "subtitle": "Turning Skill Gaps into Learning Paths",
            "points": [
                "Skill Gap Detection: Contrasts candidate skills against retrieved job requirements to isolate missing competencies.",
                "Curated Platform Catalog: Maps missing skills to trusted courses on Coursera, Udemy, YouTube, and freeCodeCamp.",
                "Phased Roadmap: Groups courses into progressive Beginner -> Intermediate -> Advanced learning phases.",
                "Live Generation: Roadmaps are dynamically generated per job match—never static predefined templates."
            ],
            "notes": "Speaker 6 Pitch (1 Min / 60s):\n- Identifying missing skills is only half the battle—we also provide the solution.\n- Our course recommender detects skill gaps and maps them to curated courses on Coursera, Udemy, and YouTube.\n- It automatically constructs a phased Beginner-to-Advanced roadmap for candidate upskilling."
        },
        {
            "slide_num": 7,
            "speaker": "Team Member 7",
            "title": "NLP Insights: YAKE Keywords & Readability",
            "subtitle": "Unsupervised Text Quality Assessment",
            "points": [
                "YAKE Keyphrase Extraction: Unsupervised statistical keyphrase extraction operating directly on single-document resumes.",
                "Flesch Reading Ease: Evaluates resume readability score to guarantee clear and impactful prose.",
                "Flesch-Kincaid Grade: Measures educational grade level required to comfortably read the resume text.",
                "LLM Synergy: Passes keyphrase and readability metrics to the AI Tutor to ground conversational responses."
            ],
            "notes": "Speaker 7 Pitch (1 Min / 60s):\n- We enhance analysis with YAKE statistical keyphrase extraction and Flesch readability scoring.\n- YAKE extracts key single-document phrases without needing external training data.\n- Readability scores ensure resumes are punchy, professional, and clear to recruiters."
        },
        {
            "slide_num": 8,
            "speaker": "Team Member 8",
            "title": "Local AI Tutor Integration (Ollama & LLaMA 3.1)",
            "subtitle": "100% Private, Grounded Conversational AI",
            "points": [
                "Local LLM Execution: Operates via local Ollama server running LLaMA 3.1 on port 11434 with zero cloud APIs.",
                "Grounded Prompts: System prompts strictly restrict LLM to analysis JSON facts, preventing AI hallucinations.",
                "Dual API Routes: /api/tutor/explain (narrative summary) and /api/tutor/chat (multi-turn follow-up Q&A).",
                "Resilient Client: Handles local connection state, model warm-up, and extended 180s inference timeouts."
            ],
            "notes": "Speaker 8 Pitch (1 Min / 60s):\n- Our AI Tutor is powered by a local Ollama server running LLaMA 3.1—100% private and offline.\n- Strict prompt engineering ensures responses are strictly grounded in analysis data without hallucinations.\n- Candidates can ask follow-up questions in real-time through multi-turn chat."
        },
        {
            "slide_num": 9,
            "speaker": "Team Member 9",
            "title": "Full-Stack Presentation Layer (FastAPI & React)",
            "subtitle": "Modern Analytics Dashboard & UI/UX",
            "points": [
                "FastAPI REST Endpoints: Asynchronous routes (/api/analyze, /api/tutor/*) with CORS and Pydantic schema validation.",
                "React Dashboard: SPA built with Vite, Tailwind CSS, and Lucide React icons for maximum responsiveness.",
                "Visual Analytics: Features score gauges, skill gap indicators, radar charts, and interactive upskilling cards.",
                "AI Tutor UI Tab: Dedicated interactive chat panel for candidate Q&A."
            ],
            "notes": "Speaker 9 Pitch (1 Min / 60s):\n- The user experience is delivered through a modern React SPA powered by Vite and Tailwind CSS.\n- It connects asynchronously to our FastAPI backend for file uploads and streaming tutor responses.\n- Interactive charts, gauges, and tabbed navigation give candidates instant visual feedback."
        },
        {
            "slide_num": 10,
            "speaker": "Team Member 10",
            "title": "Deployment, Verification & Future Vision",
            "subtitle": "Operational Readiness & Next Steps",
            "points": [
                "One-Command Setup: Automated scripts (build_vector_db.py, run_backend.sh, run_frontend.sh).",
                "Empirical Verification: End-to-end smoke testing (test_pipeline_smoke.py) validating pipeline integrity.",
                "Verified Offline Operation: Zero external network calls during parsing, RAG, analysis, or tutor chat.",
                "Future Vision: Multi-resume batch screening, custom fine-tuned local models, and HR ATS connectors."
            ],
            "notes": "Speaker 10 Pitch (1 Min / 60s):\n- In summary, our project is fully verified, operational, and runs 100% offline with zero cloud costs.\n- We have automated setup scripts and end-to-end unit tests validating system stability.\n- Thank you for your time, and we're happy to open the floor to any questions!"
        }
    ]

    for data in slides_data:
        slide_layout = prs.slide_layouts[6] # blank layout
        slide = prs.slides.add_slide(slide_layout)

        # Background header bar
        header_rect = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(1.3))
        header_rect.fill.solid()
        header_rect.fill.fore_color.rgb = DARK_BG
        header_rect.line.fill.background()

        # Header Title
        tf = header_rect.text_frame
        tf.word_wrap = True
        tf.margin_left = Inches(0.8)
        tf.margin_top = Inches(0.2)
        p = tf.paragraphs[0]
        p.text = data["title"]
        p.font.size = Pt(26)
        p.font.bold = True
        p.font.color.rgb = TEXT_LIGHT

        # Header Subtitle
        p2 = tf.add_paragraph()
        p2.text = data["subtitle"]
        p2.font.size = Pt(14)
        p2.font.color.rgb = RGBColor(199, 210, 254)

        # Speaker Badge Card (Top Right)
        badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(9.8), Inches(0.25), Inches(2.8), Inches(0.8))
        badge.fill.solid()
        badge.fill.fore_color.rgb = ACCENT_PURPLE
        badge.line.fill.background()
        btf = badge.text_frame
        btf.margin_left = Inches(0.1)
        btf.margin_top = Inches(0.15)
        bp = btf.paragraphs[0]
        bp.alignment = PP_ALIGN.CENTER
        bp.text = f"Speaker: {data['speaker']}"
        bp.font.size = Pt(13)
        bp.font.bold = True
        bp.font.color.rgb = TEXT_LIGHT
        bp2 = btf.add_paragraph()
        bp2.alignment = PP_ALIGN.CENTER
        bp2.text = "Allocated Time: 1 Min (60s)"
        bp2.font.size = Pt(10)
        bp2.font.color.rgb = RGBColor(224, 231, 255)

        # Content Card Body
        body_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(1.6), Inches(11.733), Inches(5.3))
        body_card.fill.solid()
        body_card.fill.fore_color.rgb = CARD_BG
        body_card.line.color.rgb = BORDER_COLOR

        ctf = body_card.text_frame
        ctf.word_wrap = True
        ctf.margin_left = Inches(0.5)
        ctf.margin_top = Inches(0.4)
        ctf.margin_right = Inches(0.5)

        for idx, pt_text in enumerate(data["points"]):
            cp = ctf.add_paragraph() if idx > 0 else ctf.paragraphs[0]
            cp.text = f"-  {pt_text}"
            cp.font.size = Pt(18)
            cp.font.color.rgb = TEXT_DARK
            cp.space_after = Pt(18)

        # Add Speaker Notes
        notes_slide = slide.notes_slide
        text_frame = notes_slide.notes_text_frame
        text_frame.text = data["notes"]

    output_path = "C:/Users/adams/Downloads/main_analyzer_with_tutor/main_analyzer_with_tutor/main_analyzer/AI_Resume_Analyzer_Presentation.pptx"
    prs.save(output_path)
    print(f"Presentation saved successfully to: {output_path}")

if __name__ == "__main__":
    create_presentation()
