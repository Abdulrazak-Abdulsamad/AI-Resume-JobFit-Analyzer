import pptx

prs = pptx.Presentation('C:/Users/adams/Downloads/Final_AI_Resume_Analyzer.pptx')
with open('detailed_shapes.txt', 'w', encoding='utf-8') as f:
    for s_idx, slide in enumerate(prs.slides):
        f.write(f'=== SLIDE {s_idx+1} ===\n')
        for sh_idx, shape in enumerate(slide.shapes):
            if shape.has_text_frame:
                tf = shape.text_frame
                f.write(f'  Shape [{sh_idx}] (name="{shape.name}", id={shape.shape_id}):\n')
                for p_idx, p in enumerate(tf.paragraphs):
                    p_text = ''.join(r.text for r in p.runs) or p.text
                    if p_text.strip():
                        runs_info = []
                        for r_idx, r in enumerate(p.runs):
                            runs_info.append(f'r[{r_idx}]="{r.text}"')
                        f.write(f'    p[{p_idx}]: "{p_text}" | RUNS: {", ".join(runs_info)}\n')

print('Detailed shape inspection saved to detailed_shapes.txt')
