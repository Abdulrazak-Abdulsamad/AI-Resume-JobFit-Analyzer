"""
skills_taxonomy.py

The canonical list of technical/professional skills recognized by the whole
system. This is the SINGLE source of truth for "what counts as a skill" -
both the Resume Parser (extracting skills from free text) and the Job
Analyzer (matching resume skills against job requirements) import this list,
which eliminates the two divergent, hand-maintained skill lists that existed
in the original projects.

FIX (previously a sector-coverage bug): the taxonomy used to be a small,
hand-curated, tech-only list (~60 entries). Because `job_db.json` spans
seven sectors (Information Technology, Healthcare, Business & Finance,
Engineering, Marketing & Sales, Education, Operations & Logistics) with
~1,950 distinct `required_skills` values between them, that tech-only list
meant skill extraction could never recognize a candidate's real skills for
any non-IT job - there was nothing non-tech in the taxonomy to match
against. `SKILL_TAXONOMY` is now the union of:
  1. `_CORE_SKILL_TAXONOMY` - the original hand-curated general/tech list
     (kept so the taxonomy still contains sensible entries even in contexts
     where the job database isn't available, e.g. a fresh checkout before
     `data/job_db.json` exists, or an isolated unit test).
  2. Every distinct `required_skills` value already present in the job
     database, loaded through `database.job_repository` (the single place
     that reads `job_db.json`) rather than a second, hand-copied list - so
     this taxonomy is a true superset of the job database's vocabulary
     across every sector, and stays that way automatically as the job
     database grows or changes.

`SKILL_ALIASES` is a second, small addition: a common-abbreviation ->
canonical-taxonomy-term map (e.g. "JS" -> "JavaScript", "EHR" -> "Electronic
Health Records (EHR)", "SEO" -> "SEO Strategy"), spanning every sector
above, not just tech. This exists because embedding-based fuzzy matching is
unreliable for short acronyms (there isn't enough semantic signal in two or
three letters for a general-purpose sentence embedding model to reliably
land close to the right canonical phrase). Resolving known aliases
deterministically, before falling back to embeddings, removes that
uncertainty entirely for the common cases below.
"""
from __future__ import annotations

from typing import Dict, List

# ---------------------------------------------------------------------------
# 1. Hand-curated core list (kept as a fallback and for readability/tests).
# ---------------------------------------------------------------------------
_CORE_SKILL_TAXONOMY: List[str] = sorted(set([
    # Languages
    "Python", "Java", "JavaScript", "TypeScript", "C++", "R", "Bash",
    # Web / Frontend
    "React", "Vue.js", "HTML5", "CSS3", "Tailwind", "REST APIs", "RESTful APIs",
    # Backend / Data
    "Node.js", "SQL", "PostgreSQL", "MongoDB", "Snowflake",
    "Pandas", "NumPy", "Scikit-Learn", "Apache Spark", "Airflow", "Hadoop",
    # AI / ML
    "PyTorch", "TensorFlow", "Natural Language Processing", "Computer Vision",
    "MLOps", "Machine Learning", "spaCy",
    # DevOps / Cloud
    "Docker", "Kubernetes", "CI/CD", "GitHub Actions", "Jenkins", "Linux",
    "AWS", "Azure", "GCP", "Terraform", "Git", "FastAPI",
    # Security
    "Network Security", "Penetration Testing", "Risk Assessment", "SIEM Tools",
    # Design
    "Figma", "Adobe XD", "Wireframing", "Prototyping", "User Research",
    # BI / Analytics
    "Tableau", "PowerBI", "Data Analysis",
    # Product / Process
    "Product Strategy", "Agile", "Scrum", "Stakeholder Management",
    "System Design",
]))


def _load_job_database_skills() -> List[str]:
    """
    Pull every distinct `required_skills` value across the entire job
    database - every sector, not just Information Technology - so the
    taxonomy actually matches what jobs ask for. Imported lazily (function
    body, not module top-level) so a context that only needs the static
    core list (e.g. a minimal unit test with no `data/job_db.json` on disk)
    doesn't fail just importing this module.
    """
    try:
        from database.job_repository import get_job_repository

        job_repository = get_job_repository()
        skills: set[str] = set()
        for job in job_repository.all_jobs():
            skills.update(job.get("required_skills", []))
        return sorted(skills)
    except Exception:
        # Job database not available yet (fresh checkout, isolated test,
        # etc.) - fall back to the static core list only rather than
        # raising an import-time error.
        return []


SKILL_TAXONOMY: List[str] = sorted(set(_CORE_SKILL_TAXONOMY) | set(_load_job_database_skills()))


# ---------------------------------------------------------------------------
# 2. Common-abbreviation -> canonical-taxonomy-term aliases, across every
#    sector represented in the job database. Keys are matched
#    case-insensitively as whole words/phrases against resume text; values
#    must be exact `SKILL_TAXONOMY` entries (validated below).
# ---------------------------------------------------------------------------
SKILL_ALIASES: Dict[str, str] = {
    # --- Information Technology ---
    "js": "JavaScript",
    "ts": "TypeScript",
    "k8s": "Kubernetes",
    "node": "Node.js",
    "nodejs": "Node.js",
    "postgres": "PostgreSQL",
    "mongo": "MongoDB",
    "ml": "Machine Learning",
    "nlp": "Natural Language Processing",
    "iac": "Infrastructure as Code",
    "gh actions": "GitHub Actions",
    "pentest": "Penetration Testing",
    "pentesting": "Penetration Testing",
    "pen testing": "Penetration Testing",

    # --- Healthcare ---
    "ehr": "Electronic Health Records (EHR)",
    "emr": "Electronic Health Records (EHR)",
    "bls": "Basic Life Support (BLS)",
    "als": "Advanced Life Support (ALS)",
    "ecg": "Electrocardiogram (ECG) Interpretation",
    "ekg": "Electrocardiogram (ECG) Interpretation",
    "icu": "Critical Care",
    "hipaa": "HIPAA Compliance",
    "adl": "Activities of Daily Living (ADL) Training",
    "ecmo": "Extracorporeal Membrane Oxygenation (ECMO)",
    "cbt": "Cognitive Behavioral Therapy (CBT)",

    # --- Business & Finance ---
    "kpi": "KPI Tracking",
    "kpis": "KPI Tracking",
    "roi": "ROI Analysis",
    "p&l": "Profit & Loss (P&L) Management",
    "pnl": "Profit & Loss (P&L) Management",
    "var": "Value at Risk (VaR)",
    "dcf": "DCF Analysis",
    "lbo": "LBO Modeling",

    # --- Marketing & Sales ---
    "seo": "SEO Strategy",
    "sem": "SEO/SEM",
    "crm": "CRM Management",
    "ppc": "Paid Search Strategy",
    "ltv": "Customer Lifetime Value (LTV)",
    "abm": "Account-Based Marketing (ABM)",

    # --- Education ---
    "iep": "IEP Development",
    "lms": "Learning Management Systems",
    "esl": "ESL Integration",
    "ferpa": "FERPA Compliance",
    "addie": "ADDIE Model",

    # --- Operations & Logistics ---
    "wms": "Warehouse Management Systems (WMS)",
    "sla": "SLA Management",
    "edi": "EDI Protocols",
    "jit": "Just-In-Time (JIT) Delivery",
    "osha": "OSHA Rules",
}

# Fail fast (at import time) if an alias points at a canonical term that
# doesn't actually exist in the taxonomy - e.g. because the job database's
# exact phrasing changed. Silently dropping a broken alias would be a much
# quieter, harder-to-notice bug than an import-time error.
_unknown_alias_targets = {
    target for target in SKILL_ALIASES.values() if target not in SKILL_TAXONOMY
}
if _unknown_alias_targets:
    raise ValueError(
        "SKILL_ALIASES references canonical terms not present in SKILL_TAXONOMY: "
        f"{sorted(_unknown_alias_targets)}"
    )
