"""
config.py

Centralized, single-source configuration for the AI Resume Analyzer.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
# Base paths
# ---------------------------------------------------------------------------
BASE_DIR: Path = Path(__file__).resolve().parent
DATA_DIR: Path = BASE_DIR / "data"
VECTOR_DB_DIR: Path = BASE_DIR / "data" / "vectordb"

JOB_DB_PATH: Path = Path(os.getenv("RESUME_ANALYZER_JOB_DB", str(DATA_DIR / "job_db.json")))
COURSE_DB_PATH: Path = Path(os.getenv("RESUME_ANALYZER_COURSE_DB", str(DATA_DIR / "course_db.json")))


@dataclass(frozen=True)
class EmbeddingConfig:
    model_name: str = os.getenv("RESUME_ANALYZER_EMBED_MODEL", "all-MiniLM-L6-v2")


@dataclass(frozen=True)
class VectorStoreConfig:
    persist_directory: str = str(VECTOR_DB_DIR)
    collection_name: str = "jobs"


@dataclass(frozen=True)
class RetrievalConfig:
    top_k: int = 4


# ---------------------------------------------------------------------------
# Legacy scoring weights
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ScoringWeights:
    semantic_similarity: float = 0.40
    skill_match: float = 0.40
    experience_match: float = 0.20

    def validate(self) -> None:
        total = self.semantic_similarity + self.skill_match + self.experience_match
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"ScoringWeights must sum to 1.0, got {total}")


# ---------------------------------------------------------------------------
# New 8-step scoring model weights
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CategoryWeights:
    skills_match: float = 0.30
    experience_match: float = 0.25
    industry_match: float = 0.15
    education_match: float = 0.10
    certification_match: float = 0.05
    achievement_score: float = 0.05
    ats_compatibility: float = 0.05
    resume_quality: float = 0.05

    def validate(self) -> None:
        total = (
            self.skills_match
            + self.experience_match
            + self.industry_match
            + self.education_match
            + self.certification_match
            + self.achievement_score
            + self.ats_compatibility
            + self.resume_quality
        )
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"CategoryWeights must sum to 1.0, got {total}")


@dataclass(frozen=True)
class RatingBands:
    excellent: float = 90.0
    very_good: float = 80.0
    good: float = 70.0
    average: float = 50.0
    poor: float = 0.0


@dataclass(frozen=True)
class SkillExtractionConfig:
    similarity_threshold: float = 0.68


@dataclass(frozen=True)
class APIConfig:
    host: str = os.getenv("RESUME_ANALYZER_API_HOST", "0.0.0.0")
    port: int = int(os.getenv("RESUME_ANALYZER_API_PORT", "8000"))
    cors_origins: tuple[str, ...] = tuple(
        origin.strip()
        for origin in os.getenv(
            "RESUME_ANALYZER_CORS_ORIGINS",
            "http://localhost:5173,http://127.0.0.1:5173",
        ).split(",")
        if origin.strip()
    )


@dataclass(frozen=True)
class Settings:
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    vector_store: VectorStoreConfig = field(default_factory=VectorStoreConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    scoring_weights: ScoringWeights = field(default_factory=ScoringWeights)
    category_weights: CategoryWeights = field(default_factory=CategoryWeights)
    rating_bands: RatingBands = field(default_factory=RatingBands)
    skill_extraction: SkillExtractionConfig = field(default_factory=SkillExtractionConfig)
    api: APIConfig = field(default_factory=APIConfig)
    job_db_path: Path = JOB_DB_PATH
    course_db_path: Path = COURSE_DB_PATH


settings = Settings()
settings.scoring_weights.validate()
settings.category_weights.validate()
