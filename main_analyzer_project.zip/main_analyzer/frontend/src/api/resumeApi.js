/**
 * resumeApi.js
 *
 * The single place that talks to the FastAPI backend (`api.py`). Every
 * component calls into these functions instead of calling `fetch` directly,
 * so there is exactly one spot to change if a route, base URL, or error
 * format ever changes.
 */
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

/**
 * Extract a readable error message from a failed fetch Response.
 */
async function extractErrorMessage(response) {
  try {
    const body = await response.json();
    if (body && typeof body.detail === 'string') return body.detail;
  } catch {
    // Response wasn't JSON - fall through to the generic message below.
  }
  return `Request failed with status ${response.status}`;
}

/**
 * Upload a resume file (.pdf or .docx) and get back the full analysis
 * report: parsed resume + ranked job matches (similarity, skill gap, ATS
 * score, insights, course recommendations, and learning roadmap).
 */
export async function analyzeResume(file, { signal } = {}) {
  const formData = new FormData();
  formData.append('file', file);

  let response;
  try {
    response = await fetch(`${API_BASE_URL}/api/analyze`, {
      method: 'POST',
      body: formData,
      signal,
    });
  } catch {
    throw new Error(
      `Could not reach the AI server at ${API_BASE_URL}. Is the backend (uvicorn api:app) running?`
    );
  }

  if (!response.ok) {
    throw new Error(await extractErrorMessage(response));
  }

  return response.json();
}

/**
 * Simple readiness check against the backend's /api/health route.
 */
export async function checkBackendHealth() {
  const response = await fetch(`${API_BASE_URL}/api/health`);
  if (!response.ok) {
    throw new Error(await extractErrorMessage(response));
  }
  return response.json();
}

/**
 * Get a personalized, LLM-generated explanation of a single job match
 * analysis (instead of raw score percentages). `jobMatch` is whatever
 * analysis object is already in frontend state for that match.
 */
export async function explainJobMatch(jobMatch, { resumeText, candidateName, signal } = {}) {
  const response = await fetch(`${API_BASE_URL}/api/tutor/explain`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      job_match: jobMatch,
      resume_text: resumeText,
      candidate_name: candidateName,
    }),
    signal,
  });
  if (!response.ok) {
    throw new Error(await extractErrorMessage(response));
  }
  return response.json();
}

/**
 * Ask the tutor a follow-up question about a job match analysis.
 * `conversation` is the running [{role, content}] history kept in state.
 */
export async function askTutor(jobMatch, message, conversation = [], { candidateName, signal } = {}) {
  const response = await fetch(`${API_BASE_URL}/api/tutor/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      job_match: jobMatch,
      message,
      conversation,
      candidate_name: candidateName,
    }),
    signal,
  });
  if (!response.ok) {
    throw new Error(await extractErrorMessage(response));
  }
  return response.json();
}
