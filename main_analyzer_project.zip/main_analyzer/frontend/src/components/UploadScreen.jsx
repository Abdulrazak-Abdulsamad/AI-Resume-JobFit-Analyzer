import { useState, useCallback } from 'react';
import { UploadCloud, FileText, CheckCircle2, Replace, ArrowRight } from 'lucide-react';

function UploadScreen({ onUploadComplete, onBack }) {
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  }, []);

  const handleChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (selectedFile) => {
    setFile(selectedFile);
    setUploadSuccess(false);
    setProgress(0);
  };

  const simulateUpload = () => {
    setIsUploading(true);
    setProgress(0);
    let step = 0;
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          setUploadSuccess(true);
          return 100;
        }
        const next = prev + 2;
        if (next > 30 && step === 0) { step = 1; }
        if (next > 60 && step === 1) { step = 2; }
        return next;
      });
    }, 60);
  };

  const handleContinue = () => {
    onUploadComplete(file);
  };

  const handleReplace = () => {
    setFile(null);
    setUploadSuccess(false);
    setProgress(0);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg">
        <button
          onClick={onBack}
          className="text-sm text-gray-500 hover:text-gray-700 mb-6 flex items-center gap-1"
        >
          ← Back to Home
        </button>

        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Upload Your Resume</h2>
            <p className="text-gray-500">Supported formats: PDF, DOCX, TXT</p>
          </div>

          {!uploadSuccess ? (
            <>
              <div
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
                className={`relative border-2 border-dashed rounded-xl p-10 text-center transition-colors ${
                  dragActive
                    ? 'border-indigo-400 bg-indigo-50'
                    : 'border-gray-300 hover:border-gray-400 bg-gray-50'
                }`}
              >
                <input
                  type="file"
                  accept=".pdf,.docx,.txt"
                  onChange={handleChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <UploadCloud className="w-10 h-10 text-gray-400 mx-auto mb-3" />
                {file ? (
                  <div className="flex items-center justify-center gap-2 text-indigo-700 font-medium">
                    <FileText className="w-5 h-5" />
                    {file.name}
                  </div>
                ) : (
                  <p className="text-gray-500">
                    Drag & drop your resume here, or <span className="text-indigo-600 font-medium">browse</span>
                  </p>
                )}
              </div>

              {file && !isUploading && (
                <button
                  onClick={simulateUpload}
                  className="w-full mt-6 bg-indigo-600 text-white py-3 rounded-xl font-semibold hover:bg-indigo-700 transition-colors"
                >
                  Upload Resume
                </button>
              )}

              {isUploading && (
                <div className="mt-6">
                  <div className="flex justify-between text-sm text-gray-600 mb-2">
                    <span>Processing Resume... Extracting experience</span>
                    <span>{Math.min(progress, 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-8 animate-fade-in">
              <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Resume Uploaded Successfully</h3>
              <p className="text-gray-500 mb-6">Your resume has been processed and is ready for analysis.</p>
              <div className="flex gap-3 justify-center">
                <button
                  onClick={handleReplace}
                  className="inline-flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-xl text-gray-700 font-medium hover:bg-gray-50"
                >
                  <Replace className="w-4 h-4" />
                  Replace File
                </button>
                <button
                  onClick={handleContinue}
                  className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-2 rounded-xl font-semibold hover:bg-indigo-700"
                >
                  Continue to Target Role
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default UploadScreen;
