import { CheckCircle2 } from 'lucide-react';

function getCourseUrl(course) {
  const rawUrl = course?.url || course?.link;
  if (rawUrl && typeof rawUrl === 'string' && rawUrl.startsWith('http')) {
    return rawUrl;
  }
  const title = course?.course_title || course?.title || 'course';
  const platform = course?.platform || course?.provider || '';
  return `https://www.google.com/search?q=${encodeURIComponent(`${title} ${platform} course`.trim())}`;
}

function RoadmapTab({ roadmap }) {
  if (!roadmap || !roadmap.phases || roadmap.phases.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <p className="text-sm">No learning roadmap available for this role.</p>
      </div>
    );
  }

  return (
    <div>
      <h3 className="text-lg font-bold text-gray-900 mb-6">Your Learning Roadmap</h3>
      <div className="relative">
        <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200" />

        <div className="space-y-8">
          {roadmap.phases.map((phase) => (
            <div key={phase.phase_number} className="relative pl-16">
              <div className="absolute left-4 top-0 w-5 h-5 rounded-full bg-indigo-600 border-4 border-white shadow-sm z-10" />

              <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                      Phase {phase.phase_number}
                    </span>
                    <h4 className="text-xl font-bold text-gray-900 mt-1">{phase.title}</h4>
                  </div>
                  {phase.difficulty && (
                    <span className="text-xs font-medium text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                      {phase.difficulty}
                    </span>
                  )}
                </div>

                {phase.objective && (
                  <p className="text-sm text-gray-600 mb-4">{phase.objective}</p>
                )}

                {phase.focus_skills && phase.focus_skills.length > 0 && (
                  <div className="mb-4">
                    <div className="text-sm font-semibold text-gray-500 mb-2">Focus Skills</div>
                    <div className="flex flex-wrap gap-2">
                      {phase.focus_skills.map((skill) => (
                        <span
                          key={skill}
                          className="px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-sm font-medium"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {phase.courses && phase.courses.length > 0 && (
                  <div className="mb-4">
                    <div className="text-sm font-semibold text-gray-500 mb-2">Courses</div>
                    <ul className="space-y-2">
                      {phase.courses.map((course, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                          <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                          <span>
                            <a
                              href={getCourseUrl(course)}
                              target="_blank"
                              rel="noreferrer"
                              className="font-semibold text-indigo-600 hover:text-indigo-800 hover:underline"
                            >
                              {course.course_title || course.title}
                            </a>
                            <span className="text-gray-400"> - {course.platform} ({course.difficulty})</span>
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {phase.milestones && phase.milestones.length > 0 && (
                  <div>
                    <div className="text-sm font-semibold text-gray-500 mb-2">Milestones</div>
                    <ul className="space-y-2">
                      {phase.milestones.map((milestone, j) => (
                        <li key={j} className="flex items-start gap-2 text-sm text-gray-700">
                          <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                          {milestone}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {phase.expected_outcome && (
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <div className="text-sm font-semibold text-gray-900 mb-1">Expected Outcome</div>
                    <p className="text-sm text-gray-600">{phase.expected_outcome}</p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default RoadmapTab;
