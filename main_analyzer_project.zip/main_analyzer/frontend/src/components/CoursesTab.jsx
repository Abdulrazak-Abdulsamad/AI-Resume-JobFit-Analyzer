import { ExternalLink } from 'lucide-react';

const PLATFORM_COLORS = {
  Coursera: 'bg-blue-50 text-blue-700 border-blue-100',
  Udemy: 'bg-purple-50 text-purple-700 border-purple-100',
  YouTube: 'bg-red-50 text-red-700 border-red-100',
  'YouTube (freeCodeCamp)': 'bg-red-50 text-red-700 border-red-100',
  edX: 'bg-teal-50 text-teal-700 border-teal-100',
  DataCamp: 'bg-orange-50 text-orange-700 border-orange-100',
  Codecademy: 'bg-indigo-50 text-indigo-700 border-indigo-100',
  freeCodeCamp: 'bg-green-50 text-green-700 border-green-100',
  'AWS Skill Builder': 'bg-amber-50 text-amber-700 border-amber-100',
  'Microsoft Learn': 'bg-sky-50 text-sky-700 border-sky-100',
  'Google Cloud Skills Boost': 'bg-emerald-50 text-emerald-700 border-emerald-100',
  'LinkedIn Learning': 'bg-blue-50 text-blue-700 border-blue-100',
};

function getCourseUrl(course) {
  const rawUrl = course?.url || course?.link;
  if (rawUrl && typeof rawUrl === 'string' && rawUrl.startsWith('http')) {
    return rawUrl;
  }
  const title = course?.course_title || course?.title || 'course';
  const platform = course?.platform || course?.provider || '';
  return `https://www.google.com/search?q=${encodeURIComponent(`${title} ${platform} course`.trim())}`;
}

function CoursesTab({ courses }) {
  if (!courses || courses.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <p className="text-sm">No course recommendations available for this role.</p>
      </div>
    );
  }

  return (
    <div>
      <h3 className="text-lg font-bold text-gray-900 mb-4">Recommended Courses</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {courses.map((course, i) => (
          <div
            key={i}
            className="bg-white border border-gray-200 rounded-xl p-5 hover:shadow-md transition-shadow flex flex-col"
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-bold text-gray-900 mb-1">{course.title || course.course_title}</h4>
                <span
                  className={`inline-block text-xs font-semibold px-2 py-0.5 rounded-full border ${
                    PLATFORM_COLORS[course.provider || course.platform] || 'bg-gray-50 text-gray-700 border-gray-100'
                  }`}
                >
                  {course.provider || course.platform}
                </span>
              </div>
              {course.certificate && (
                <span className="text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-100 px-2 py-0.5 rounded-full shrink-0">
                  Certificate
                </span>
              )}
            </div>

            <div className="flex items-center gap-3 text-sm text-gray-500 mb-3">
              <span>{course.duration || course.estimated_duration}</span>
              <span
                className={`font-medium px-2 py-0.5 rounded-full text-xs ${
                  (course.difficulty || '') === 'Beginner'
                    ? 'bg-green-100 text-green-700'
                    : (course.difficulty || '') === 'Intermediate'
                    ? 'bg-amber-100 text-amber-700'
                    : 'bg-red-100 text-red-700'
                }`}
              >
                {course.difficulty}
              </span>
            </div>

            {course.skills_covered && course.skills_covered.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-3">
                {course.skills_covered.map((skill) => (
                  <span
                    key={skill}
                    className="px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 text-xs font-medium border border-indigo-100"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            )}

            {course.reason && (
              <p className="text-xs text-gray-500 mb-3 leading-relaxed">{course.reason}</p>
            )}

            <a
              href={getCourseUrl(course)}
              target="_blank"
              rel="noreferrer"
              className="mt-auto inline-flex items-center gap-1 text-sm font-semibold text-indigo-600 hover:text-indigo-700"
            >
              View Course
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CoursesTab;
