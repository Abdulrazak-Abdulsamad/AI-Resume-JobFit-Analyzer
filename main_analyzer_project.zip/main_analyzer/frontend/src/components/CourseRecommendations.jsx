const DIFFICULTY_CLASSES = {
  Beginner: 'bg-green-100 text-green-700',
  Intermediate: 'bg-yellow-100 text-yellow-700',
  Advanced: 'bg-red-100 text-red-700',
};

function DifficultyBadge({ difficulty }) {
  const classes = DIFFICULTY_CLASSES[difficulty] ?? 'bg-gray-100 text-gray-700';
  return (
    <span className={`px-2 py-0.5 rounded text-xs font-semibold ${classes}`}>
      {difficulty}
    </span>
  );
}

/**
 * CourseRecommendations.jsx
 *
 * Renders the Course Recommendation stage's output: one ordered course
 * list per missing skill, exactly as produced by
 * `course_recommender.recommender_service`.
 */
function getCourseUrl(course) {
  const rawUrl = course?.url || course?.link;
  if (rawUrl && typeof rawUrl === 'string' && rawUrl.startsWith('http')) {
    return rawUrl;
  }
  const title = course?.course_title || course?.title || 'course';
  const platform = course?.platform || course?.provider || '';
  return `https://www.google.com/search?q=${encodeURIComponent(`${title} ${platform} course`.trim())}`;
}

function CourseRecommendations({ skillRecommendations }) {
  if (!skillRecommendations || skillRecommendations.length === 0) return null;

  return (
    <div className="border-t pt-4 bg-gray-50 p-4 rounded-lg mt-4">
      <h4 className="font-bold text-gray-800 mb-4">Course Recommendations</h4>
      <div className="space-y-4">
        {skillRecommendations.map((skillGroup) => (
          <div key={skillGroup.skill}>
            <span className="text-sm font-bold text-blue-800 uppercase tracking-wider mb-2 block border-b pb-1">
              To learn: {skillGroup.skill}
            </span>
            <div className="space-y-2">
              {skillGroup.courses.map((course) => (
                <div
                  key={`${course.skill}-${course.recommended_order}`}
                  className="flex justify-between items-center p-3 bg-white border rounded hover:border-blue-300 transition-colors"
                >
                  <div>
                    <span className="text-sm font-bold text-gray-800 block">
                      {course.recommended_order}. {course.course_title}
                    </span>
                    <span className="text-xs text-gray-500 flex items-center gap-2 mt-1">
                      {course.platform} · {course.estimated_duration}
                      <DifficultyBadge difficulty={course.difficulty} />
                    </span>
                  </div>
                  <a
                    href={getCourseUrl(course)}
                    target="_blank"
                    rel="noreferrer"
                    className="text-sm text-white bg-blue-600 px-3 py-1 rounded hover:bg-blue-700 shrink-0 ml-4"
                  >
                    View
                  </a>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CourseRecommendations;
export { DifficultyBadge };
