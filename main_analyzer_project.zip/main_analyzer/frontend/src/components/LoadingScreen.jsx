import { useState, useEffect, useRef } from 'react';
import { Loader2, AlertCircle, RefreshCw, ArrowRight } from 'lucide-react';
import { analyzeResume } from '../api/resumeApi';
import { calculateAnalysis } from '../data/mockData';

const LOADING_STEPS = [
  'Parsing resume structure...',
  'Extracting skills...',
  'Matching job market...',
  'Calculating ATS score...',
  'Generating learning roadmap...',
];

function formatBackendReport(report, fallbackJob) {
  if (!report || !report.job_matches || report.job_matches.length === 0) {
    return null;
  }
  const topMatch = report.best_match || report.job_matches[0];
  const scoreObj = topMatch.score || {};
  const skillsObj = topMatch.skills || {};
  const expObj = topMatch.experience || {};
  const parsed = report.parsed_resume || {};

  const categoryScores = {
    ats_score: Math.round(scoreObj.ats_score || scoreObj.final_fit_score || 85),
    skill_match_score: Math.round(scoreObj.skill_match_score || 80),
    experience_match_score: Math.round(scoreObj.experience_match_score || 80),
    industry_match_score: Math.round(scoreObj.industry_match_score || 75),
    education_match_score: Math.round(scoreObj.education_match_score || 90),
    certification_match_score: Math.round(scoreObj.certification_match_score || 85),
    achievement_score: Math.round(scoreObj.achievement_score || 70),
    resume_quality_score: Math.round(scoreObj.resume_quality_score || 85),
  };

  const matchingSkills = skillsObj.matching_skills || [];
  const missingSkills = skillsObj.missing_skills || [];
  const recBundle = topMatch.course_recommendations || {};
  const skillRecs = recBundle.skill_recommendations || [];

  // Extract flat list of courses for CoursesTab
  const coursesList = skillRecs.flatMap((group) =>
    (group.courses || []).map((c) => ({
      ...c,
      id: c.course_title || c.title,
      title: c.course_title || c.title,
      provider: c.platform || c.provider || 'Coursera',
      url: c.url || c.link || '',
    }))
  );

  // Extract skillGaps structure for SkillGapTab
  const skillGaps = missingSkills.map((sk) => ({
    name: sk,
    skill: sk,
    status: 'missing',
    priority: 'High',
    candidateLevel: 'None',
    requiredLevel: 'Proficient',
  }));

  return {
    ...topMatch,
    jobMatchScore: Math.round(scoreObj.final_fit_score || 80),
    atsScore: categoryScores.ats_score,
    skillMatchScore: categoryScores.skill_match_score,
    experienceScore: categoryScores.experience_match_score,
    targetRole: topMatch.job_title || fallbackJob?.title || 'Target Role',
    targetSector: topMatch.sector || fallbackJob?.sector || 'General',
    categoryScores,
    matchingSkills,
    acquiredSkills: matchingSkills,
    missingSkills,
    skillGaps,
    courses: coursesList,
    courseRecommendations: skillRecs,
    roadmap: recBundle.roadmap || { phases: [], total_courses: 0 },
    jobMatches: report.job_matches,
    parsedResume: parsed,
    candidate_name: parsed.name || 'Candidate',
  };
}

function LoadingScreen({ uploadedFile, selectedJob, resumeData, onComplete }) {
  const [step, setStep] = useState(0);
  const [error, setError] = useState(null);
  const isAnalyzing = useRef(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setStep((prev) => (prev < LOADING_STEPS.length - 1 ? prev + 1 : prev));
    }, 700);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (isAnalyzing.current) return;
    isAnalyzing.current = true;

    async function runAnalysis() {
      if (uploadedFile) {
        try {
          const report = await analyzeResume(uploadedFile);
          const formatted = formatBackendReport(report, selectedJob);
          if (formatted) {
            setTimeout(() => onComplete && onComplete(formatted), 500);
            return;
          }
        } catch (err) {
          console.warn('Backend analyze API error, using local fallback:', err);
          setError(err.message || 'Could not connect to backend analyzer.');
        }
      }

      // Fallback calculation if uploadedFile is missing or API failed
      if (selectedJob && resumeData) {
        const fallbackAnalysis = calculateAnalysis(resumeData, selectedJob);
        setTimeout(() => onComplete && onComplete(fallbackAnalysis), 600);
      } else {
        setTimeout(() => onComplete && onComplete(null), 600);
      }
    }

    runAnalysis();
  }, [uploadedFile, selectedJob, resumeData, onComplete]);

  const handleProceedFallback = () => {
    if (selectedJob && resumeData) {
      const fallbackAnalysis = calculateAnalysis(resumeData, selectedJob);
      onComplete && onComplete(fallbackAnalysis);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center px-4">
      <div className="text-center max-w-md w-full">
        <Loader2 className="w-16 h-16 text-indigo-600 animate-spin-slow mx-auto mb-6" />
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Analyzing Your Profile</h2>

        <div className="space-y-3 mb-6">
          {LOADING_STEPS.map((text, i) => (
            <div
              key={i}
              className={`text-sm transition-all duration-300 ${
                i <= step ? 'text-indigo-600 font-medium' : 'text-gray-300'
              }`}
            >
              {i <= step ? (
                <span className="inline-flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
                  {text}
                </span>
              ) : (
                text
              )}
            </div>
          ))}
        </div>

        {error && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-left mb-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-semibold text-amber-800">Backend Notice</h4>
                <p className="text-xs text-amber-700 mt-1">{error}</p>
                <button
                  onClick={handleProceedFallback}
                  className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-white bg-amber-600 px-3 py-1.5 rounded-lg hover:bg-amber-700"
                >
                  Proceed with Demo Analysis
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default LoadingScreen;
