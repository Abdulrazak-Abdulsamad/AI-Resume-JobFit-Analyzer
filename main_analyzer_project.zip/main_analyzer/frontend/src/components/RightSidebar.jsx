import { FileText, Target, BarChart3, Gauge } from 'lucide-react';

const NAV_ITEMS = [
  { step: 0, label: 'Home', icon: FileText },
  { step: 1, label: 'Upload', icon: FileText },
  { step: 2, label: 'Target Role', icon: Target },
  { step: 3, label: 'Analysis', icon: BarChart3 },
  { step: 4, label: 'Results', icon: Gauge },
];

function RightSidebar({ currentStep, onNavigate, selectedJob }) {
  return (
    <div className="fixed right-0 top-0 h-screen w-20 bg-white border-l border-gray-200 flex flex-col items-center py-6 z-50">
      <div className="mb-8">
        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
          <span className="text-white font-bold text-lg">K</span>
        </div>
      </div>

      <nav className="flex-1 flex flex-col gap-2 w-full px-3">
        {NAV_ITEMS.map((item) => {
          const isActive = currentStep === item.step;
          const isClickable = currentStep > item.step || item.step === 0;
          return (
            <button
              key={item.step}
              onClick={() => isClickable && onNavigate(item.step)}
              disabled={!isClickable}
              className={`w-full flex flex-col items-center gap-1 py-3 rounded-xl transition-all ${
                isActive
                  ? 'bg-indigo-50 text-indigo-700'
                  : isClickable
                  ? 'text-gray-400 hover:text-gray-600 hover:bg-gray-50'
                  : 'text-gray-200 cursor-not-allowed'
              }`}
              title={item.label}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

    </div>
  );
}

export default RightSidebar;
