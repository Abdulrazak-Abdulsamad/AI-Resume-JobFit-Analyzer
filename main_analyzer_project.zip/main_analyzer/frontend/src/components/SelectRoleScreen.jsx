import { useState, useMemo } from 'react';
import { Search, CheckCircle2, ArrowRight, Target } from 'lucide-react';
import jobsData from '../data/job_db.json';

function SelectRoleScreen({ onSelectRole, onBack }) {
  const [search, setSearch] = useState('');
  const [selectedRole, setSelectedRole] = useState(null);

  const filteredRoles = useMemo(() => {
    if (!search.trim()) return jobsData;
    const q = search.toLowerCase();
    return jobsData.filter(
      (r) =>
        r.title.toLowerCase().includes(q) ||
        r.sector.toLowerCase().includes(q) ||
        r.required_skills.some((skill) => skill.toLowerCase().includes(q))
    );
  }, [search]);

  const handleContinue = () => {
    if (selectedRole) onSelectRole(selectedRole);
  };

  return (
    <div className="min-h-screen bg-slate-50 px-4 py-12">
      <div className="max-w-6xl mx-auto">
        <button
          onClick={onBack}
          className="text-sm text-gray-500 hover:text-gray-700 mb-6 flex items-center gap-1"
        >
          ← Back
        </button>

        <h2 className="text-3xl font-bold text-gray-900 mb-2">Select Your Target Role</h2>
        <p className="text-gray-500 mb-8">Choose the role you want to analyze your fit for.</p>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search roles..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-3">
            <div className="max-h-[520px] overflow-y-auto pr-2 space-y-3">
              {filteredRoles.map((role, index) => (
                <button
                  key={`${role.title}-${role.sector}-${index}`}
                  onClick={() => setSelectedRole(role)}
                  className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                    selectedRole?.title === role.title && selectedRole?.sector === role.sector
                      ? 'border-indigo-600 bg-indigo-50 shadow-sm'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-gray-900">{role.title}</h3>
                      <span className="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                        {role.sector}
                      </span>
                    </div>
                    {selectedRole?.title === role.title && selectedRole?.sector === role.sector && (
                      <CheckCircle2 className="w-5 h-5 text-indigo-600" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-7">
            {selectedRole ? (
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-8 animate-fade-in sticky top-8">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{selectedRole.title}</h3>
                    <span className="text-sm font-medium text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full mt-2 inline-block">
                      {selectedRole.sector}
                    </span>
                  </div>
                </div>

                <p className="text-gray-600 mb-6 leading-relaxed">
                  Requires {selectedRole.minimum_work_experience_years}+ years of experience.
                </p>

                <div className="mb-8">
                  <div className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">
                    Core Requirements
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedRole.required_skills.map((req) => (
                      <span
                        key={req}
                        className="px-3 py-1.5 rounded-full bg-gray-100 text-gray-700 text-sm font-medium"
                      >
                        {req}
                      </span>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleContinue}
                  className="w-full inline-flex items-center justify-center gap-2 bg-indigo-600 text-white py-3.5 rounded-xl font-semibold hover:bg-indigo-700 transition-colors"
                >
                  Analyze Match
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-12 text-center h-full flex flex-col items-center justify-center min-h-[400px]">
                <Target className="w-12 h-12 text-gray-300 mb-4" />
                <p className="text-gray-500">Select a role to view details</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default SelectRoleScreen;
