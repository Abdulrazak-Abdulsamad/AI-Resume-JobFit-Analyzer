import { useState } from 'react';
import SkillChips from './SkillChips';
import CourseRecommendations from './CourseRecommendations';
import LearningRoadmap from './LearningRoadmap';
import { getJobMatchCardScoreColor, getJobMatchCardRatingBadgeColor } from '../utils/scoreColors';

function MetricTile({ label, value }) {
  return (
    <div className="p-4 bg-gray-50 rounded-lg text-center border">
      <div className="text-gray-500 text-xs font-bold uppercase mb-1">{label}</div>
      <div className="font-bold text-gray-900 text-lg">{value}%</div>
    </div>
  );
}

/**
 * JobMatchCard.jsx
 *
 * One ranked job match end-to-end. By default only the job title and main
 * score are visible. Click the header to expand/collapse the detailed
 * analysis (similarity, skill gap, experience, strengths, weaknesses,
 * course recommendations, and learning roadmap).
 */
function JobMatchCard({ match }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const bundle = match.course_recommendations;
  const scoreColor = getJobMatchCardScoreColor(match.score.final_fit_score);
  const ratingBadgeColor = getJobMatchCardRatingBadgeColor(match.score.final_fit_score);

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 mb-6">
      <div
        className="flex justify-between items-center cursor-pointer select-none"
        onClick={() => setIsExpanded((prev) => !prev)}
      >
        <div className="flex items-center gap-3">
          <h3 className="text-xl font-bold text-gray-800">{match.job_title}</h3>
          <span className={`text-xs font-bold px-2 py-1 rounded-full ${ratingBadgeColor}`}>
            {match.score.rating}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className={`block text-2xl font-bold ${scoreColor}`}>{match.score.final_fit_score}%</span>
          </div>
          <svg
            className={`w-5 h-5 text-gray-400 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </div>

      {isExpanded && (
        <div className="mt-6 animate-fade-in">
          <div className="grid grid-cols-3 gap-4 mb-6">
            <MetricTile label="Similarity" value={match.similarity.combined_score} />
            <MetricTile label="Skill Match" value={match.skills.skill_match_percentage} />
            <MetricTile label="Experience Match" value={match.experience.match_percentage} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <h4 className="font-bold text-green-700 mb-2">Matching Skills</h4>
              <SkillChips skills={match.skills.matching_skills} variant="green" />
            </div>
            <div>
              <h4 className="font-bold text-red-700 mb-2">Missing Skills</h4>
              <SkillChips skills={match.skills.missing_skills} variant="red" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
            <div>
              <h4 className="font-bold text-green-700 mb-2">Strengths</h4>
              <ul className="list-disc pl-5 text-gray-600 text-sm space-y-1">
                {match.strengths.map((s) => <li key={s}>{s}</li>)}
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-red-700 mb-2">Weaknesses</h4>
              <ul className="list-disc pl-5 text-gray-600 text-sm space-y-1">
                {match.weaknesses.map((w) => <li key={w}>{w}</li>)}
              </ul>
            </div>
          </div>

          <div className="mb-2">
            <h4 className="font-bold text-gray-800 mb-2">Improvement Suggestions</h4>
            <ul className="list-disc pl-5 text-gray-600 text-sm space-y-1">
              {match.improvement_suggestions.map((s) => <li key={s}>{s}</li>)}
            </ul>
          </div>

          {bundle && bundle.skill_recommendations.length > 0 ? (
            <>
              <CourseRecommendations skillRecommendations={bundle.skill_recommendations} />
              <LearningRoadmap roadmap={bundle.roadmap} />
            </>
          ) : (
            <p className="text-sm text-gray-500 border-t pt-4 mt-4">
              No missing skills detected for this role — no courses needed!
            </p>
          )}
        </div>
      )}
    </div>
  );
}

export default JobMatchCard;
