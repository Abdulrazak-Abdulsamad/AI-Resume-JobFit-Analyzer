import { useState, useEffect } from 'react';
import { LayoutDashboard, Briefcase, ListChecks, BookOpen, Route, AlertTriangle, Sparkles } from 'lucide-react';
import ScoreGauge from './ScoreGauge';
import RadarChartComponent from './RadarChartComponent';
import SummaryCards from './SummaryCards';
import SkillGapIndicator from './SkillGapIndicator';
import JobMatchesTab from './JobMatchesTab';
import SkillGapTab from './SkillGapTab';
import CoursesTab from './CoursesTab';
import RoadmapTab from './RoadmapTab';
import TutorChatTab from './TutorChatTab';

const TABS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'job-matches', label: 'Job Matches', icon: Briefcase },
  { id: 'skill-gaps', label: 'Skill Gaps', icon: ListChecks },
  { id: 'courses', label: 'Courses', icon: BookOpen },
  { id: 'roadmap', label: 'Roadmap', icon: Route },
  { id: 'tutor', label: 'AI Tutor', icon: Sparkles },
];

const TAB_HASH_MAP = {
  'dashboard': '#dashboard',
  'job-matches': '#job-matches',
  'skill-gaps': '#skill-gaps',
  'courses': '#courses',
  'roadmap': '#roadmap',
  'tutor': '#tutor',
};

function getTabFromHash() {
  const hash = window.location.hash.replace('#', '');
  if (hash && TAB_HASH_MAP[hash]) return hash;
  return 'dashboard';
}

function Dashboard({ analysis }) {
  const [activeTab, setActiveTab] = useState(getTabFromHash);

  useEffect(() => {
    const handleHashChange = () => {
      const tab = getTabFromHash();
      setActiveTab(tab);
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const switchTab = (tabId) => {
    setActiveTab(tabId);
    window.location.hash = TAB_HASH_MAP[tabId];
  };

  const categoryScores = analysis.categoryScores || {
    ats_score: analysis.atsScore || 0,
    skill_match_score: analysis.skillMatchScore || 0,
    experience_match_score: analysis.experienceScore || 0,
    industry_match_score: 0,
    education_match_score: 0,
    certification_match_score: 0,
    achievement_score: 0,
    resume_quality_score: 0,
  };

  const missingSkills = analysis.missingSkills || analysis.missing_skills || [];
  const acquiredSkills = analysis.acquiredSkills || analysis.matchingSkills || analysis.matching_skills || [];
  const skillGaps = analysis.skillGaps || [];
  const totalRequired = skillGaps.length || (acquiredSkills.length + missingSkills.length);

  return (
    <div className="max-w-6xl mx-auto px-6 py-8 animate-fade-in">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-3xl font-bold text-gray-900">
            {analysis.targetRole || analysis.job_title || 'Role'} Match
          </h1>
          <span className="text-sm text-gray-500 font-medium">Prepared for {analysis.candidate_name || 'Candidate'}</span>
        </div>
        {(analysis.targetSector || analysis.sector) && (
          <span className="inline-block text-sm font-medium text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full mt-2">
            {analysis.targetSector || analysis.sector}
          </span>
        )}
      </div>

      <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden mb-8">
        <div className="flex border-b border-gray-200 overflow-x-auto">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => switchTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-4 text-sm font-semibold transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/50'
                  : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-6 md:p-8">
          {activeTab === 'dashboard' && (
            <div className="animate-fade-in space-y-8">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <ScoreGauge value={analysis.atsScore || categoryScores.ats_score} label="ATS Score" size={140} strokeWidth={10} />
                <ScoreGauge value={categoryScores.resume_quality_score} label="Resume Quality Score" size={140} strokeWidth={10} />
                <ScoreGauge value={analysis.skillMatchScore || categoryScores.skill_match_score} label="Skill Match Score" size={140} strokeWidth={10} />
                <ScoreGauge value={analysis.experienceScore || categoryScores.experience_match_score} label="Experience & Seniority" size={140} strokeWidth={10} />
              </div>

              <SummaryCards
                jobScore={analysis.jobMatchScore || analysis.score?.final_fit_score}
                categoryScores={categoryScores}
                missingSkills={missingSkills.length}
              />

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Score Breakdown</h3>
                  <RadarChartComponent categoryScores={categoryScores} />
                </div>

                <SkillGapIndicator missingSkills={missingSkills} totalRequired={totalRequired} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-green-50/50 rounded-xl p-6 border border-green-200">
                  <h4 className="font-bold text-gray-900 mb-3">Acquired Skills</h4>
                  <div className="flex flex-wrap gap-2">
                    {acquiredSkills.length > 0 ? (
                      acquiredSkills.map((skill) => (
                        <span
                          key={skill}
                          className="px-3 py-1.5 rounded-full bg-green-100 text-green-800 text-sm font-semibold border border-green-200"
                        >
                          {skill}
                        </span>
                      ))
                    ) : (
                      <span className="text-xs text-gray-400">No specific matching skills listed</span>
                    )}
                  </div>
                </div>
                <div className="bg-red-50/50 rounded-xl p-6 border-2 border-red-200">
                  <div className="flex items-center gap-2 mb-3">
                    <AlertTriangle className="w-5 h-5 text-red-600" />
                    <h4 className="font-bold text-red-900">Missing Skills</h4>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {missingSkills.length > 0 ? (
                      missingSkills.map((skill) => (
                        <span
                          key={skill}
                          className="px-3 py-1.5 rounded-full bg-red-100 text-red-800 text-sm font-semibold border border-red-200"
                        >
                          {skill}
                        </span>
                      ))
                    ) : (
                      <span className="text-xs text-green-700 font-medium">No missing skills required for this position!</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'job-matches' && (
            <div className="animate-fade-in">
              <JobMatchesTab jobs={analysis.jobMatches} />
            </div>
          )}

          {activeTab === 'skill-gaps' && (
            <div className="animate-fade-in">
              <SkillGapTab
                skillGaps={analysis.skillGaps}
                missingSkills={analysis.missingSkills}
              />
            </div>
          )}

          {activeTab === 'courses' && (
            <div className="animate-fade-in">
              <CoursesTab courses={analysis.courses} />
            </div>
          )}

          {activeTab === 'roadmap' && (
            <div className="animate-fade-in">
              <RoadmapTab roadmap={analysis.roadmap} />
            </div>
          )}

          {activeTab === 'tutor' && <TutorChatTab analysis={analysis} />}
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
