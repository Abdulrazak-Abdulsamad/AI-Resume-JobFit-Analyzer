import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from 'recharts';

function RadarChartComponent({ categoryScores }) {
  const data = [
    { subject: 'ATS', score: categoryScores.ats_score || 0, fullMark: 100 },
    { subject: 'Skills', score: categoryScores.skill_match_score || 0, fullMark: 100 },
    { subject: 'Industry', score: categoryScores.industry_match_score || 0, fullMark: 100 },
    { subject: 'Education', score: categoryScores.education_match_score || 0, fullMark: 100 },
    { subject: 'Certs', score: categoryScores.certification_match_score || 0, fullMark: 100 },
  ];

  return (
    <ResponsiveContainer width="100%" height={300}>
      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
        <PolarGrid />
        <PolarAngleAxis dataKey="subject" tick={{ fill: '#4b5563', fontSize: 12 }} />
        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#9ca3af', fontSize: 10 }} />
        <Radar
          name="Score"
          dataKey="score"
          stroke="#5B50E5"
          fill="#5B50E5"
          fillOpacity={0.3}
          strokeWidth={2}
        />
      </RadarChart>
    </ResponsiveContainer>
  );
}

export default RadarChartComponent;
