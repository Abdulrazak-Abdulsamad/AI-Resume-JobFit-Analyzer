import { useEffect, useRef, useState } from 'react';
import { Sparkles, Send, Loader2 } from 'lucide-react';
import { explainJobMatch, askTutor } from '../api/resumeApi';

/**
 * New tab, additive to the existing Dashboard tabs. Reads the same
 * `analysis` object the rest of the Dashboard already renders and asks
 * the new /api/tutor/* backend routes for a personalized explanation and
 * a follow-up chat - none of the existing tabs/components change.
 */
function cleanText(str) {
  if (!str) return '';
  return str.replace(/\*\*/g, '');
}

function TutorChatTab({ analysis }) {
  const [explanation, setExplanation] = useState(null);
  const [loadingExplanation, setLoadingExplanation] = useState(true);
  const [error, setError] = useState(null);

  const [messages, setMessages] = useState([]); // [{role, content}]
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    setLoadingExplanation(true);
    setError(null);

    explainJobMatch(analysis)
      .then((res) => {
        if (cancelled) return;
        setExplanation(res);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoadingExplanation(false);
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, sending]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || sending) return;

    const nextMessages = [...messages, { role: 'user', content: text }];
    setMessages(nextMessages);
    setInput('');
    setSending(true);
    setError(null);

    try {
      const res = await askTutor(analysis, text, messages);
      setMessages([...nextMessages, { role: 'assistant', content: res.reply }]);
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-indigo-600" />
        <h3 className="text-lg font-bold text-gray-900">Ask the AI Tutor</h3>
      </div>

      <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
        {loadingExplanation && (
          <div className="flex items-center gap-2 text-gray-500 text-sm">
            <Loader2 className="w-4 h-4 animate-spin" />
            Reading your results and putting together a personalized explanation...
          </div>
        )}

        {!loadingExplanation && error && !explanation && (
          <div className="text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-xl p-4">
            Couldn't reach the tutor: {error}
            <div className="text-amber-600 mt-1">
              (Make sure Ollama or your local LLM server is running locally on <code>http://localhost:11434</code>.)
            </div>
          </div>
        )}

        {explanation && (
          <div className="space-y-4">
            <p className="text-gray-800 whitespace-pre-line leading-relaxed">{cleanText(explanation.explanation)}</p>

            {explanation.keywords?.length > 0 && (
              <div>
                <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                  Key phrases detected in your resume
                </div>
                <div className="flex flex-wrap gap-2">
                  {explanation.keywords.map((kw) => (
                    <span key={kw} className="text-xs font-medium bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-full">
                      {kw}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {explanation.readability && Object.keys(explanation.readability).length > 0 && (
              <div className="text-xs text-gray-500">
                Readability - Flesch Reading Ease:{' '}
                <span className="font-semibold text-gray-700">{explanation.readability.flesch_reading_ease}</span>
                {' · '}Flesch-Kincaid Grade:{' '}
                <span className="font-semibold text-gray-700">{explanation.readability.flesch_kincaid_grade}</span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="bg-white border border-gray-200 rounded-2xl shadow-sm flex flex-col h-96">
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.length === 0 && (
            <p className="text-sm text-gray-400">Ask anything about your results - e.g. "why is my skill match low?"</p>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm whitespace-pre-line ${
                  m.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-800'
                }`}
              >
                {cleanText(m.content)}
              </div>
            </div>
          ))}
          {sending && (
            <div className="flex justify-start">
              <div className="bg-gray-100 text-gray-500 rounded-2xl px-4 py-2.5 text-sm flex items-center gap-2">
                <Loader2 className="w-3.5 h-3.5 animate-spin" /> Thinking...
              </div>
            </div>
          )}
        </div>

        <div className="border-t border-gray-200 p-4 flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask the tutor a question..."
            className="flex-1 rounded-xl border border-gray-200 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={handleSend}
            disabled={sending || !input.trim()}
            className="rounded-xl bg-indigo-600 text-white p-2.5 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-indigo-700 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default TutorChatTab;
