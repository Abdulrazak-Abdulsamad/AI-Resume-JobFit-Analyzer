import { TrendingUp, Award, AlertCircle } from 'lucide-react';
import { getSummaryCardColorClass, SUMMARY_CARD_COLOR_CLASSES } from '../utils/scoreColors';

function SummaryCards({ jobScore, categoryScores, missingSkills }) {
  const bestCategory = Object.entries(categoryScores).reduce((best, [key, value]) => {
    const label = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    return value > best.value ? { label, value } : best;
  }, { label: 'N/A', value: 0 });

  const overallColor = getSummaryCardColorClass(jobScore);
  const bestColor = getSummaryCardColorClass(bestCategory.value);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      <div className={`p-6 rounded-2xl border-2 ${overallColor} transition-all duration-300 hover:shadow-lg hover:scale-[1.02] cursor-pointer`}>
        <div className="flex items-center justify-between mb-2">
          <TrendingUp className="w-6 h-6" />
          <span className="text-xs font-semibold uppercase tracking-wider opacity-75">Overall</span>
        </div>
        <div className="text-3xl font-bold mb-1">{Math.round(jobScore)}%</div>
        <div className="text-sm opacity-90">Job Score</div>
      </div>

      <div className={`p-6 rounded-2xl border-2 ${bestColor} transition-all duration-300 hover:shadow-lg hover:scale-[1.02] cursor-pointer`}>
        <div className="flex items-center justify-between mb-2">
          <Award className="w-6 h-6" />
          <span className="text-xs font-semibold uppercase tracking-wider opacity-75">Best</span>
        </div>
        <div className="text-2xl font-bold mb-1 truncate">{bestCategory.label}</div>
        <div className="text-sm opacity-90">{Math.round(bestCategory.value)}%</div>
      </div>

      <div className={`p-6 rounded-2xl border-2 ${missingSkills > 0 ? SUMMARY_CARD_COLOR_CLASSES.red : SUMMARY_CARD_COLOR_CLASSES.green} transition-all duration-300 hover:shadow-lg hover:scale-[1.02] cursor-pointer`}>
        <div className="flex items-center justify-between mb-2">
          <AlertCircle className="w-6 h-6" />
          <span className="text-xs font-semibold uppercase tracking-wider opacity-75">Gaps</span>
        </div>
        <div className="text-3xl font-bold mb-1">{missingSkills}</div>
        <div className="text-sm opacity-90">Missing Skills</div>
      </div>
    </div>
  );
}

export default SummaryCards;
