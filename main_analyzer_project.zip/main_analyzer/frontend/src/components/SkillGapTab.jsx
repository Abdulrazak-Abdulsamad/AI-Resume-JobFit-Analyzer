import { AlertCircle, CheckCircle2 } from 'lucide-react';

function SkillGapTab({ skillGaps, missingSkills }) {
  const safeMissing = Array.isArray(missingSkills) ? missingSkills : [];
  const safeGaps = Array.isArray(skillGaps) ? skillGaps : [];

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-lg font-bold text-gray-900 mb-4">Critical Missing Skills</h3>
        <div className="flex flex-wrap gap-2">
          {safeMissing.length > 0 ? (
            safeMissing.map((skill) => (
              <span
                key={typeof skill === 'string' ? skill : skill.skill || skill.name}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-50 text-red-700 text-sm font-medium border border-red-100"
              >
                <AlertCircle className="w-3.5 h-3.5" />
                {typeof skill === 'string' ? skill : skill.skill || skill.name}
              </span>
            ))
          ) : (
            <p className="text-sm text-green-700 font-medium">No critical missing skills detected for this position!</p>
          )}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-bold text-gray-900 mb-4">Technical Skill Analysis</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {safeGaps.length > 0 ? (
            safeGaps.map((skill, idx) => {
              const name = skill.name || skill.skill || `Skill ${idx + 1}`;
              const isMissing = skill.status === 'missing' || skill.candidateLevel === 'None';
              const priority = skill.priority || skill.importance || 'High';
              return (
                <div
                  key={name}
                  className={`flex items-center justify-between p-4 rounded-xl border ${
                    isMissing ? 'bg-red-50 border-red-100' : 'bg-green-50 border-green-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {isMissing ? (
                      <AlertCircle className="w-5 h-5 text-red-500" />
                    ) : (
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                    )}
                    <span className="font-medium text-gray-900">{name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs font-bold px-2 py-1 rounded-full ${
                        priority === 'High'
                          ? 'bg-red-100 text-red-700'
                          : 'bg-amber-100 text-amber-700'
                      }`}
                    >
                      {priority}
                    </span>
                    <span
                      className={`text-xs font-bold px-2 py-1 rounded-full ${
                        isMissing ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                      }`}
                    >
                      {isMissing ? 'MISSING' : 'ACQUIRED'}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <p className="text-sm text-gray-500 col-span-2">Skill breakdown analysis complete.</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default SkillGapTab;
