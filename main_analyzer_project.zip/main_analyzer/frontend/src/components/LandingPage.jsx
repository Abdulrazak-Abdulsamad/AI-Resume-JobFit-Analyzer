import { Sparkles, ArrowRight, FileText, Target, BarChart3 } from 'lucide-react';

function LandingPage({ onStart }) {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center px-4 py-16">
      <div className="max-w-3xl mx-auto text-center animate-fade-in">
        <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-50 text-indigo-700 text-sm font-semibold mb-8 border border-indigo-100">
          <Sparkles className="w-4 h-4" />
          AI-Powered Career Intelligence
        </span>

        <h1 className="text-5xl md:text-6xl font-extrabold text-gray-900 tracking-tight mb-6 leading-tight">
          Stop guessing.<br />
          <span className="text-indigo-600">Start ascending.</span>
        </h1>

        <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto mb-10 leading-relaxed">
          Upload your resume. Select your target role. Get a precision breakdown of your
          skill gaps, ATS readiness, and a personalized learning roadmap.
        </p>

        <button
          onClick={onStart}
          className="inline-flex items-center gap-2 bg-indigo-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 hover:shadow-xl hover:shadow-indigo-300 hover:-translate-y-0.5"
        >
          Analyze My Resume
          <ArrowRight className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20">
          {[
            { icon: FileText, title: 'Upload Resume', desc: 'Drag & drop your PDF, DOCX, or TXT resume' },
            { icon: Target, title: 'Set Target Role', desc: 'Choose from dozens of in-demand career paths' },
            { icon: BarChart3, title: 'Get Insights', desc: 'Receive scores, gaps, courses, and a roadmap' },
          ].map((step, i) => (
            <div
              key={i}
              className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center mb-4 mx-auto">
                <step.icon className="w-6 h-6 text-indigo-600" />
              </div>
              <div className="text-xs font-bold text-indigo-600 uppercase tracking-wider mb-2">
                Step {i + 1}
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{step.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default LandingPage;
