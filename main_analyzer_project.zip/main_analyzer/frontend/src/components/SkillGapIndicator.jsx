function SkillGapIndicator({ missingSkills, totalRequired }) {
  const gapCount = missingSkills?.length || 0;
  const percentage = totalRequired > 0 ? Math.round((gapCount / totalRequired) * 100) : 0;

  const getColor = () => {
    if (percentage < 30) return { bg: 'bg-green-500', text: 'text-green-700', label: 'Low Gap' };
    if (percentage < 60) return { bg: 'bg-amber-500', text: 'text-amber-700', label: 'Medium Gap' };
    return { bg: 'bg-red-500', text: 'text-red-700', label: 'High Gap' };
  };

  const color = getColor();

  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-gray-900">Skill Gap</h3>
        <span className={`text-xs font-bold px-3 py-1 rounded-full ${color.text} bg-opacity-10 ${color.bg.replace('bg-', 'bg-').replace('-500', '-100')}`}>
          {color.label}
        </span>
      </div>

      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-600">Missing Skills</span>
          <span className="text-sm font-bold text-gray-900">{gapCount} / {totalRequired}</span>
        </div>
        <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
          <div
            className={`${color.bg} h-3 rounded-full transition-all duration-700 ease-out`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>

      {missingSkills && missingSkills.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {missingSkills.slice(0, 6).map((skill, i) => (
            <span
              key={i}
              className="px-3 py-1 rounded-full bg-red-50 text-red-700 text-xs font-medium border border-red-100"
            >
              {skill}
            </span>
          ))}
          {missingSkills.length > 6 && (
            <span className="px-3 py-1 rounded-full bg-gray-100 text-gray-600 text-xs font-medium">
              +{missingSkills.length - 6} more
            </span>
          )}
        </div>
      )}
    </div>
  );
}

export default SkillGapIndicator;
