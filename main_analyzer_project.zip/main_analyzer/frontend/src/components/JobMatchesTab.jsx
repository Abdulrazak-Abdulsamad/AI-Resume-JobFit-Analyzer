import { Briefcase, TrendingUp, Building2 } from 'lucide-react';
import { getRatingColor, getJobMatchesTabScoreColor } from '../utils/scoreColors';

function JobCard({ job, rank }) {
  const title = job.title || job.job_title || 'Position Match';
  const sector = job.sector || 'General';
  const score = Math.round(job.jobMatchScore || job.score?.final_fit_score || 0);
  const rating = job.rating || job.score?.rating || 'Match';
  const ratingColor = getRatingColor(rating);
  const scoreColor = getJobMatchesTabScoreColor(score);
  const reason = job.reason || job.whyMatch || (job.insights?.strengths?.length ? `Matched key requirements: ${job.insights.strengths.join(', ')}` : 'Relevant role match based on skill alignment.');

  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-indigo-50 flex items-center justify-center">
            <span className="text-sm font-bold text-indigo-600">#{rank}</span>
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">{title}</h3>
            <div className="flex items-center gap-1.5 text-sm text-gray-500 mt-0.5">
              <Building2 className="w-3.5 h-3.5" />
              {sector}
            </div>
          </div>
        </div>
        <div className={`text-right`}>
          <div className={`text-2xl font-bold ${scoreColor}`}>{score}%</div>
          <div className={`text-xs font-semibold px-2 py-0.5 rounded-full border mt-1 inline-block ${ratingColor}`}>
            {rating}
          </div>
        </div>
      </div>

      <div className="border-t border-gray-100 pt-4">
        <div className="flex items-center gap-1.5 text-sm text-gray-600 mb-2">
          <TrendingUp className="w-4 h-4 text-indigo-500" />
          <span className="font-semibold text-gray-900">Why this match?</span>
        </div>
        <p className="text-sm text-gray-600 leading-relaxed">{reason}</p>
      </div>
    </div>
  );
}

function JobMatchesTab({ jobs }) {
  const safeJobs = Array.isArray(jobs) ? jobs : [];
  const topJobs = safeJobs.slice(0, 3);

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Briefcase className="w-5 h-5 text-indigo-600" />
        <h3 className="text-lg font-bold text-gray-900">Top Job Matches</h3>
      </div>
      <div className="space-y-4">
        {topJobs.length > 0 ? (
          topJobs.map((job, i) => (
            <JobCard key={job.job_id || i} job={job} rank={i + 1} />
          ))
        ) : (
          <p className="text-sm text-gray-500">No job matches available.</p>
        )}
      </div>
      {safeJobs.length > 3 && (
        <p className="text-sm text-gray-500 mt-4 text-center">
          Showing top 3 of {safeJobs.length} matches
        </p>
      )}
    </div>
  );
}

export default JobMatchesTab;
