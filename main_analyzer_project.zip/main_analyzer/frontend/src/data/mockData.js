import jobsData from './job_db.json' with { type: 'json' };

export const MOCK_RESUME = {
  name: 'Alex Johnson',
  email: 'alex.johnson@email.com',
  phone: '+1 (555) 234-5678',
  total_experience_years: 5,
  skills: ['Python', 'JavaScript', 'SQL', 'Git', 'React', 'Node.js', 'Docker', 'AWS', 'Pandas', 'NumPy', 'TensorFlow', 'PyTorch'],
  experience: [
    {
      company: 'TechCorp AI',
      role: 'Machine Learning Engineer',
      dates: '2022 - Present',
      responsibilities: 'Built and deployed ML models using TensorFlow and PyTorch. Designed REST APIs for model serving. Containerized services with Docker. Collaborated with data scientists to productionize NLP and computer vision pipelines.',
      skills: ['Python', 'TensorFlow', 'PyTorch', 'Docker', 'AWS', 'FastAPI', 'Kubernetes'],
    },
    {
      company: 'DataFlow Systems',
      role: 'Backend Developer',
      dates: '2020 - 2022',
      responsibilities: 'Developed scalable backend services using Node.js and Python. Built RESTful APIs and GraphQL endpoints. Managed PostgreSQL databases and implemented caching with Redis. Participated in CI/CD pipeline design.',
      skills: ['Node.js', 'Python', 'PostgreSQL', 'Redis', 'GraphQL', 'Docker', 'AWS'],
    },
    {
      company: 'CloudScale Inc',
      role: 'IT Support Specialist',
      dates: '2018 - 2020',
      responsibilities: 'Provided technical support for internal systems. Managed user accounts and access controls. Troubleshot network and hardware issues. Maintained documentation for IT procedures.',
      skills: ['Windows Server', 'Active Directory', 'Networking', 'Hardware Troubleshooting', 'Ticketing Systems'],
    },
  ],
  education: [],
  certifications: [],
  achievements: [],
};

function _tokenize(text) {
  if (!text) return [];
  return text.toLowerCase().replace(/[^a-z0-9+#.-]/g, ' ').split(/\s+/).filter(t => t.length > 1);
}

function _clamp(value, min = 0, max = 100) {
  return Math.max(min, Math.min(max, value));
}

function scoreAts(resume) {
  let score = 0;
  if (resume.name) score += 15;
  if (resume.email) score += 15;
  if (resume.phone) score += 10;
  if (resume.skills && resume.skills.length > 3) score += 25;
  if (resume.total_experience_years > 0) score += 20;
  if (resume.education && resume.education.length > 0) score += 15;
  return _clamp(score);
}

function scoreIndustryMatch(targetIndustryYears, totalYears) {
  if (totalYears <= 0) return 0;
  return _clamp((targetIndustryYears / totalYears) * 100);
}

function scoreEducationMatch(education, requiredEducation) {
  if (!requiredEducation || !requiredEducation.length) return 100;
  const resumeDegrees = (education || []).map(e => (e.degree || '').toLowerCase()).join(' ');
  let matched = 0;
  for (const req of requiredEducation) {
    if (resumeDegrees.includes(req.toLowerCase())) matched++;
  }
  return _clamp((matched / requiredEducation.length) * 100);
}

function scoreCertificationMatch(certifications, requiredCerts) {
  if (!requiredCerts || !requiredCerts.length) return 100;
  let matched = 0;
  for (const req of requiredCerts) {
    if (certifications.some(c => c.toLowerCase().includes(req.toLowerCase()))) matched++;
  }
  return _clamp((matched / requiredCerts.length) * 100);
}

function scoreAchievements(achievements) {
  if (!achievements || !achievements.length) return 30;
  const quantified = achievements.filter(a => /%|\$|million|thousand|increased|reduced|improved|launched/i.test(a)).length;
  return _clamp(30 + (quantified / achievements.length) * 70);
}

function scoreResumeQuality(resume) {
  let score = 50;
  if (resume.name) score += 10;
  if (resume.email) score += 10;
  if (resume.phone) score += 5;
  if (resume.skills && resume.skills.length >= 5) score += 10;
  if (resume.education && resume.education.length > 0) score += 10;
  if (resume.experience && resume.experience.length > 0) score += 5;
  if (resume.achievements && resume.achievements.length > 0) score += 5;
  return _clamp(score);
}

function calculateExperienceRelevance(resume, job) {
  if (!resume || !job || !resume.experience || resume.experience.length === 0) {
    return {
      total_career_experience: resume?.total_experience_years || 0,
      target_sector_experience: 0,
      target_role_experience: 0,
      industry_breakdown: [],
      positions_counted: [],
      positions_excluded: [],
      reasoning: 'No experience entries provided.',
      role_relevance_score: 0,
    };
  }

  const targetRole = job.title || '';
  const targetSector = job.sector || '';
  const totalYears = resume.total_experience_years || 0;
  const entries = resume.experience;

  const roleTokens = new Set(_tokenize(targetRole));
  const sectorKeywords = {
    'information technology': ['software', 'developer', 'engineer', 'cloud', 'data', 'ml', 'ai', 'devops'],
    'healthcare': ['patient', 'clinical', 'medical', 'health', 'nurse', 'doctor', 'hospital'],
    'business & finance': ['finance', 'accounting', 'audit', 'tax', 'investment', 'banking'],
    'education': ['teaching', 'curriculum', 'instruction', 'classroom', 'student', 'learning'],
    'marketing & sales': ['marketing', 'advertising', 'campaign', 'brand', 'seo', 'sales'],
    'operations & logistics': ['logistics', 'supply chain', 'warehouse', 'inventory', 'procurement'],
  };
  const targetKeywords = sectorKeywords[targetSector.toLowerCase()] || [];

  const positionsCounted = [];
  const positionsExcluded = [];
  const industryBreakdown = [];
  let targetRoleYears = 0;
  let targetSectorYears = 0;

  const estimatedYearsPerPosition = totalYears / entries.length;

  entries.forEach((entry, idx) => {
    const company = entry.company || `Position ${idx + 1}`;
    const role = entry.role || '';
    const positionText = `${company} ${role}`.toLowerCase();

    const roleSimTokens = new Set(_tokenize(positionText));
    const roleMatches = [...roleTokens].filter(t => roleSimTokens.has(t));
    const roleSimilarity = roleTokens.size > 0 ? roleMatches.length / roleTokens.size : 0;

    const textTokens = new Set(_tokenize(positionText));
    const industryMatches = targetKeywords.length > 0 ? [...textTokens].filter(t => targetKeywords.includes(t)).length / targetKeywords.length : 0;

    const relevanceScore = Math.min(100, Math.max(0, (roleSimilarity * 0.6 + industryMatches * 0.4) * 100));

    let classification, multiplier;
    if (relevanceScore >= 70) {
      classification = 'Directly Relevant';
      multiplier = 1.0;
    } else if (relevanceScore >= 40) {
      classification = 'Partially Relevant';
      multiplier = relevanceScore / 100;
    } else {
      classification = 'Not Relevant';
      multiplier = 0;
    }

    const positionYears = estimatedYearsPerPosition;
    const countedYears = positionYears * multiplier;

    const positionData = {
      company,
      role_title: role,
      classification,
      relevance_score: Math.round(relevanceScore, 1),
      years: Math.round(positionYears, 1),
      target_role_years: Math.round(countedYears, 1),
    };

    if (classification === 'Not Relevant') {
      positionsExcluded.push(positionData);
    } else {
      positionsCounted.push(positionData);
      targetRoleYears += countedYears;
      targetSectorYears += classification === 'Directly Relevant' ? positionYears : positionYears * 0.7;
      industryBreakdown.push({
        industry: targetSector || 'General',
        years: Math.round(positionYears, 1),
        relevance_score: Math.round(relevanceScore, 1),
      });
    }
  });

  return {
    total_career_experience: totalYears,
    target_sector_experience: Math.round(targetSectorYears, 1),
    target_role_experience: Math.round(targetRoleYears, 1),
    industry_breakdown: industryBreakdown,
    positions_counted: positionsCounted,
    positions_excluded: positionsExcluded,
    reasoning: `${positionsCounted.length} positions counted, ${positionsExcluded.length} excluded. Target role experience: ${Math.round(targetRoleYears, 1)} years.`,
    role_relevance_score: totalYears > 0 ? Math.round((targetRoleYears / totalYears) * 100, 1) : 0,
  };
}

function scoreJob(resume, job) {
  const resumeSkills = (resume.skills || []).map((s) => s.toLowerCase().trim());
  const requiredSkills = (job.required_skills || []).map((s) => s.toLowerCase().trim());

  const matchedRequired = requiredSkills.filter((req) =>
    resumeSkills.some((rs) => rs.includes(req) || req.includes(rs))
  );

  const skillMatchScore = requiredSkills.length > 0 ? Math.round((matchedRequired.length / requiredSkills.length) * 100) : 0;

  const experienceRelevance = calculateExperienceRelevance(resume, job);
  const requiredExp = job.minimum_work_experience_years || 0;
  const experienceScore = requiredExp > 0
    ? Math.min(100, Math.round((experienceRelevance.target_role_experience / requiredExp) * 100))
    : 100;

  const atsScore = scoreAts(resume);
  const industryScore = scoreIndustryMatch(experienceRelevance.target_sector_experience, resume.total_experience_years);
  const educationScore = scoreEducationMatch(resume.education, []);
  const certScore = scoreCertificationMatch([], []);
  const achievementScore = scoreAchievements(resume.achievements || []);
  const resumeQualityScore = scoreResumeQuality(resume);

  const weights = {
    skills_match: 0.30,
    experience_match: 0.25,
    industry_match: 0.15,
    education_match: 0.10,
    certification_match: 0.05,
    achievement_score: 0.05,
    ats_compatibility: 0.05,
    resume_quality: 0.05,
  };

  const jobMatchScore = Math.round(
    skillMatchScore * weights.skills_match +
    experienceScore * weights.experience_match +
    industryScore * weights.industry_match +
    educationScore * weights.education_match +
    certScore * weights.certification_match +
    achievementScore * weights.achievement_score +
    atsScore * weights.ats_compatibility +
    resumeQualityScore * weights.resume_quality
  );

  return {
    jobMatchScore: _clamp(jobMatchScore),
    skillMatchScore,
    experienceScore,
    industryScore,
    atsScore,
    matchedRequired,
    missingSkills: requiredSkills.filter((req) => !resumeSkills.some((rs) => rs.includes(req) || req.includes(rs))),
  };
}

function getRatingLabel(score) {
  if (score >= 90) return 'Excellent Match';
  if (score >= 80) return 'Strong Match';
  if (score >= 70) return 'Good Match';
  if (score >= 60) return 'Moderate Match';
  if (score >= 50) return 'Fair Match';
  return 'Weak Match';
}

function generateReason(job, scores) {
  const matched = scores.matchedRequired.map(s => {
    const original = job.required_skills.find(rs => rs.toLowerCase().trim() === s);
    return original || s;
  });
  const missing = scores.missingSkills.map(s => {
    const original = job.required_skills.find(rs => rs.toLowerCase().trim() === s);
    return original || s;
  });

  const parts = [];
  if (matched.length > 0) {
    parts.push(`Strong background in ${matched.slice(0, 3).join(', ')}`);
  }
  if (scores.experienceScore >= 80) {
    parts.push('relevant experience aligns well');
  } else if (scores.experienceScore >= 50) {
    parts.push('some relevant experience');
  }
  if (missing.length > 0) {
    parts.push(`but missing ${missing.slice(0, 2).join(', ')}`);
  }

  if (parts.length === 0) {
    return 'Limited alignment with current profile.';
  }

  return parts.join(', ') + '.';
}

export function calculateTopJobMatches(resume, limit = 3) {
  if (!resume) return [];

  const scoredJobs = jobsData
    .map((job) => {
      const scores = scoreJob(resume, job);
      return {
        title: job.title,
        sector: job.sector,
        jobMatchScore: scores.jobMatchScore,
        skillMatchScore: scores.skillMatchScore,
        experienceMatchScore: scores.experienceScore,
        reason: generateReason(job, scores),
        rating: getRatingLabel(scores.jobMatchScore),
      };
    })
    .filter((job) => job.jobMatchScore >= 50)
    .sort((a, b) => {
      if (b.jobMatchScore !== a.jobMatchScore) return b.jobMatchScore - a.jobMatchScore;
      if (b.experienceMatchScore !== a.experienceMatchScore) return b.experienceMatchScore - a.experienceMatchScore;
      return b.skillMatchScore - a.skillMatchScore;
    })
    .slice(0, limit);

  return scoredJobs;
}

export function calculateAnalysis(resume, job) {
  if (!resume || !job) return null;

  const resumeSkills = (resume.skills || []).map((s) => s.toLowerCase().trim());
  const requiredSkills = (job.required_skills || []).map((s) => s.toLowerCase().trim());

  const matchedRequired = requiredSkills.filter((req) =>
    resumeSkills.some((rs) => rs.includes(req) || req.includes(rs))
  );

  const skillMatchScore = requiredSkills.length > 0 ? Math.round((matchedRequired.length / requiredSkills.length) * 100) : 0;

  const experienceRelevance = calculateExperienceRelevance(resume, job);
  const requiredExp = job.minimum_work_experience_years || 0;
  const experienceScore = requiredExp > 0
    ? Math.min(100, Math.round((experienceRelevance.target_role_experience / requiredExp) * 100))
    : 100;

  const atsScore = scoreAts(resume);
  const industryScore = scoreIndustryMatch(experienceRelevance.target_sector_experience, resume.total_experience_years);
  const educationScore = scoreEducationMatch(resume.education, []);
  const certScore = scoreCertificationMatch([], []);
  const achievementScore = scoreAchievements(experienceRelevance.achievements || []);
  const resumeQualityScore = scoreResumeQuality(resume);

  const categoryScores = {
    ats_score: atsScore,
    skill_match_score: skillMatchScore,
    experience_match_score: experienceScore,
    industry_match_score: industryScore,
    education_match_score: educationScore,
    certification_match_score: certScore,
    achievement_score: achievementScore,
    resume_quality_score: resumeQualityScore,
  };

  const weights = {
    skills_match: 0.30,
    experience_match: 0.25,
    industry_match: 0.15,
    education_match: 0.10,
    certification_match: 0.05,
    achievement_score: 0.05,
    ats_compatibility: 0.05,
    resume_quality: 0.05,
  };

  const jobMatchScore = Math.round(
    categoryScores.skill_match_score * weights.skills_match +
    categoryScores.experience_match_score * weights.experience_match +
    categoryScores.industry_match_score * weights.industry_match +
    categoryScores.education_match_score * weights.education_match +
    categoryScores.certification_match_score * weights.certification_match +
    categoryScores.achievement_score * weights.achievement_score +
    categoryScores.ats_score * weights.ats_compatibility +
    categoryScores.resume_quality_score * weights.resume_quality
  );

  const finalAtsFitScore = _clamp(jobMatchScore);

  const missingSkills = requiredSkills
    .filter((req) => !resumeSkills.some((rs) => rs.includes(req) || req.includes(rs)))
    .map((s) => {
      const original = job.required_skills.find((rs) => rs.toLowerCase().trim() === s);
      return original || s;
    });

  const acquiredSkills = matchedRequired.map((s) => {
    const original = job.required_skills.find((rs) => rs.toLowerCase().trim() === s);
    return original || s;
  });

  const skillGaps = requiredSkills.map((skill) => {
    const original = job.required_skills.find((rs) => rs.toLowerCase().trim() === skill);
    const isAcquired = matchedRequired.some((m) => m === skill);
    return {
      name: original || skill,
      priority: isAcquired ? 'Low' : 'High',
      status: isAcquired ? 'acquired' : 'missing',
    };
  });

  const topMatches = calculateTopJobMatches(resume, 3);

  const courses = generateMockCourses(missingSkills, job);
  const roadmap = generateMockRoadmap(courses, missingSkills);

  return {
    targetRole: job.title,
    targetSector: job.sector,
    atsScore,
    jobMatchScore,
    skillMatchScore,
    experienceScore,
    finalAtsFitScore,
    missingSkills,
    acquiredSkills,
    skillGaps,
    categoryScores,
    experienceRelevance,
    courses,
    roadmap,
    jobMatches: topMatches,
  };
}

const MOCK_COURSE_PROVIDERS = ['Coursera', 'Udemy', 'edX', 'DataCamp', 'Codecademy', 'freeCodeCamp'];
const MOCK_DIFFICULTIES = ['Beginner', 'Intermediate', 'Advanced'];

function generateMockCourses(missingSkills, job) {
  if (!missingSkills || missingSkills.length === 0) return [];
  return missingSkills.flatMap((skill) => {
    const baseTitle = skill.replace(/[^a-zA-Z0-9]/g, ' ');
    return MOCK_DIFFICULTIES.map((difficulty, idx) => ({
      id: `${skill.toLowerCase()}-${difficulty.toLowerCase()}`,
      title: `${baseTitle} ${difficulty} Course`,
      provider: MOCK_COURSE_PROVIDERS[idx % MOCK_COURSE_PROVIDERS.length],
      skills_covered: [skill],
      difficulty,
      duration: `${(idx + 1) * 4} weeks`,
      url: '#',
      certificate: difficulty === 'Advanced',
      reason: `Selected to help you learn ${skill} for your target role as ${job?.title || 'the position'}.`,
    }));
  });
}

function generateMockRoadmap(courses, _missingSkills) {
  if (!courses || courses.length === 0) return { phases: [] };

  const beginner = courses.filter((c) => c.difficulty === 'Beginner');
  const intermediate = courses.filter((c) => c.difficulty === 'Intermediate');
  const advanced = courses.filter((c) => c.difficulty === 'Advanced');

  const phases = [];
  if (beginner.length > 0) {
    phases.push({
      phaseNumber: 1,
      title: 'Foundation',
      objective: 'Build fundamental knowledge and core concepts required for the target role.',
      difficulty: 'Beginner',
      courses: beginner,
      focusSkills: [...new Set(beginner.flatMap((c) => c.skills_covered))],
      milestones: beginner.map((c) => `Complete ${c.title}`),
      expectedOutcome: 'Solid grasp of fundamental concepts and terminology.',
    });
  }
  if (intermediate.length > 0) {
    phases.push({
      phaseNumber: phases.length + 1,
      title: 'Core Skills',
      objective: 'Develop intermediate proficiency in the core technical skills for the target role.',
      difficulty: 'Intermediate',
      courses: intermediate,
      focusSkills: [...new Set(intermediate.flatMap((c) => c.skills_covered))],
      milestones: intermediate.map((c) => `Complete intermediate coursework for ${c.skills_covered[0]}`),
      expectedOutcome: 'Hands-on competence with core tools, frameworks, and workflows.',
    });
  }
  if (advanced.length > 0) {
    phases.push({
      phaseNumber: phases.length + 1,
      title: 'Advanced Skills',
      objective: 'Master advanced topics and specialized skills that distinguish top candidates.',
      difficulty: 'Advanced',
      courses: advanced,
      focusSkills: [...new Set(advanced.flatMap((c) => c.skills_covered))],
      milestones: advanced.map((c) => `Complete advanced training for ${c.skills_covered[0]}`),
      expectedOutcome: 'Deep expertise in advanced concepts and production-grade practices.',
    });
  }

  return {
    phases,
    skillsCovered: [...new Set(courses.flatMap((c) => c.skills_covered))],
    totalCourses: courses.length,
  };
}
