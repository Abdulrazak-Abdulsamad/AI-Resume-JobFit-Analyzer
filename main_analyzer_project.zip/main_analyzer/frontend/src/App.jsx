import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import UploadScreen from './components/UploadScreen';
import SelectRoleScreen from './components/SelectRoleScreen';
import LoadingScreen from './components/LoadingScreen';
import Dashboard from './components/Dashboard';
import RightSidebar from './components/RightSidebar';
import { MOCK_RESUME, calculateAnalysis } from './data/mockData';
import { analyzeResume } from './api/resumeApi';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('UI ErrorBoundary caught an exception:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 text-center">
          <div className="bg-white border border-gray-200 rounded-2xl p-8 max-w-md shadow-lg">
            <h2 className="text-xl font-bold text-gray-900 mb-2">Something went wrong</h2>
            <p className="text-sm text-gray-600 mb-6">
              {this.state.error?.message || 'An unexpected rendering error occurred.'}
            </p>
            <button
              onClick={() => {
                this.setState({ hasError: false });
                window.location.reload();
              }}
              className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-indigo-700"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  const [step, setStep] = useState(0);
  const [resumeData, setResumeData] = useState(MOCK_RESUME);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [selectedJob, setSelectedJob] = useState(null);
  const [analysisData, setAnalysisData] = useState(null);

  const goToStep = (newStep) => {
    setStep(newStep);
  };

  const handleStart = () => {
    setStep(1);
  };

  const handleUploadComplete = (file) => {
    setUploadedFile(file);
    setResumeData(MOCK_RESUME);
    setStep(2);
  };

  const handleSelectRole = (job) => {
    setSelectedJob(job);
    setStep(3);
  };

  const handleAnalysisComplete = (formattedAnalysis) => {
    if (formattedAnalysis) {
      setAnalysisData(formattedAnalysis);
    } else if (selectedJob && resumeData) {
      const analysis = calculateAnalysis(resumeData, selectedJob);
      setAnalysisData(analysis);
    }
    setStep(4);
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-slate-50 font-sans">
        {step > 0 && (
          <RightSidebar currentStep={step} onNavigate={goToStep} selectedJob={selectedJob} />
        )}

        <main className={step > 0 ? 'mr-20' : ''}>
          {step === 0 && <LandingPage onStart={handleStart} />}
          {step === 1 && (
            <UploadScreen onUploadComplete={handleUploadComplete} onBack={() => setStep(0)} />
          )}
          {step === 2 && (
            <SelectRoleScreen onSelectRole={handleSelectRole} onBack={() => setStep(1)} />
          )}
          {step === 3 && (
            <LoadingScreen
              uploadedFile={uploadedFile}
              selectedJob={selectedJob}
              resumeData={resumeData}
              onComplete={handleAnalysisComplete}
            />
          )}
          {step === 4 && analysisData && <Dashboard analysis={analysisData} />}
        </main>
      </div>
    </ErrorBoundary>
  );
}

export default App;
