/**
 * scoreColors.js
 *
 * Score -> Tailwind class helpers. Each component previously kept its own
 * copy of "if score >= N return some-class" logic; this file is the single
 * place that logic lives now. The three scales below (`jobMatchesTab`,
 * `jobMatchCard`, `summaryCard`) intentionally keep each component's exact
 * original thresholds/colors - they were subtly different designs, not
 * accidental copies of one another - so consolidating them here removes the
 * duplicated *shape* of the logic without changing any component's look.
 */

// Generic helper: walk an ordered list of [minScore, className] pairs and
// return the class for the first threshold the score satisfies.
function colorForScore(score, scale) {
  for (const [min, className] of scale) {
    if (score >= min) return className;
  }
  return scale[scale.length - 1][1];
}

// Used by JobMatchesTab (rating badge + big score, on white cards).
const RATING_SCALE = [
  ['Excellent', 'text-green-700 bg-green-50 border-green-200'],
  ['Strong', 'text-emerald-700 bg-emerald-50 border-emerald-200'],
  ['Good', 'text-blue-700 bg-blue-50 border-blue-200'],
  ['Moderate', 'text-amber-700 bg-amber-50 border-amber-200'],
  ['Fair', 'text-orange-700 bg-orange-50 border-orange-200'],
];
const DEFAULT_RATING_CLASS = 'text-red-700 bg-red-50 border-red-200';

export function getRatingColor(rating) {
  const match = RATING_SCALE.find(([keyword]) => rating.includes(keyword));
  return match ? match[1] : DEFAULT_RATING_CLASS;
}

const JOB_MATCHES_TAB_SCORE_SCALE = [
  [90, 'text-green-600'],
  [80, 'text-emerald-600'],
  [70, 'text-blue-600'],
  [60, 'text-amber-600'],
  [50, 'text-orange-600'],
  [0, 'text-red-600'],
];

export function getJobMatchesTabScoreColor(score) {
  return colorForScore(score, JOB_MATCHES_TAB_SCORE_SCALE);
}

const JOB_MATCH_CARD_TEXT_SCALE = [
  [90, 'text-emerald-600'],
  [80, 'text-blue-600'],
  [70, 'text-amber-600'],
  [50, 'text-orange-600'],
  [0, 'text-red-600'],
];

const JOB_MATCH_CARD_BADGE_SCALE = [
  [90, 'bg-emerald-100 text-emerald-700'],
  [80, 'bg-blue-100 text-blue-700'],
  [70, 'bg-amber-100 text-amber-700'],
  [50, 'bg-orange-100 text-orange-700'],
  [0, 'bg-red-100 text-red-700'],
];

export function getJobMatchCardScoreColor(score) {
  return colorForScore(score, JOB_MATCH_CARD_TEXT_SCALE);
}

export function getJobMatchCardRatingBadgeColor(score) {
  return colorForScore(score, JOB_MATCH_CARD_BADGE_SCALE);
}

export const SUMMARY_CARD_COLOR_CLASSES = {
  green: 'bg-green-50 border-green-200 text-green-700',
  yellow: 'bg-amber-50 border-amber-200 text-amber-700',
  red: 'bg-red-50 border-red-200 text-red-700',
};

const SUMMARY_CARD_SCALE = [
  [80, SUMMARY_CARD_COLOR_CLASSES.green],
  [50, SUMMARY_CARD_COLOR_CLASSES.yellow],
  [0, SUMMARY_CARD_COLOR_CLASSES.red],
];

export function getSummaryCardColorClass(score) {
  return colorForScore(score, SUMMARY_CARD_SCALE);
}
