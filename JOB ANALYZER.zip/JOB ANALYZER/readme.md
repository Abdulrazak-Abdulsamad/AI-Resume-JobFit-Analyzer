# AI Resume & Job Fit Analyzer

## Description

This project compares a resume with a job description using Natural Language Processing and Machine Learning.

It provides:

- Resume similarity score
- Skill gap analysis
- Resume fit score
- Predicted job role
- Recommended jobs
- Recommended courses

## Installation

```bash
pip install -r requirements.txt
```

## Train Model

```bash
python train_model.py
```

## Run

```bash
streamlit run app.py
```