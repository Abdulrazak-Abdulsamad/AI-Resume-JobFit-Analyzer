"""
skill_gap.py

Compares resume skills with required job skills.
Returns:
- Matching skills
- Missing skills
- Skill match percentage
"""

import re


class SkillGapAnalyzer:

    def __init__(self):
        pass

    def extract_skills(self, text, skill_database):
        """
        Extract skills from text using a predefined list of skills.

        Parameters:
            text (str): Resume or job description.
            skill_database (list): List of known skills.

        Returns:
            list: Skills found in the text.
        """

        text = text.lower()

        found_skills = []

        for skill in skill_database:

            if re.search(r"\b" + re.escape(skill.lower()) + r"\b", text):

                found_skills.append(skill)

        return sorted(list(set(found_skills)))

    def analyze(self, resume_text, job_text, skill_database):
        """
        Compare resume skills with job skills.
        """

        resume_skills = self.extract_skills(
            resume_text,
            skill_database
        )

        job_skills = self.extract_skills(
            job_text,
            skill_database
        )

        matching = sorted(
            list(
                set(resume_skills).intersection(job_skills)
            )
        )

        missing = sorted(
            list(
                set(job_skills).difference(resume_skills)
            )
        )

        if len(job_skills) == 0:
            percentage = 0
        else:
            percentage = (
                len(matching) /
                len(job_skills)
            ) * 100

        return {

            "resume_skills": resume_skills,

            "job_skills": job_skills,

            "matching_skills": matching,

            "missing_skills": missing,

            "skill_match_percentage":
                round(percentage, 2)

        }