"""
recommendation.py

Provides:
1. Job recommendations
2. Course recommendations
"""

class RecommendationEngine:

    def __init__(self):

        self.course_database = {

            "Python": "Python for Everybody (Coursera)",

            "SQL": "SQL for Data Science (Coursera)",

            "Power BI": "Microsoft Power BI (Microsoft Learn)",

            "Excel": "Excel Skills for Business (Coursera)",

            "Docker": "Docker Essentials (IBM)",

            "AWS": "AWS Cloud Practitioner Essentials",

            "Git": "Git and GitHub Crash Course",

            "Machine Learning": "Machine Learning by Andrew Ng",

            "Deep Learning": "Deep Learning Specialization",

            "TensorFlow": "TensorFlow Developer Certificate",

            "PyTorch": "PyTorch Fundamentals",

            "Java": "Java Programming Masterclass",

            "React": "React Complete Guide",

            "HTML": "HTML & CSS Bootcamp",

            "CSS": "CSS Flexbox and Grid",

            "JavaScript": "JavaScript Complete Course"
        }

        self.job_database = {

            "Data Analyst":[

                "Business Intelligence Analyst",

                "Reporting Analyst",

                "Junior Data Scientist"

            ],

            "Machine Learning Engineer":[

                "AI Engineer",

                "Computer Vision Engineer",

                "Data Scientist"

            ],

            "Frontend Developer":[

                "UI Developer",

                "React Developer",

                "Web Developer"

            ],

            "Backend Developer":[

                "Python Developer",

                "API Developer",

                "Software Engineer"

            ]
        }

    def recommend_courses(self, missing_skills):

        courses = []

        for skill in missing_skills:

            if skill in self.course_database:

                courses.append({

                    "skill": skill,

                    "course": self.course_database[skill]

                })

        return courses

    def recommend_jobs(self, predicted_role):

        return self.job_database.get(
            predicted_role,
            []
        )