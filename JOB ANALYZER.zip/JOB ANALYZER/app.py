import streamlit as st
from analyzer import ResumeAnalyzer

# -----------------------------------
# Skill Database
# -----------------------------------

SKILLS = [

    "Python",
    "SQL",
    "Power BI",
    "Excel",
    "Machine Learning",
    "Deep Learning",
    "TensorFlow",
    "PyTorch",
    "Docker",
    "Git",
    "AWS",
    "Java",
    "C++",
    "React",
    "HTML",
    "CSS",
    "JavaScript",
    "Django",
    "Flask",
    "MySQL",
    "PostgreSQL"

]

# -----------------------------------
# Streamlit UI
# -----------------------------------

st.title("AI Resume & Job Fit Analyzer")

st.write("Compare a resume with a job description.")

resume = st.text_area(
    "Resume Text",
    height=250
)

job = st.text_area(
    "Job Description",
    height=250
)

if st.button("Analyze Resume"):

    if resume.strip() == "" or job.strip() == "":

        st.warning("Please enter both the resume and job description.")

    else:

        analyzer = ResumeAnalyzer()

        result = analyzer.analyze(

            resume,

            job,

            SKILLS

        )

        st.header("Analysis Result")

        st.subheader("Predicted Role")

        st.write(result["predicted_role"])

        st.subheader("Role Confidence")

        st.write(f'{result["role_confidence"]}%')

        st.subheader("Resume Fit Score")

        st.write(result["resume_score"]["final_fit_score"])

        st.subheader("Rating")

        st.write(result["rating"])

        st.subheader("Similarity Scores")

        st.write(result["similarity"])

        st.subheader("Matching Skills")

        st.write(result["skills"]["matching_skills"])

        st.subheader("Missing Skills")

        st.write(result["skills"]["missing_skills"])

        st.subheader("Recommended Jobs")

        st.write(result["recommended_jobs"])

        st.subheader("Recommended Courses")

        st.write(result["recommended_courses"])


        