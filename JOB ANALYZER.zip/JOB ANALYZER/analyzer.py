"""
analyzer.py

Main pipeline that combines all AI modules.
"""

from similarity import SimilarityCalculator
from skill_gap import SkillGapAnalyzer
from role_prediction import RolePredictor
from scoring import ResumeScorer
from recommendation import RecommendationEngine


class ResumeAnalyzer:

    def __init__(self):

        self.similarity = SimilarityCalculator()

        self.skill_gap = SkillGapAnalyzer()

        self.role_predictor = RolePredictor()

        self.scorer = ResumeScorer()

        self.recommender = RecommendationEngine()

    def analyze(

        self,

        resume_text,

        job_description,

        skill_database

    ):

        # -----------------------------
        # Similarity
        # -----------------------------

        similarity_result = self.similarity.final_similarity(

            resume_text,

            job_description

        )

        # -----------------------------
        # Skill Gap
        # -----------------------------

        skill_result = self.skill_gap.analyze(

            resume_text,

            job_description,

            skill_database

        )

        # -----------------------------
        # Role Prediction
        # -----------------------------

        role_result = self.role_predictor.predict(

            resume_text

        )

        # -----------------------------
        # Final Resume Score
        # -----------------------------

        score_result = self.scorer.calculate_score(

            similarity_result["final_score"],

            skill_result["skill_match_percentage"],

            role_result["confidence"]

        )

        # -----------------------------
        # Rating
        # -----------------------------

        rating = self.scorer.rating(

            score_result["final_fit_score"]

        )

        # -----------------------------
        # Recommendations
        # -----------------------------

        courses = self.recommender.recommend_courses(

            skill_result["missing_skills"]

        )

        jobs = self.recommender.recommend_jobs(

            role_result["predicted_role"]

        )

        # -----------------------------
        # Final Output
        # -----------------------------

        return {

            "predicted_role":

                role_result["predicted_role"],

            "role_confidence":

                role_result["confidence"],

            "similarity":

                similarity_result,

            "skills":

                skill_result,

            "resume_score":

                score_result,

            "rating":

                rating,

            "recommended_jobs":

                jobs,

            "recommended_courses":

                courses

        }