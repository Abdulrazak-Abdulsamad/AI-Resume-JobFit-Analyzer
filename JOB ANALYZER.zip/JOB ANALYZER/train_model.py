from role_prediction import RolePredictor

print("Starting training...")

predictor = RolePredictor()

predictor.train("datasets/resume_roles.csv")

print("Training finished!")