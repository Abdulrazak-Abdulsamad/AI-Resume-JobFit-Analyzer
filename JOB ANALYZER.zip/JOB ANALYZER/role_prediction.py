"""
role_prediction.py

Train a machine learning model to predict
the best job role for a resume.
"""

import joblib
import pandas as pd

from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression


class RolePredictor:

    def __init__(self):

        self.model = joblib.load(
            "models/role_classifier.pkl"
        )


    def predict(self, resume_text):

        prediction = self.model.predict(
            [resume_text]
        )[0]


        probability = max(
            self.model.predict_proba(
                [resume_text]
            )[0]
        )


        return {

            "predicted_role": prediction,

            "confidence": round(
                probability * 100,
                2
            )

        }

    def train(self, csv_path):

        print("Step 1: Reading CSV...")

        data = pd.read_csv(csv_path)

        print(data.head())

        print("Columns:", data.columns.tolist())

        X = data["resume_text"]
        y = data["role"]

        print("Step 2: Training model...")

        self.model.fit(X, y)

        print("Step 3: Saving model...")

        joblib.dump(
            self.model,
            "models/role_classifier.pkl"
        )

        print("Model trained successfully!")


    def predict(self, resume_text):

        model = joblib.load(
            "models/role_classifier.pkl"
        )

        prediction = model.predict(
            [resume_text]
        )[0]

        probability = max(
            model.predict_proba([resume_text])[0]
        )

        return {

            "predicted_role": prediction,

            "confidence": round(
                probability * 100,
                2
            )

        }