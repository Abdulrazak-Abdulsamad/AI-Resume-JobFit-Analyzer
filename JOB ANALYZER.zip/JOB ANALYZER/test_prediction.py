from role_prediction import RolePredictor

predictor = RolePredictor()

resume = """
Frontend developer with 3 years experience.
Skills include HTML, CSS, JavaScript, React, Bootstrap,
Tailwind CSS, responsive web design, UI development,
and creating user-friendly web applications.
"""

result = predictor.predict(resume)

print("Predicted Role:", result["predicted_role"])
print("Confidence:", result["confidence"], "%")