"""
similarity.py

Calculates resume-job similarity using:

1. TF-IDF Cosine Similarity
2. Sentence Transformer Embeddings
"""

from sklearn.metrics.pairwise import cosine_similarity
from feature_extraction import FeatureExtractor


class SimilarityCalculator:

    def __init__(self):

        self.extractor = FeatureExtractor()

    def tfidf_similarity(self, resume_text, job_text):
        """
        Calculate keyword similarity using TF-IDF.
        """

        tfidf = self.extractor.tfidf_features(
            resume_text,
            job_text
        )

        similarity = cosine_similarity(
            tfidf[0:1],
            tfidf[1:2]
        )[0][0]

        return similarity

    def semantic_similarity(self, resume_text, job_text):
        """
        Calculate semantic similarity using embeddings.
        """

        resume_embedding, job_embedding = (
            self.extractor.embedding_features(
                resume_text,
                job_text
            )
        )

        similarity = cosine_similarity(
            [resume_embedding],
            [job_embedding]
        )[0][0]

        return similarity

    def final_similarity(self, resume_text, job_text):
        """
        Combine TF-IDF and Semantic similarity.
        """

        tfidf_score = self.tfidf_similarity(
            resume_text,
            job_text
        )

        semantic_score = self.semantic_similarity(
            resume_text,
            job_text
        )

        final_score = (
            tfidf_score * 0.4 +
            semantic_score * 0.6
        )

        return {
            "tfidf_score": round(tfidf_score * 100, 2),
            "semantic_score": round(semantic_score * 100, 2),
            "final_score": round(final_score * 100, 2)
        }