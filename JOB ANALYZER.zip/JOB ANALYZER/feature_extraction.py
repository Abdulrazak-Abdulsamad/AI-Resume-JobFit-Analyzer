"""
feature_extraction.py

Extracts text features from resumes and job descriptions.

Uses:
1. TF-IDF (keyword features)
2. Sentence Transformers (semantic embeddings)
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sentence_transformers import SentenceTransformer


class FeatureExtractor:

    def __init__(self):
        """
        Load the embedding model once when the class is created.
        """
        self.vectorizer = TfidfVectorizer(stop_words="english")
        self.embedding_model = SentenceTransformer(
            "all-MiniLM-L6-v2"
        )

    def tfidf_features(self, resume_text, job_text):
        """
        Convert resume and job description into TF-IDF vectors.
        """

        documents = [resume_text, job_text]

        tfidf_matrix = self.vectorizer.fit_transform(documents)

        return tfidf_matrix

    def embedding_features(self, resume_text, job_text):
        """
        Convert resume and job description into semantic embeddings.
        """

        resume_embedding = self.embedding_model.encode(resume_text)

        job_embedding = self.embedding_model.encode(job_text)

        return resume_embedding, job_embedding