"""
scoring.py

Calculates the final resume fit score.
"""


class ResumeScorer:

    def __init__(self):

        self.weights = {

            "similarity": 0.50,

            "skills": 0.30,

            "role": 0.20

        }

    def calculate_score(

        self,

        similarity_score,

        skill_match,

        role_confidence

    ):

        final_score = (

            similarity_score * self.weights["similarity"]

            +

            skill_match * self.weights["skills"]

            +

            role_confidence * self.weights["role"]

        )

        return {

            "similarity_score":

                round(similarity_score, 2),

            "skill_match":

                round(skill_match, 2),

            "role_confidence":

                round(role_confidence, 2),

            "final_fit_score":

                round(final_score, 2)

        }

    def rating(self, score):

        if score >= 90:

            return "Excellent Match"

        elif score >= 80:

            return "Very Good Match"

        elif score >= 70:

            return "Good Match"

        elif score >= 60:

            return "Average Match"

        else:

            return "Poor Match"