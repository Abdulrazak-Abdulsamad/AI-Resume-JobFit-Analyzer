"""
scoring.py (job_analyzer)

Combines the individual signals (semantic similarity, skill match,
experience match) into a single weighted ATS fit score, and translates that
score into a human-readable rating band. Weights come from the central
`config.settings` so they are tuned in exactly one place.
"""
from __future__ import annotations

from config import settings
from job_analyzer.schemas import ScoreResult


class ResumeScorer:
    def __init__(self) -> None:
        self.weights = settings.scoring_weights
        self.bands = settings.rating_bands

    def calculate_score(
        self,
        similarity_score: float,
        skill_match_percentage: float,
        experience_match_percentage: float,
    ) -> ScoreResult:
        final_score = (
            similarity_score * self.weights.semantic_similarity
            + skill_match_percentage * self.weights.skill_match
            + experience_match_percentage * self.weights.experience_match
        )

        return ScoreResult(
            similarity_score=round(similarity_score, 2),
            skill_match_score=round(skill_match_percentage, 2),
            experience_match_score=round(experience_match_percentage, 2),
            final_fit_score=round(final_score, 2),
            rating=self._rating(final_score),
        )

    def _rating(self, score: float) -> str:
        if score >= self.bands.excellent:
            return "Excellent Match"
        if score >= self.bands.very_good:
            return "Very Good Match"
        if score >= self.bands.good:
            return "Good Match"
        if score >= self.bands.average:
            return "Average Match"
        return "Poor Match"
