"""
schemas.py (job_analyzer)

Output data contracts for a single resume-vs-job analysis.
"""
from __future__ import annotations

from typing import List

from pydantic import BaseModel

from course_recommender.schemas import CourseRecommendationBundle


class SimilarityResult(BaseModel):
    tfidf_score: float
    semantic_score: float
    combined_score: float


class SkillGapResult(BaseModel):
    resume_skills: List[str]
    job_required_skills: List[str]
    matching_skills: List[str]
    missing_skills: List[str]
    skill_match_percentage: float


class ExperienceMatchResult(BaseModel):
    candidate_years: int
    required_years: int
    meets_requirement: bool
    match_percentage: float


class ScoreResult(BaseModel):
    similarity_score: float
    skill_match_score: float
    experience_match_score: float
    final_fit_score: float
    rating: str


class JobAnalysisResult(BaseModel):
    job_id: str
    job_title: str
    retrieval_similarity: float
    similarity: SimilarityResult
    skills: SkillGapResult
    experience: ExperienceMatchResult
    score: ScoreResult
    strengths: List[str]
    weaknesses: List[str]
    improvement_suggestions: List[str]
    # Populated from `skills.missing_skills` by the Course Recommendation
    # stage: recommended courses per missing skill plus the derived
    # beginner -> advanced learning roadmap for this job match.
    course_recommendations: CourseRecommendationBundle
