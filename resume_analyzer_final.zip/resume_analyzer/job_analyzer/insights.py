"""
insights.py (job_analyzer)

Generates strengths, weaknesses, and improvement suggestions for a
resume/job pairing. This replaces the original `recommendation.py`
(hardcoded course/job lookup dictionaries) entirely - insights here are
derived directly from the RAG-retrieved job's real requirements and the
computed skill-gap / experience-match / similarity signals, so they always
stay in sync with the job database instead of a separate static mapping.
"""
from __future__ import annotations

from typing import List

from job_analyzer.schemas import ExperienceMatchResult, ScoreResult, SkillGapResult


class InsightGenerator:
    @staticmethod
    def generate(
        skills: SkillGapResult,
        experience: ExperienceMatchResult,
        score: ScoreResult,
    ) -> tuple[List[str], List[str], List[str]]:
        strengths: List[str] = []
        weaknesses: List[str] = []
        suggestions: List[str] = []

        # --- Skills ---
        if skills.matching_skills:
            strengths.append(
                f"Strong overlap on {len(skills.matching_skills)} required skill(s): "
                f"{', '.join(skills.matching_skills)}."
            )
        if skills.missing_skills:
            weaknesses.append(
                f"Missing {len(skills.missing_skills)} required skill(s): "
                f"{', '.join(skills.missing_skills)}."
            )
            suggestions.append(
                "Build demonstrable experience (projects, certifications, or coursework) in: "
                f"{', '.join(skills.missing_skills)}."
            )

        # --- Experience ---
        if experience.meets_requirement:
            strengths.append(
                f"Meets or exceeds the required experience "
                f"({experience.candidate_years} vs {experience.required_years} year(s) required)."
            )
        else:
            gap_years = experience.required_years - experience.candidate_years
            weaknesses.append(
                f"Experience gap of {gap_years} year(s) "
                f"({experience.candidate_years} vs {experience.required_years} year(s) required)."
            )
            suggestions.append(
                "Highlight freelance work, internships, or personal projects that can offset "
                "the experience gap until the required tenure is reached."
            )

        # --- Overall similarity ---
        if score.similarity_score >= 70:
            strengths.append("Resume content is highly aligned with the job's overall context.")
        elif score.similarity_score < 40:
            weaknesses.append("Resume content shows low overall alignment with this role's context.")
            suggestions.append(
                "Tailor the resume summary and experience bullets to mirror the language used "
                "in this role's requirements."
            )

        if not strengths:
            strengths.append("No standout strengths identified for this specific role yet.")
        if not weaknesses:
            weaknesses.append("No significant gaps identified for this role.")
        if not suggestions:
            suggestions.append("Keep the resume updated as new skills and projects are completed.")

        return strengths, weaknesses, suggestions
