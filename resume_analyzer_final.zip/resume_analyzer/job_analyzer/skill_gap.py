"""
skill_gap.py (job_analyzer)

Compares the skills already extracted by the Resume Parser against the
`required_skills` of a job retrieved through the RAG pipeline. No skill
re-extraction happens here - both sides were produced against the same
canonical `SKILL_TAXONOMY`, so this is a straightforward set comparison.
"""
from __future__ import annotations

from typing import List

from job_analyzer.schemas import SkillGapResult


class SkillGapAnalyzer:
    @staticmethod
    def analyze(resume_skills: List[str], job_required_skills: List[str]) -> SkillGapResult:
        resume_set = {s.strip().lower() for s in resume_skills}
        job_set = {s.strip().lower() for s in job_required_skills}

        # Preserve original casing from the job's required_skills for display.
        display_by_lower = {s.strip().lower(): s.strip() for s in job_required_skills}
        display_by_lower.update({s.strip().lower(): s.strip() for s in resume_skills})

        matching = sorted(display_by_lower[s] for s in (resume_set & job_set))
        missing = sorted(display_by_lower[s] for s in (job_set - resume_set))

        match_percentage = (len(matching) / len(job_set) * 100) if job_set else 0.0

        return SkillGapResult(
            resume_skills=sorted(resume_skills),
            job_required_skills=sorted(job_required_skills),
            matching_skills=matching,
            missing_skills=missing,
            skill_match_percentage=round(match_percentage, 2),
        )
