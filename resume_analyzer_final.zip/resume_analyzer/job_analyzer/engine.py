"""
engine.py (job_analyzer)

The Job Analyzer's public entry point. Given a parsed resume, it:
  1. Retrieves candidate jobs EXCLUSIVELY through the RAG pipeline (never
     reads job_db.json or any job data directly).
  2. Scores the resume against each retrieved job (similarity, skill gap,
     experience match).
  3. Produces a final weighted ATS score, rating, and improvement insights
     for every retrieved job, ranked best-first.
  4. Feeds the detected missing skills into the Course Recommendation stage
     (`course_recommender`) to attach ordered course suggestions and a
     beginner -> advanced learning roadmap to each job match.
"""
from __future__ import annotations

from typing import List

from course_recommender.recommender_service import CourseRecommendationService
from job_analyzer.experience_matcher import ExperienceMatcher
from job_analyzer.insights import InsightGenerator
from job_analyzer.schemas import JobAnalysisResult
from job_analyzer.scoring import ResumeScorer
from job_analyzer.similarity import SimilarityCalculator
from job_analyzer.skill_gap import SkillGapAnalyzer
from rag.retriever import JobRetriever
from resume_parsing.schema import ParsedResume
from utils.logging_config import get_logger

logger = get_logger(__name__)


def _resume_to_text(resume: ParsedResume) -> str:
    """Flatten the parsed resume into free text for similarity scoring."""
    experience_text = " ".join(f"{e.company or ''} {e.role or ''}" for e in resume.experience)
    education_text = " ".join(f"{e.institution or ''} {e.degree or ''}" for e in resume.education)
    return " ".join([
        resume.name or "",
        ", ".join(resume.skills),
        education_text,
        experience_text,
    ]).strip()


class JobAnalyzer:
    """Orchestrates RAG retrieval + scoring + insight generation."""

    def __init__(
        self,
        retriever: JobRetriever,
        similarity_calculator: SimilarityCalculator | None = None,
        skill_gap_analyzer: SkillGapAnalyzer | None = None,
        experience_matcher: ExperienceMatcher | None = None,
        scorer: ResumeScorer | None = None,
        insight_generator: InsightGenerator | None = None,
        course_recommendation_service: CourseRecommendationService | None = None,
    ) -> None:
        self.retriever = retriever
        self.similarity_calculator = similarity_calculator or SimilarityCalculator()
        self.skill_gap_analyzer = skill_gap_analyzer or SkillGapAnalyzer()
        self.experience_matcher = experience_matcher or ExperienceMatcher()
        self.scorer = scorer or ResumeScorer()
        self.insight_generator = insight_generator or InsightGenerator()
        self.course_recommendation_service = course_recommendation_service or CourseRecommendationService()

    def analyze(self, resume: ParsedResume, top_k: int | None = None) -> List[JobAnalysisResult]:
        retrieved_jobs = self.retriever.retrieve_top_jobs(resume, top_k=top_k)
        if not retrieved_jobs:
            logger.warning("RAG pipeline returned no candidate jobs for this resume.")
            return []

        resume_text = _resume_to_text(resume)
        results: List[JobAnalysisResult] = []

        for job in retrieved_jobs:
            similarity = self.similarity_calculator.calculate(resume_text, job.context_text)
            skills = self.skill_gap_analyzer.analyze(resume.skills, job.required_skills)
            experience = self.experience_matcher.match(
                resume.total_experience_years, job.minimum_work_experience_years
            )
            score = self.scorer.calculate_score(
                similarity_score=similarity.combined_score,
                skill_match_percentage=skills.skill_match_percentage,
                experience_match_percentage=experience.match_percentage,
            )
            strengths, weaknesses, suggestions = self.insight_generator.generate(skills, experience, score)
            course_recommendations = self.course_recommendation_service.recommend_for_missing_skills(
                skills.missing_skills
            )

            results.append(JobAnalysisResult(
                job_id=job.job_id,
                job_title=job.title,
                retrieval_similarity=job.similarity_score,
                similarity=similarity,
                skills=skills,
                experience=experience,
                score=score,
                strengths=strengths,
                weaknesses=weaknesses,
                improvement_suggestions=suggestions,
                course_recommendations=course_recommendations,
            ))

        results.sort(key=lambda r: r.score.final_fit_score, reverse=True)
        return results
