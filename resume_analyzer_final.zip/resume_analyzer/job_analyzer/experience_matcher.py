"""
experience_matcher.py (job_analyzer)

Compares a candidate's total years of experience (from the parsed resume)
against a job's minimum required years (from the RAG-retrieved job record).
This closes the "experience matching" requirement that neither original
project implemented as a standalone, scorable signal.
"""
from __future__ import annotations

from job_analyzer.schemas import ExperienceMatchResult


class ExperienceMatcher:
    @staticmethod
    def match(candidate_years: int, required_years: int) -> ExperienceMatchResult:
        meets_requirement = candidate_years >= required_years

        if required_years <= 0:
            match_percentage = 100.0
        else:
            match_percentage = min(candidate_years / required_years, 1.0) * 100

        return ExperienceMatchResult(
            candidate_years=candidate_years,
            required_years=required_years,
            meets_requirement=meets_requirement,
            match_percentage=round(match_percentage, 2),
        )
