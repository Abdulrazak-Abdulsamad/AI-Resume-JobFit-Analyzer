"""
course_recommender

Self-contained module responsible for turning a list of missing skills
(produced by `job_analyzer.skill_gap.SkillGapAnalyzer`) into concrete course
recommendations and an ordered, beginner-to-advanced learning roadmap.

Public entry point: `CourseRecommendationService` (recommender_service.py).
Nothing outside this package needs to know how courses are looked up or how
the roadmap is ordered - that is an implementation detail encapsulated here,
in line with the same "one facade per stage" pattern already used by
`job_analyzer` and `rag`.
"""
from __future__ import annotations
