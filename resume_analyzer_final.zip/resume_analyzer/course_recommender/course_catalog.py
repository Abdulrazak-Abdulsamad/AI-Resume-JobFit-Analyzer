"""
course_catalog.py (course_recommender)

The single source of truth for "which courses teach which skill". Keyed by
the same skill strings used in `utils.skills_taxonomy.SKILL_TAXONOMY`, so a
missing skill produced anywhere in the app can be looked up here without a
second, divergent skill list.

Each catalog entry is already listed beginner -> advanced; `recommended_order`
is derived from list position rather than hand-typed on every row, so
re-ordering a skill's path only ever requires reordering the list (DRY).

For any skill without a curated entry, `get_courses_for_skill` falls back to
generated search links on the same trusted platforms, so every missing skill
always yields a usable recommendation instead of a blank result.
"""
from __future__ import annotations

from typing import Dict, List, TypedDict
from urllib.parse import quote_plus


class _RawCourse(TypedDict):
    course_title: str
    platform: str
    difficulty: str  # "Beginner" | "Intermediate" | "Advanced"
    estimated_duration: str
    url: str


# ---------------------------------------------------------------------------
# Curated catalog: skill -> ordered list of courses (beginner -> advanced).
# Skill keys match `SKILL_TAXONOMY` entries; lookups are case-insensitive.
# ---------------------------------------------------------------------------
COURSE_CATALOG: Dict[str, List[_RawCourse]] = {
    "Python": [
        {
            "course_title": "Python for Everybody Specialization",
            "platform": "Coursera",
            "difficulty": "Beginner",
            "estimated_duration": "8 weeks (approx.)",
            "url": "https://www.coursera.org/specializations/python",
        },
        {
            "course_title": "100 Days of Code: The Complete Python Pro Bootcamp",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "60 hours",
            "url": "https://www.udemy.com/course/100-days-of-code/",
        },
        {
            "course_title": "CS50's Introduction to Programming with Python",
            "platform": "edX",
            "difficulty": "Advanced",
            "estimated_duration": "9 weeks",
            "url": "https://www.edx.org/learn/python/harvard-university-cs50-s-introduction-to-programming-with-python",
        },
    ],
    "Java": [
        {
            "course_title": "Java Programming and Software Engineering Fundamentals",
            "platform": "Coursera",
            "difficulty": "Beginner",
            "estimated_duration": "5 months (approx.)",
            "url": "https://www.coursera.org/specializations/java-programming",
        },
        {
            "course_title": "Java Programming Masterclass",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "80 hours",
            "url": "https://www.udemy.com/course/java-the-complete-java-developer-course/",
        },
    ],
    "JavaScript": [
        {
            "course_title": "Learn JavaScript",
            "platform": "Codecademy",
            "difficulty": "Beginner",
            "estimated_duration": "25 hours",
            "url": "https://www.codecademy.com/learn/introduction-to-javascript",
        },
        {
            "course_title": "JavaScript Algorithms and Data Structures",
            "platform": "freeCodeCamp",
            "difficulty": "Beginner",
            "estimated_duration": "300 hours (self-paced)",
            "url": "https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/",
        },
        {
            "course_title": "The Complete JavaScript Course",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "69 hours",
            "url": "https://www.udemy.com/course/the-complete-javascript-course/",
        },
    ],
    "TypeScript": [
        {
            "course_title": "Learn TypeScript",
            "platform": "Codecademy",
            "difficulty": "Beginner",
            "estimated_duration": "10 hours",
            "url": "https://www.codecademy.com/learn/learn-typescript",
        },
        {
            "course_title": "Understanding TypeScript",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "17 hours",
            "url": "https://www.udemy.com/course/understanding-typescript/",
        },
    ],
    "SQL": [
        {
            "course_title": "Learn SQL",
            "platform": "Codecademy",
            "difficulty": "Beginner",
            "estimated_duration": "12 hours",
            "url": "https://www.codecademy.com/learn/learn-sql",
        },
        {
            "course_title": "Introduction to SQL",
            "platform": "DataCamp",
            "difficulty": "Beginner",
            "estimated_duration": "4 hours",
            "url": "https://www.datacamp.com/courses/introduction-to-sql",
        },
        {
            "course_title": "SQL for Data Science",
            "platform": "Coursera",
            "difficulty": "Intermediate",
            "estimated_duration": "4 weeks (approx.)",
            "url": "https://www.coursera.org/learn/sql-for-data-science",
        },
    ],
    "PostgreSQL": [
        {
            "course_title": "PostgreSQL for Everybody",
            "platform": "Coursera",
            "difficulty": "Beginner",
            "estimated_duration": "4 weeks (approx.)",
            "url": "https://www.coursera.org/specializations/postgresql-for-everybody",
        },
    ],
    "MongoDB": [
        {
            "course_title": "MongoDB Basics",
            "platform": "MongoDB University (via Coursera)",
            "difficulty": "Beginner",
            "estimated_duration": "6 hours",
            "url": "https://www.coursera.org/learn/mongodb-basics",
        },
    ],
    "Pandas": [
        {
            "course_title": "Data Manipulation with pandas",
            "platform": "DataCamp",
            "difficulty": "Beginner",
            "estimated_duration": "4 hours",
            "url": "https://www.datacamp.com/courses/data-manipulation-with-pandas",
        },
    ],
    "NumPy": [
        {
            "course_title": "Introduction to NumPy",
            "platform": "DataCamp",
            "difficulty": "Beginner",
            "estimated_duration": "4 hours",
            "url": "https://www.datacamp.com/courses/introduction-to-numpy",
        },
    ],
    "Scikit-Learn": [
        {
            "course_title": "Supervised Learning with scikit-learn",
            "platform": "DataCamp",
            "difficulty": "Intermediate",
            "estimated_duration": "4 hours",
            "url": "https://www.datacamp.com/courses/supervised-learning-with-scikit-learn",
        },
    ],
    "Machine Learning": [
        {
            "course_title": "Machine Learning Specialization",
            "platform": "Coursera",
            "difficulty": "Beginner",
            "estimated_duration": "3 months (approx.)",
            "url": "https://www.coursera.org/specializations/machine-learning-introduction",
        },
        {
            "course_title": "Machine Learning A-Z",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "44 hours",
            "url": "https://www.udemy.com/course/machinelearning/",
        },
    ],
    "TensorFlow": [
        {
            "course_title": "DeepLearning.AI TensorFlow Developer Professional Certificate",
            "platform": "Coursera",
            "difficulty": "Intermediate",
            "estimated_duration": "4 months (approx.)",
            "url": "https://www.coursera.org/professional-certificates/tensorflow-in-practice",
        },
    ],
    "PyTorch": [
        {
            "course_title": "Introduction to Deep Learning with PyTorch",
            "platform": "DataCamp",
            "difficulty": "Intermediate",
            "estimated_duration": "4 hours",
            "url": "https://www.datacamp.com/courses/introduction-to-deep-learning-with-pytorch",
        },
    ],
    "Natural Language Processing": [
        {
            "course_title": "Natural Language Processing Specialization",
            "platform": "Coursera",
            "difficulty": "Intermediate",
            "estimated_duration": "4 months (approx.)",
            "url": "https://www.coursera.org/specializations/natural-language-processing",
        },
    ],
    "Computer Vision": [
        {
            "course_title": "Deep Learning Specialization (Convolutional Neural Networks)",
            "platform": "Coursera",
            "difficulty": "Intermediate",
            "estimated_duration": "4 weeks (approx.)",
            "url": "https://www.coursera.org/learn/convolutional-neural-networks",
        },
    ],
    "Docker": [
        {
            "course_title": "Docker Tutorial for Beginners",
            "platform": "YouTube (freeCodeCamp)",
            "difficulty": "Beginner",
            "estimated_duration": "3 hours",
            "url": "https://www.youtube.com/watch?v=fqMOX6JJhGo",
        },
        {
            "course_title": "Docker & Kubernetes: The Practical Guide",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "22 hours",
            "url": "https://www.udemy.com/course/docker-kubernetes-the-practical-guide/",
        },
    ],
    "Kubernetes": [
        {
            "course_title": "Kubernetes for the Absolute Beginners",
            "platform": "Udemy",
            "difficulty": "Beginner",
            "estimated_duration": "6 hours",
            "url": "https://www.udemy.com/course/learn-kubernetes/",
        },
    ],
    "CI/CD": [
        {
            "course_title": "GitHub Actions - The Complete Guide",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "13 hours",
            "url": "https://www.udemy.com/course/github-actions-the-complete-guide/",
        },
    ],
    "GitHub Actions": [
        {
            "course_title": "GitHub Actions - The Complete Guide",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "13 hours",
            "url": "https://www.udemy.com/course/github-actions-the-complete-guide/",
        },
    ],
    "Jenkins": [
        {
            "course_title": "Jenkins: The Complete Guide to Continuous Integration",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "9 hours",
            "url": "https://www.udemy.com/course/jenkins-from-zero-to-hero/",
        },
    ],
    "Linux": [
        {
            "course_title": "Introduction to Linux",
            "platform": "edX",
            "difficulty": "Beginner",
            "estimated_duration": "40-60 hours",
            "url": "https://www.edx.org/learn/linux/the-linux-foundation-introduction-to-linux",
        },
    ],
    "Git": [
        {
            "course_title": "Learn Git",
            "platform": "Codecademy",
            "difficulty": "Beginner",
            "estimated_duration": "6 hours",
            "url": "https://www.codecademy.com/learn/learn-git",
        },
        {
            "course_title": "Git and GitHub for Beginners",
            "platform": "YouTube (freeCodeCamp)",
            "difficulty": "Beginner",
            "estimated_duration": "1 hour",
            "url": "https://www.youtube.com/watch?v=RGOj5yH7evk",
        },
    ],
    "AWS": [
        {
            "course_title": "AWS Cloud Practitioner Essentials",
            "platform": "AWS Skill Builder",
            "difficulty": "Beginner",
            "estimated_duration": "6 hours",
            "url": "https://explore.skillbuilder.aws/learn/courses/134/aws-cloud-practitioner-essentials",
        },
        {
            "course_title": "AWS Certified Solutions Architect - Associate",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "27 hours",
            "url": "https://www.udemy.com/course/aws-certified-solutions-architect-associate-saa-c03/",
        },
    ],
    "Azure": [
        {
            "course_title": "AZ-900: Microsoft Azure Fundamentals",
            "platform": "Microsoft Learn",
            "difficulty": "Beginner",
            "estimated_duration": "10-12 hours",
            "url": "https://learn.microsoft.com/en-us/training/paths/az-900-describe-cloud-concepts/",
        },
    ],
    "GCP": [
        {
            "course_title": "Google Cloud Fundamentals: Core Infrastructure",
            "platform": "Google Cloud Skills Boost",
            "difficulty": "Beginner",
            "estimated_duration": "8 hours",
            "url": "https://www.cloudskillsboost.google/course_templates/60",
        },
    ],
    "Terraform": [
        {
            "course_title": "HashiCorp Certified: Terraform Associate Course",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "13 hours",
            "url": "https://www.udemy.com/course/terraform-beginner-to-advanced/",
        },
    ],
    "React": [
        {
            "course_title": "Learn React",
            "platform": "Codecademy",
            "difficulty": "Beginner",
            "estimated_duration": "20 hours",
            "url": "https://www.codecademy.com/learn/react-101",
        },
        {
            "course_title": "Front End Development Libraries",
            "platform": "freeCodeCamp",
            "difficulty": "Beginner",
            "estimated_duration": "300 hours (self-paced)",
            "url": "https://www.freecodecamp.org/learn/front-end-development-libraries/",
        },
        {
            "course_title": "React - The Complete Guide",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "68 hours",
            "url": "https://www.udemy.com/course/react-the-complete-guide-incl-redux/",
        },
    ],
    "Vue.js": [
        {
            "course_title": "Vue - The Complete Guide",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "32 hours",
            "url": "https://www.udemy.com/course/vuejs-2-the-complete-guide/",
        },
    ],
    "Node.js": [
        {
            "course_title": "Learn Node.js",
            "platform": "Codecademy",
            "difficulty": "Beginner",
            "estimated_duration": "10 hours",
            "url": "https://www.codecademy.com/learn/learn-node-js",
        },
        {
            "course_title": "The Complete Node.js Developer Course",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "35 hours",
            "url": "https://www.udemy.com/course/the-complete-nodejs-developer-course-2/",
        },
    ],
    "HTML5": [
        {
            "course_title": "Responsive Web Design",
            "platform": "freeCodeCamp",
            "difficulty": "Beginner",
            "estimated_duration": "300 hours (self-paced)",
            "url": "https://www.freecodecamp.org/learn/2022/responsive-web-design/",
        },
    ],
    "CSS3": [
        {
            "course_title": "Responsive Web Design",
            "platform": "freeCodeCamp",
            "difficulty": "Beginner",
            "estimated_duration": "300 hours (self-paced)",
            "url": "https://www.freecodecamp.org/learn/2022/responsive-web-design/",
        },
    ],
    "FastAPI": [
        {
            "course_title": "FastAPI - The Complete Course",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "16 hours",
            "url": "https://www.udemy.com/course/fastapi-the-complete-course/",
        },
    ],
    "System Design": [
        {
            "course_title": "Grokking the System Design Interview",
            "platform": "Udemy",
            "difficulty": "Advanced",
            "estimated_duration": "20 hours",
            "url": "https://www.udemy.com/course/system-design-interview-prep/",
        },
    ],
    "Tableau": [
        {
            "course_title": "Data Visualization with Tableau",
            "platform": "Coursera",
            "difficulty": "Beginner",
            "estimated_duration": "5 months (approx.)",
            "url": "https://www.coursera.org/specializations/data-visualization",
        },
    ],
    "PowerBI": [
        {
            "course_title": "Power BI Data Analyst",
            "platform": "Microsoft Learn",
            "difficulty": "Beginner",
            "estimated_duration": "20-25 hours",
            "url": "https://learn.microsoft.com/en-us/training/paths/data-analytics-microsoft/",
        },
    ],
    "Data Analysis": [
        {
            "course_title": "Google Data Analytics Professional Certificate",
            "platform": "Coursera",
            "difficulty": "Beginner",
            "estimated_duration": "6 months (approx.)",
            "url": "https://www.coursera.org/professional-certificates/google-data-analytics",
        },
    ],
    "Agile": [
        {
            "course_title": "Agile Crash Course: Agile Project Management",
            "platform": "Udemy",
            "difficulty": "Beginner",
            "estimated_duration": "3 hours",
            "url": "https://www.udemy.com/course/agile-crash-course/",
        },
    ],
    "Scrum": [
        {
            "course_title": "Scrum Master Certification Prep",
            "platform": "LinkedIn Learning",
            "difficulty": "Beginner",
            "estimated_duration": "2 hours",
            "url": "https://www.linkedin.com/learning/topics/scrum",
        },
    ],
    "Network Security": [
        {
            "course_title": "Introduction to Cybersecurity",
            "platform": "Coursera",
            "difficulty": "Beginner",
            "estimated_duration": "4 weeks (approx.)",
            "url": "https://www.coursera.org/professional-certificates/google-cybersecurity",
        },
    ],
    "Penetration Testing": [
        {
            "course_title": "The Complete Ethical Hacking Course",
            "platform": "Udemy",
            "difficulty": "Intermediate",
            "estimated_duration": "24 hours",
            "url": "https://www.udemy.com/course/penetration-testing/",
        },
    ],
    "Figma": [
        {
            "course_title": "Learn Figma",
            "platform": "LinkedIn Learning",
            "difficulty": "Beginner",
            "estimated_duration": "2 hours",
            "url": "https://www.linkedin.com/learning/topics/figma",
        },
    ],
}


def _search_fallback_courses(skill: str) -> List[_RawCourse]:
    """
    Generic, always-available fallback for any skill not yet curated above.
    Uses live search URLs on trusted platforms rather than inventing a
    specific course title/URL that may not exist, keeping the recommendation
    honest while still giving the user somewhere useful to click.
    """
    encoded = quote_plus(skill)
    return [
        {
            "course_title": f"{skill} - curated video tutorials",
            "platform": "YouTube",
            "difficulty": "Beginner",
            "estimated_duration": "Varies",
            "url": f"https://www.youtube.com/results?search_query={encoded}+tutorial",
        },
        {
            "course_title": f"{skill} courses",
            "platform": "Coursera",
            "difficulty": "Intermediate",
            "estimated_duration": "Varies",
            "url": f"https://www.coursera.org/search?query={encoded}",
        },
        {
            "course_title": f"{skill} courses",
            "platform": "Udemy",
            "difficulty": "Advanced",
            "estimated_duration": "Varies",
            "url": f"https://www.udemy.com/courses/search/?q={encoded}",
        },
    ]


def get_courses_for_skill(skill: str) -> List[_RawCourse]:
    """
    Case-insensitive lookup into the curated catalog, falling back to
    generated search links so every skill returns something.
    """
    for key, courses in COURSE_CATALOG.items():
        if key.lower() == skill.strip().lower():
            return courses
    return _search_fallback_courses(skill)
