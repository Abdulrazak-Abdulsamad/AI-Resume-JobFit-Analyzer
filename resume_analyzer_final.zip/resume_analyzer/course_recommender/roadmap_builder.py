"""
roadmap_builder.py (course_recommender)

Turns a flat collection of per-skill course recommendations into a single
ordered `LearningRoadmap`: every course grouped into a Beginner phase, an
Intermediate phase, and an Advanced phase (skipping any phase that has no
courses), so the candidate gets one linear path to follow across all of
their missing skills instead of one list per skill.
"""
from __future__ import annotations

from typing import List

from course_recommender.schemas import (
    CourseRecommendation,
    DifficultyLevel,
    LearningRoadmap,
    RoadmapPhase,
    SkillCourseRecommendations,
)

_PHASE_ORDER: List[DifficultyLevel] = [
    DifficultyLevel.BEGINNER,
    DifficultyLevel.INTERMEDIATE,
    DifficultyLevel.ADVANCED,
]


class RoadmapBuilder:
    @staticmethod
    def build(skill_recommendations: List[SkillCourseRecommendations]) -> LearningRoadmap:
        all_courses: List[CourseRecommendation] = [
            course for group in skill_recommendations for course in group.courses
        ]

        phases: List[RoadmapPhase] = []
        for phase_number, difficulty in enumerate(_PHASE_ORDER, start=1):
            courses_in_phase = [c for c in all_courses if c.difficulty == difficulty]
            if not courses_in_phase:
                continue
            # Within a phase, keep skills grouped together and preserve each
            # skill's own beginner->advanced ordering.
            courses_in_phase.sort(key=lambda c: (c.skill.lower(), c.recommended_order))
            phases.append(RoadmapPhase(
                phase_number=phase_number,
                difficulty=difficulty,
                courses=courses_in_phase,
            ))

        return LearningRoadmap(
            phases=phases,
            skills_covered=[group.skill for group in skill_recommendations],
            total_courses=len(all_courses),
        )
