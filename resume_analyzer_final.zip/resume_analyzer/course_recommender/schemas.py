"""
schemas.py (course_recommender)

Output data contracts for the Course Recommendation stage. Mirrors the style
of `job_analyzer/schemas.py`: plain pydantic models, no business logic.
"""
from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import BaseModel

# Canonical beginner -> advanced ordering used both to sort a single skill's
# own course list and to group courses into roadmap phases. Defined once
# here so no other module has to re-invent "what order do difficulties go
# in" (DRY).
_DIFFICULTY_RANK = {"Beginner": 0, "Intermediate": 1, "Advanced": 2}


class DifficultyLevel(str, Enum):
    BEGINNER = "Beginner"
    INTERMEDIATE = "Intermediate"
    ADVANCED = "Advanced"

    @property
    def rank(self) -> int:
        return _DIFFICULTY_RANK[self.value]


class CourseRecommendation(BaseModel):
    """A single recommended learning resource for one missing skill."""

    skill: str
    course_title: str
    platform: str
    difficulty: DifficultyLevel
    estimated_duration: str
    url: str
    # 1-based position within THIS skill's own learning path (beginner first).
    recommended_order: int


class SkillCourseRecommendations(BaseModel):
    """All recommended courses for a single missing skill, already ordered."""

    skill: str
    courses: List[CourseRecommendation]


class RoadmapPhase(BaseModel):
    """One stage of the overall roadmap (e.g. all beginner-level courses)."""

    phase_number: int
    difficulty: DifficultyLevel
    courses: List[CourseRecommendation]


class LearningRoadmap(BaseModel):
    """
    The full personalized roadmap: every recommended course for every
    missing skill, grouped into beginner -> intermediate -> advanced phases
    and given a global step number so the candidate has a single ordered
    list to follow.
    """

    phases: List[RoadmapPhase]
    skills_covered: List[str]
    total_courses: int


class CourseRecommendationBundle(BaseModel):
    """
    Everything the Course Recommendation stage produces for one job match:
    the per-skill recommendation lists plus the derived roadmap. Keeping
    both together avoids computing the roadmap twice (once for display,
    once for export) - DRY.
    """

    skill_recommendations: List[SkillCourseRecommendations]
    roadmap: LearningRoadmap
