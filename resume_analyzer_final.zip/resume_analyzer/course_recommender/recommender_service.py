"""
recommender_service.py (course_recommender)

The single entry point the rest of the app should use for course
recommendations - mirrors the facade pattern already used by
`job_analyzer.engine.JobAnalyzer` and `services.resume_analysis_service`.

Workflow position:

    Skill Gap Detection -> **Course Recommendations** -> Learning Roadmap

Given the missing skills produced by `SkillGapAnalyzer`, this service:
  1. Looks up ordered courses per skill via `course_catalog`.
  2. Wraps each raw course dict into a `CourseRecommendation`.
  3. Delegates roadmap assembly to `RoadmapBuilder`.
"""
from __future__ import annotations

from typing import List

from course_recommender.course_catalog import get_courses_for_skill
from course_recommender.roadmap_builder import RoadmapBuilder
from course_recommender.schemas import (
    CourseRecommendation,
    CourseRecommendationBundle,
    SkillCourseRecommendations,
)
from utils.logging_config import get_logger

logger = get_logger(__name__)


class CourseRecommendationService:
    """Facade turning missing skills into recommendations + a roadmap."""

    def __init__(self, roadmap_builder: RoadmapBuilder | None = None) -> None:
        self.roadmap_builder = roadmap_builder or RoadmapBuilder()

    def recommend_for_skill(self, skill: str) -> SkillCourseRecommendations:
        """Ordered (beginner -> advanced) course list for a single skill."""
        raw_courses = get_courses_for_skill(skill)
        courses = [
            CourseRecommendation(
                skill=skill,
                course_title=raw["course_title"],
                platform=raw["platform"],
                difficulty=raw["difficulty"],
                estimated_duration=raw["estimated_duration"],
                url=raw["url"],
                recommended_order=order,
            )
            for order, raw in enumerate(raw_courses, start=1)
        ]
        return SkillCourseRecommendations(skill=skill, courses=courses)

    def recommend_for_missing_skills(self, missing_skills: List[str]) -> CourseRecommendationBundle:
        """
        Build the full recommendation bundle (per-skill courses + roadmap)
        for every missing skill detected during Skill Gap Detection.
        """
        if not missing_skills:
            logger.info("No missing skills detected; skipping course recommendations.")
            return CourseRecommendationBundle(
                skill_recommendations=[],
                roadmap=self.roadmap_builder.build([]),
            )

        skill_recommendations = [self.recommend_for_skill(skill) for skill in missing_skills]
        roadmap = self.roadmap_builder.build(skill_recommendations)
        return CourseRecommendationBundle(
            skill_recommendations=skill_recommendations,
            roadmap=roadmap,
        )


def get_course_recommendation_service() -> CourseRecommendationService:
    """Factory kept for symmetry with the rest of the app's service getters."""
    return CourseRecommendationService()
