"""
test_pipeline_smoke.py

A dependency-injected smoke test that exercises the full
RAG <-> Job Analyzer wiring WITHOUT requiring network access to download
the real sentence-transformers model (this sandbox has no route to
huggingface.co). A deterministic hash-based fake embedder stands in for
`EmbeddingService` so imports, data flow, and scoring logic can all be
verified end-to-end.

This test intentionally does NOT cover the real embedding model or spaCy
NER output quality - that requires running `pip install -r requirements.txt`
with full internet access, as noted in README.md.

Run with:  python tests/test_pipeline_smoke.py
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path
from typing import List, Sequence

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from course_recommender.recommender_service import CourseRecommendationService  # noqa: E402
from database.job_repository import JobRepository  # noqa: E402
from job_analyzer.engine import JobAnalyzer  # noqa: E402
from job_analyzer.experience_matcher import ExperienceMatcher  # noqa: E402
from job_analyzer.scoring import ResumeScorer  # noqa: E402
from job_analyzer.similarity import SimilarityCalculator  # noqa: E402
from job_analyzer.skill_gap import SkillGapAnalyzer  # noqa: E402
from job_analyzer.insights import InsightGenerator  # noqa: E402
from rag.retriever import JobRetriever  # noqa: E402
from rag.vector_store import VectorStoreManager  # noqa: E402
from resume_parsing.schema import ExperienceEntry, ParsedResume  # noqa: E402


class FakeEmbeddingService:
    """
    Deterministic, dependency-free stand-in for the real EmbeddingService.
    Encodes text as a small vector derived from a hash of its words, so
    identical/similar texts land close together - enough to exercise vector
    store add/query logic without downloading any model weights.
    """

    _DIM = 32

    def encode(self, text: str) -> List[float]:
        return self._vector_for(text)

    def encode_many(self, texts: Sequence[str]) -> List[List[float]]:
        return [self._vector_for(t) for t in texts]

    def _vector_for(self, text: str) -> List[float]:
        vector = [0.0] * self._DIM
        for word in (text or "").lower().split():
            digest = hashlib.md5(word.encode()).hexdigest()
            bucket = int(digest, 16) % self._DIM
            vector[bucket] += 1.0
        norm = sum(v * v for v in vector) ** 0.5 or 1.0
        return [v / norm for v in vector]


def run_smoke_test() -> None:
    import tempfile

    fake_embedder = FakeEmbeddingService()

    # Point the job repository at the real bundled job_db.json.
    job_repository = JobRepository()
    assert len(job_repository.all_jobs()) == 10, "Expected 10 seeded jobs in job_db.json"

    # Use an isolated, throwaway vector store directory for this test run.
    with tempfile.TemporaryDirectory() as tmp_vectordb:
        import config
        config.settings.vector_store.__dict__  # noqa: B018 (dataclass is frozen; just documenting intent)

        from dataclasses import replace
        vs_config = replace(config.settings.vector_store, persist_directory=tmp_vectordb)
        object.__setattr__(config.settings, "vector_store", vs_config)

        vector_store = VectorStoreManager(job_repository=job_repository, embedding_service=fake_embedder)
        assert vector_store.count() == 10, "Vector store should be seeded with all 10 jobs"

        retriever = JobRetriever(vector_store, job_repository=job_repository, embedding_service=fake_embedder)

        analyzer = JobAnalyzer(
            retriever=retriever,
            similarity_calculator=SimilarityCalculator(embedding_service=fake_embedder),
            skill_gap_analyzer=SkillGapAnalyzer(),
            experience_matcher=ExperienceMatcher(),
            scorer=ResumeScorer(),
            insight_generator=InsightGenerator(),
            course_recommendation_service=CourseRecommendationService(),
        )

        sample_resume = ParsedResume(
            name="Jane Doe",
            email="jane@example.com",
            phone="+1-555-0100",
            total_experience_years=3,
            education=[],
            experience=[ExperienceEntry(company="Acme Corp", role="Backend Developer", dates="2021-2024")],
            skills=["Python", "SQL", "RESTful APIs", "System Design"],
        )

        results = analyzer.analyze(sample_resume, top_k=3)

        assert len(results) == 3, "Expected 3 ranked job matches"
        assert results[0].score.final_fit_score >= results[-1].score.final_fit_score, "Results must be ranked descending"

        for result in results:
            assert 0 <= result.score.final_fit_score <= 100
            assert result.skills.job_required_skills, "Every match must carry job_db-sourced required skills"

            bundle = result.course_recommendations
            if result.skills.missing_skills:
                assert bundle.skill_recommendations, "Missing skills must yield course recommendations"
                assert bundle.roadmap.total_courses > 0
                assert bundle.roadmap.phases, "Roadmap must have at least one phase"
                # Every phase's courses must actually match that phase's difficulty.
                for phase in bundle.roadmap.phases:
                    assert all(c.difficulty == phase.difficulty for c in phase.courses)
            else:
                assert bundle.skill_recommendations == []

        print("SMOKE TEST PASSED")
        print(f"Top match: {results[0].job_title} -> {results[0].score.final_fit_score}% ({results[0].score.rating})")
        for r in results:
            print(f"  - {r.job_title}: fit={r.score.final_fit_score}% skills_match={r.skills.skill_match_percentage}%")


if __name__ == "__main__":
    run_smoke_test()
