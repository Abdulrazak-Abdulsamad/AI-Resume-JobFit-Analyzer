"""
file_utils.py

Small filesystem helpers shared by the UI and pipeline layers (e.g. saving
an uploaded file to a temporary path before handing it to the Resume Parser).
"""
from __future__ import annotations

import tempfile
from pathlib import Path


def save_uploaded_file(file_bytes: bytes, original_filename: str) -> Path:
    """
    Persist uploaded bytes to a temporary file with the original extension so
    downstream extractors (which dispatch on file suffix) work unchanged.
    """
    suffix = Path(original_filename).suffix or ".tmp"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp_file:
        tmp_file.write(file_bytes)
        return Path(tmp_file.name)
