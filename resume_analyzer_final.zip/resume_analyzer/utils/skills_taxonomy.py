"""
skills_taxonomy.py

The canonical list of technical/professional skills recognized by the whole
system. This is the SINGLE source of truth for "what counts as a skill" -
both the Resume Parser (extracting skills from free text) and the Job
Analyzer (matching resume skills against job requirements) import this list,
which eliminates the two divergent, hand-maintained skill lists that existed
in the original projects.

The list is a superset of every `required_skills` entry found in the job
database plus the general-purpose skills the original Resume Parser looked
for, so nothing already supported is lost.
"""
from __future__ import annotations

SKILL_TAXONOMY: list[str] = sorted(set([
    # Languages
    "Python", "Java", "JavaScript", "TypeScript", "C++", "R", "Bash",
    # Web / Frontend
    "React", "Vue.js", "HTML5", "CSS3", "Tailwind", "REST APIs", "RESTful APIs",
    # Backend / Data
    "Node.js", "SQL", "PostgreSQL", "MongoDB", "Snowflake",
    "Pandas", "NumPy", "Scikit-Learn", "Apache Spark", "Airflow", "Hadoop",
    # AI / ML
    "PyTorch", "TensorFlow", "Natural Language Processing", "Computer Vision",
    "MLOps", "Machine Learning", "spaCy",
    # DevOps / Cloud
    "Docker", "Kubernetes", "CI/CD", "GitHub Actions", "Jenkins", "Linux",
    "AWS", "Azure", "GCP", "Terraform", "Git", "FastAPI",
    # Security
    "Network Security", "Penetration Testing", "Risk Assessment", "SIEM Tools",
    # Design
    "Figma", "Adobe XD", "Wireframing", "Prototyping", "User Research",
    # BI / Analytics
    "Tableau", "PowerBI", "Data Analysis",
    # Product / Process
    "Product Strategy", "Agile", "Scrum", "Stakeholder Management",
    "System Design",
]))
