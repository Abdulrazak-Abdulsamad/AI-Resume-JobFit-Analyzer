"""
logging_config.py

Single place to configure logging for the whole application. Import
`get_logger` anywhere a module needs a logger instead of calling
`logging.basicConfig` repeatedly across files.
"""
from __future__ import annotations

import logging
import sys

_CONFIGURED = False


def configure_logging(level: int = logging.INFO) -> None:
    """Idempotently configure the root logger exactly once."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        stream=sys.stdout,
    )
    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a module-level logger, ensuring logging is configured first."""
    configure_logging()
    return logging.getLogger(name)
