"""
schemas.py (rag)

Data contracts for the RAG module's output.
"""
from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel


class RetrievedJob(BaseModel):
    """A single job retrieved from the vector store, enriched with the
    original structured fields from the job database (single source of
    truth), not just free text."""
    job_id: str
    title: str
    required_skills: List[str] = []
    minimum_work_experience_years: int = 0
    context_text: str
    similarity_score: float
