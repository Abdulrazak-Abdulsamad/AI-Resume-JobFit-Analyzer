"""
context_builder.py

Final "context generation" step of the RAG pipeline: assembles the list of
`RetrievedJob` objects into a single formatted context block. Consumers
(the Job Analyzer's insight generator, or an optional LLM explainer) receive
ready-to-use text instead of re-implementing their own formatting.
"""
from __future__ import annotations

from typing import List

from rag.schemas import RetrievedJob


def build_context_block(retrieved_jobs: List[RetrievedJob]) -> str:
    """Format retrieved jobs into a single human/LLM-readable context block."""
    if not retrieved_jobs:
        return "No relevant jobs were retrieved."

    sections = []
    for index, job in enumerate(retrieved_jobs, start=1):
        sections.append(
            f"--- Retrieved Job {index} ---\n"
            f"Title: {job.title}\n"
            f"Required Skills: {', '.join(job.required_skills)}\n"
            f"Minimum Experience: {job.minimum_work_experience_years} year(s)\n"
            f"Retrieval Similarity: {job.similarity_score}"
        )
    return "\n\n".join(sections)
