"""
vector_store.py

Owns the RAG module's ChromaDB collection: builds a rich text "document"
per job (document loading + context generation), embeds it via the shared
EmbeddingService, and stores it for later retrieval.

Job data is obtained exclusively through `database.job_repository`
(the single source of truth) rather than reading job_db.json directly, so
there is exactly one code path that touches the file on disk.
"""
from __future__ import annotations

from typing import Any, Dict, List

import chromadb

from config import settings
from database.job_repository import JobRepository, get_job_repository
from services.embedding_service import EmbeddingService, get_embedding_service
from utils.logging_config import get_logger

logger = get_logger(__name__)


def build_job_document(job: Dict[str, Any]) -> str:
    """
    Build the rich text chunk used both for embedding and as the retrieved
    context passed to the Job Analyzer. This is the module's "context
    generation" responsibility.
    """
    title = job.get("title", "Unknown Position")
    skills = job.get("required_skills", [])
    skills_str = ", ".join(skills) if isinstance(skills, list) else str(skills)
    min_experience = job.get("minimum_work_experience_years", 0)

    if job.get("description"):
        return f"Job Title: {title}\nDescription: {job['description']}"

    return (
        f"Job Title: {title}\n"
        f"Required Skills: {skills_str}.\n"
        f"Minimum Experience: {min_experience} year(s)."
    )


class VectorStoreManager:
    """Manages the persistent ChromaDB collection of job embeddings."""

    def __init__(
        self,
        job_repository: JobRepository | None = None,
        embedding_service: EmbeddingService | None = None,
    ) -> None:
        self.job_repository = job_repository or get_job_repository()
        self.embedding_service = embedding_service or get_embedding_service()

        self.client = chromadb.PersistentClient(path=settings.vector_store.persist_directory)
        self.collection = self.client.get_or_create_collection(
            name=settings.vector_store.collection_name
        )
        self._seed_if_empty()

    def _seed_if_empty(self) -> None:
        if self.collection.count() > 0:
            logger.info("Vector store already populated (%d jobs). Skipping seed.", self.collection.count())
            return

        jobs = self.job_repository.all_jobs()
        if not jobs:
            logger.warning("Job repository returned no jobs; vector store left empty.")
            return

        logger.info("Seeding vector store from %d job records...", len(jobs))
        documents: List[str] = []
        metadatas: List[Dict[str, Any]] = []
        ids: List[str] = []

        for job in jobs:
            documents.append(build_job_document(job))
            ids.append(job["job_id"])
            metadatas.append({
                "job_id": job["job_id"],
                "title": job["title"],
                "required_skills": ", ".join(job.get("required_skills", [])),
                "minimum_work_experience_years": job.get("minimum_work_experience_years", 0),
            })

        embeddings = self.embedding_service.encode_many(documents)
        self.collection.add(ids=ids, embeddings=embeddings, metadatas=metadatas, documents=documents)
        logger.info("Vector store seeded. Total indexed jobs: %d", self.collection.count())

    def count(self) -> int:
        return self.collection.count()
