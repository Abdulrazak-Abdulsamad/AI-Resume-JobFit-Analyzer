"""
config.py

Centralized, single-source configuration for the AI Resume Analyzer.

Every module reads paths, model names, and tunable parameters from this file
instead of hard-coding them, so the project has exactly one place to change
settings such as the job database location, the embedding model, or scoring
weights.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
# Base paths
# ---------------------------------------------------------------------------
BASE_DIR: Path = Path(__file__).resolve().parent
DATA_DIR: Path = BASE_DIR / "data"
VECTOR_DB_DIR: Path = BASE_DIR / "data" / "vectordb"

# The single source of truth for job data. Can be overridden with the
# RESUME_ANALYZER_JOB_DB environment variable (useful for tests/deployment).
JOB_DB_PATH: Path = Path(os.getenv("RESUME_ANALYZER_JOB_DB", str(DATA_DIR / "job_db.json")))


@dataclass(frozen=True)
class EmbeddingConfig:
    """Settings for the single shared embedding model used across modules."""
    model_name: str = os.getenv("RESUME_ANALYZER_EMBED_MODEL", "all-MiniLM-L6-v2")


@dataclass(frozen=True)
class VectorStoreConfig:
    """Settings for the RAG vector store (ChromaDB)."""
    persist_directory: str = str(VECTOR_DB_DIR)
    collection_name: str = "jobs"


@dataclass(frozen=True)
class RetrievalConfig:
    """Settings controlling how many jobs the RAG pipeline retrieves."""
    top_k: int = 4


@dataclass(frozen=True)
class ScoringWeights:
    """
    Weights used by the Job Analyzer to combine individual signals into the
    final ATS fit score. Must sum to 1.0.
    """
    semantic_similarity: float = 0.40
    skill_match: float = 0.40
    experience_match: float = 0.20

    def validate(self) -> None:
        total = self.semantic_similarity + self.skill_match + self.experience_match
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"ScoringWeights must sum to 1.0, got {total}")


@dataclass(frozen=True)
class RatingBands:
    """Score thresholds used to translate a numeric score into a rating label."""
    excellent: float = 90.0
    very_good: float = 80.0
    good: float = 70.0
    average: float = 60.0


@dataclass(frozen=True)
class SkillExtractionConfig:
    """Settings for embedding-based fuzzy skill extraction."""
    similarity_threshold: float = 0.68


@dataclass(frozen=True)
class APIConfig:
    """
    Settings for the FastAPI presentation layer (`api.py`). Kept here, like
    every other setting, so the allowed frontend origin(s) and bind
    host/port have exactly one place to change instead of being hard-coded
    inside the API module.
    """
    host: str = os.getenv("RESUME_ANALYZER_API_HOST", "0.0.0.0")
    port: int = int(os.getenv("RESUME_ANALYZER_API_PORT", "8000"))
    # Comma-separated list of allowed frontend origins for CORS. Defaults
    # cover the Vite dev server's default and fallback ports.
    cors_origins: tuple[str, ...] = tuple(
        origin.strip()
        for origin in os.getenv(
            "RESUME_ANALYZER_CORS_ORIGINS",
            "http://localhost:5173,http://127.0.0.1:5173",
        ).split(",")
        if origin.strip()
    )


@dataclass(frozen=True)
class Settings:
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    vector_store: VectorStoreConfig = field(default_factory=VectorStoreConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    scoring_weights: ScoringWeights = field(default_factory=ScoringWeights)
    rating_bands: RatingBands = field(default_factory=RatingBands)
    skill_extraction: SkillExtractionConfig = field(default_factory=SkillExtractionConfig)
    api: APIConfig = field(default_factory=APIConfig)
    job_db_path: Path = JOB_DB_PATH


# Single, importable settings instance (import this everywhere instead of
# constructing new dataclasses, so the whole app shares one configuration).
settings = Settings()
settings.scoring_weights.validate()
