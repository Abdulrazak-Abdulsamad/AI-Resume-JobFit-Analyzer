#!/usr/bin/env bash
# Installs (if needed) and starts the React/Vite frontend dev server.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/frontend"

if [ ! -d node_modules ]; then
  echo "Installing frontend dependencies..."
  npm install
fi

npm run dev
