import { DifficultyBadge } from './CourseRecommendations';

/**
 * LearningRoadmap.jsx
 *
 * Renders the personalized, beginner -> advanced roadmap produced by
 * `course_recommender.roadmap_builder` for one job match's missing skills.
 */
function LearningRoadmap({ roadmap }) {
  if (!roadmap || !roadmap.phases || roadmap.phases.length === 0) return null;

  return (
    <div className="border-t pt-4 mt-4">
      <h4 className="font-bold text-gray-800 mb-4">
        Personalized Learning Roadmap
        <span className="ml-2 text-xs font-normal text-gray-500">
          {roadmap.total_courses} course(s) across {roadmap.skills_covered.length} skill(s)
        </span>
      </h4>
      <div className="space-y-4">
        {roadmap.phases.map((phase) => (
          <div key={phase.phase_number} className="flex gap-4">
            <div className="shrink-0 w-28 text-right">
              <span className="text-xs font-bold text-gray-400 uppercase block">
                Phase {phase.phase_number}
              </span>
              <DifficultyBadge difficulty={phase.difficulty} />
            </div>
            <ul className="flex-1 space-y-1 border-l-2 border-blue-100 pl-4">
              {phase.courses.map((course) => (
                <li key={`${course.skill}-${course.recommended_order}`} className="text-sm text-gray-700">
                  <a
                    href={course.url}
                    target="_blank"
                    rel="noreferrer"
                    className="font-medium text-blue-700 hover:underline"
                  >
                    {course.course_title}
                  </a>{' '}
                  <span className="text-gray-500">
                    ({course.skill} · {course.platform} · {course.estimated_duration})
                  </span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

export default LearningRoadmap;
