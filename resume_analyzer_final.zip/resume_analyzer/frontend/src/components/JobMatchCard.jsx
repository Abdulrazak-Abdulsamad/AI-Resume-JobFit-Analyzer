import SkillChips from './SkillChips';
import CourseRecommendations from './CourseRecommendations';
import LearningRoadmap from './LearningRoadmap';

function MetricTile({ label, value }) {
  return (
    <div className="p-4 bg-gray-50 rounded-lg text-center border">
      <div className="text-gray-500 text-xs font-bold uppercase mb-1">{label}</div>
      <div className="font-bold text-gray-900 text-lg">{value}%</div>
    </div>
  );
}

/**
 * JobMatchCard.jsx
 *
 * One ranked job match end-to-end: similarity/skill/experience metrics,
 * strengths & weaknesses, matching/missing skills, course recommendations,
 * and the learning roadmap - everything `JobAnalysisResult` carries for
 * this job.
 */
function JobMatchCard({ match }) {
  const bundle = match.course_recommendations;

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 mb-6">
      {/* Job Header */}
      <div className="flex justify-between items-center mb-6 border-b pb-4">
        <h3 className="text-xl font-bold text-gray-800">{match.job_title}</h3>
        <div className="text-right">
          <span className="block text-2xl font-bold text-blue-600">{match.score.final_fit_score}%</span>
          <span className="text-sm text-gray-500 font-bold uppercase tracking-wider">{match.score.rating}</span>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <MetricTile label="Similarity" value={match.similarity.combined_score} />
        <MetricTile label="Skill Match" value={match.skills.skill_match_percentage} />
        <MetricTile label="Experience Match" value={match.experience.match_percentage} />
      </div>

      {/* Matching / Missing skills */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h4 className="font-bold text-green-700 mb-2">Matching Skills</h4>
          <SkillChips skills={match.skills.matching_skills} variant="green" />
        </div>
        <div>
          <h4 className="font-bold text-red-700 mb-2">Missing Skills</h4>
          <SkillChips skills={match.skills.missing_skills} variant="red" />
        </div>
      </div>

      {/* Strengths & Weaknesses */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
        <div>
          <h4 className="font-bold text-green-700 mb-2">Strengths</h4>
          <ul className="list-disc pl-5 text-gray-600 text-sm space-y-1">
            {match.strengths.map((s) => <li key={s}>{s}</li>)}
          </ul>
        </div>
        <div>
          <h4 className="font-bold text-red-700 mb-2">Weaknesses</h4>
          <ul className="list-disc pl-5 text-gray-600 text-sm space-y-1">
            {match.weaknesses.map((w) => <li key={w}>{w}</li>)}
          </ul>
        </div>
      </div>

      {/* Improvement Suggestions */}
      <div className="mb-2">
        <h4 className="font-bold text-gray-800 mb-2">Improvement Suggestions</h4>
        <ul className="list-disc pl-5 text-gray-600 text-sm space-y-1">
          {match.improvement_suggestions.map((s) => <li key={s}>{s}</li>)}
        </ul>
      </div>

      {bundle && bundle.skill_recommendations.length > 0 ? (
        <>
          <CourseRecommendations skillRecommendations={bundle.skill_recommendations} />
          <LearningRoadmap roadmap={bundle.roadmap} />
        </>
      ) : (
        <p className="text-sm text-gray-500 border-t pt-4 mt-4">
          No missing skills detected for this role — no courses needed!
        </p>
      )}
    </div>
  );
}

export default JobMatchCard;
