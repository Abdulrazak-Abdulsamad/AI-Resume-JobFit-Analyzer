const VARIANT_CLASSES = {
  blue: 'bg-blue-50 text-blue-700',
  green: 'bg-green-50 text-green-700',
  red: 'bg-red-50 text-red-700',
  gray: 'bg-gray-100 text-gray-700',
};

/**
 * Renders a list of skill strings as rounded chips. Used for extracted
 * resume skills, matching skills, and missing skills alike, so the chip
 * markup only exists in one place.
 */
function SkillChips({ skills, variant = 'blue', emptyLabel = 'None' }) {
  if (!skills || skills.length === 0) {
    return <p className="text-sm text-gray-500">{emptyLabel}</p>;
  }

  const colorClasses = VARIANT_CLASSES[variant] ?? VARIANT_CLASSES.blue;

  return (
    <div className="flex flex-wrap gap-2">
      {skills.map((skill) => (
        <span
          key={skill}
          className={`px-3 py-1 rounded-full text-sm font-medium ${colorClasses}`}
        >
          {skill}
        </span>
      ))}
    </div>
  );
}

export default SkillChips;
