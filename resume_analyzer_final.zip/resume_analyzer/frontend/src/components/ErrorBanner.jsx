/**
 * ErrorBanner.jsx
 *
 * A visible, dismissible error message. Replaces the old `alert(...)` call
 * so failures show up inline in the page instead of a blocking browser
 * dialog.
 */
function ErrorBanner({ message, onDismiss }) {
  if (!message) return null;

  return (
    <div className="mb-8 flex items-start justify-between gap-4 rounded-xl border border-red-200 bg-red-50 p-4 text-red-800">
      <p className="text-sm">{message}</p>
      <button
        onClick={onDismiss}
        className="text-red-600 hover:text-red-800 text-sm font-bold leading-none"
        aria-label="Dismiss error"
      >
        ✕
      </button>
    </div>
  );
}

export default ErrorBanner;
