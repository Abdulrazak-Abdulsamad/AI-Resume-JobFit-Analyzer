import SkillChips from './SkillChips';

/**
 * CandidateSummary.jsx
 *
 * Renders the parsed resume's candidate details and extracted skills -
 * output of the Resume Parsing stage.
 */
function CandidateSummary({ resume }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Candidate Details</h2>
        <ul className="space-y-2 text-gray-600">
          <li><strong className="text-gray-900">Name:</strong> {resume.name || 'N/A'}</li>
          <li><strong className="text-gray-900">Email:</strong> {resume.email || 'N/A'}</li>
          <li><strong className="text-gray-900">Phone:</strong> {resume.phone || 'N/A'}</li>
          <li><strong className="text-gray-900">Experience:</strong> {resume.total_experience_years} year(s)</li>
        </ul>
      </div>
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Extracted Skills</h2>
        <SkillChips skills={resume.skills} variant="blue" emptyLabel="No skills detected" />
      </div>
    </div>
  );
}

export default CandidateSummary;
