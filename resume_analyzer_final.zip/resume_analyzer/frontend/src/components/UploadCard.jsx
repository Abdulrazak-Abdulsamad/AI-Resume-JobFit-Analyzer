/**
 * UploadCard.jsx
 *
 * The resume upload form. Purely presentational - it reports the chosen
 * file and submit action up to `App`, which owns all analysis state.
 */
function UploadCard({ file, onFileChange, onSubmit, isAnalyzing }) {
  return (
    <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 mb-8 text-center">
      <input
        type="file"
        accept=".pdf,.docx"
        onChange={(e) => onFileChange(e.target.files[0] ?? null)}
        className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 mb-4 cursor-pointer"
      />
      <button
        onClick={onSubmit}
        disabled={!file || isAnalyzing}
        className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 transition-colors w-full md:w-auto"
      >
        {isAnalyzing ? 'Analyzing Resume (please wait)...' : 'Analyze My Fit'}
      </button>
    </div>
  );
}

export default UploadCard;
