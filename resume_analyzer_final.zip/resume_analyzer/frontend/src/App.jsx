import { useState } from 'react';
import { analyzeResume } from './api/resumeApi';
import UploadCard from './components/UploadCard';
import ErrorBanner from './components/ErrorBanner';
import CandidateSummary from './components/CandidateSummary';
import JobMatchCard from './components/JobMatchCard';

function App() {
  const [file, setFile] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [report, setReport] = useState(null);
  const [error, setError] = useState(null);

  const handleFileChange = (selectedFile) => {
    setFile(selectedFile);
    setError(null);
  };

  const handleAnalyze = async () => {
    if (!file) return;
    setIsAnalyzing(true);
    setError(null);

    try {
      const data = await analyzeResume(file);
      setReport(data);
    } catch (err) {
      setError(err.message || 'Something went wrong while analyzing the resume.');
      setReport(null);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setFile(null);
    setReport(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8 font-sans">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <header className="mb-10 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">AI Resume Analyzer</h1>
          <p className="text-gray-600">
            Resume Parsing → RAG Job Retrieval → Job Analysis → Skill Gap Detection →
            Course Recommendations → Learning Roadmap
          </p>
        </header>

        <ErrorBanner message={error} onDismiss={() => setError(null)} />

        <UploadCard
          file={file}
          onFileChange={handleFileChange}
          onSubmit={handleAnalyze}
          isAnalyzing={isAnalyzing}
        />

        {/* Results Dashboard */}
        {report && report.parsed_resume && (
          <div className="space-y-8 animate-fade-in">
            <div className="flex justify-end">
              <button
                onClick={handleReset}
                className="text-sm text-gray-500 hover:text-gray-700 underline"
              >
                Analyze another resume
              </button>
            </div>

            <CandidateSummary resume={report.parsed_resume} />

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Job Matches</h2>
              {report.job_matches && report.job_matches.length > 0 ? (
                report.job_matches.map((match) => (
                  <JobMatchCard key={match.job_id} match={match} />
                ))
              ) : (
                <p className="text-gray-500">No matching jobs were retrieved.</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
