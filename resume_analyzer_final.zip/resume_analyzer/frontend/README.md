# AI Resume Analyzer — Frontend

A React + Vite + Tailwind single-page app that replaces the project's old
Streamlit UI. It talks to the FastAPI backend (`../api.py`) over HTTP and
renders the exact same pipeline output the backend has always produced:

```
Upload resume -> Resume Parsing -> RAG Job Retrieval -> Job Analysis
-> Skill Gap Detection -> Course Recommendations -> Learning Roadmap
```

## Structure

```
frontend/
├── src/
│   ├── api/
│   │   └── resumeApi.js         # The ONLY module that calls the backend
│   ├── components/
│   │   ├── UploadCard.jsx       # Resume file picker + submit button
│   │   ├── ErrorBanner.jsx      # Inline error display (no alert() popups)
│   │   ├── CandidateSummary.jsx # Parsed resume details + extracted skills
│   │   ├── SkillChips.jsx       # Shared chip renderer (extracted/matching/missing)
│   │   ├── JobMatchCard.jsx     # One ranked job match: metrics, insights, skills
│   │   ├── CourseRecommendations.jsx  # Per-skill course list
│   │   └── LearningRoadmap.jsx  # Beginner -> Advanced roadmap phases
│   ├── App.jsx                  # Orchestrates state; no direct fetch calls
│   ├── main.jsx
│   └── index.css
└── .env.example                 # VITE_API_BASE_URL override
```

Each component has one job (mirroring the backend's own module boundaries),
and all HTTP calls go through `src/api/resumeApi.js` so there is exactly one
place that knows the backend's base URL and routes.

## Setup

```bash
cd frontend
npm install
cp .env.example .env   # optional - defaults to http://localhost:8000
npm run dev
```

The dev server starts on **http://localhost:5173** by default. Make sure the
backend is running first (see `../README.md`) — the API's CORS settings
already allow `http://localhost:5173` and `http://127.0.0.1:5173` out of the
box.

## Build for production

```bash
npm run build
```

Outputs static assets to `dist/`, which can be served by any static file
host / reverse proxy. Set `VITE_API_BASE_URL` at build time to point at
wherever the FastAPI backend is deployed.
