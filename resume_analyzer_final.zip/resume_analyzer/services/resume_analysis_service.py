"""
resume_analysis_service.py

The single Facade the UI (and any future API layer) should call. It wires
together the three pipeline stages exactly once per process and exposes one
method: give it a resume file path, get back the parsed resume plus its
ranked job analyses.

    Resume Parsing -> RAG retrieval -> Job Analysis

All expensive resources (embedding model, vector store, job repository) are
constructed once here and reused across every call, satisfying the
"load once, cache" performance requirement.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import List

from job_analyzer.engine import JobAnalyzer
from job_analyzer.schemas import JobAnalysisResult
from rag.retriever import JobRetriever
from rag.vector_store import VectorStoreManager
from resume_parsing.pipeline import ResumeParsingPipeline
from resume_parsing.schema import ParsedResume
from services.embedding_service import get_embedding_service
from utils.logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class ResumeAnalysisReport:
    parsed_resume: ParsedResume
    job_matches: List[JobAnalysisResult]

    @property
    def best_match(self) -> JobAnalysisResult | None:
        return self.job_matches[0] if self.job_matches else None


class ResumeAnalysisService:
    """Facade tying Resume Parsing -> RAG -> Job Analyzer together."""

    def __init__(self) -> None:
        embedding_service = get_embedding_service()

        self.parsing_pipeline = ResumeParsingPipeline()
        self.vector_store = VectorStoreManager(embedding_service=embedding_service)
        self.retriever = JobRetriever(self.vector_store, embedding_service=embedding_service)
        self.job_analyzer = JobAnalyzer(self.retriever)

    def analyze_resume_file(self, file_path: str, top_k: int | None = None) -> ResumeAnalysisReport:
        logger.info("Running full analysis pipeline for: %s", file_path)
        parsed_resume = self.parsing_pipeline.run(file_path)
        job_matches = self.job_analyzer.analyze(parsed_resume, top_k=top_k)
        return ResumeAnalysisReport(parsed_resume=parsed_resume, job_matches=job_matches)


@lru_cache(maxsize=1)
def get_resume_analysis_service() -> ResumeAnalysisService:
    """
    Process-wide singleton. Constructing `ResumeAnalysisService` loads the
    embedding model and vector store, so this must only happen once.
    """
    return ResumeAnalysisService()
