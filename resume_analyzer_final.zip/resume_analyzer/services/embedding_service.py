"""
embedding_service.py

Single shared embedding model for the entire application.

The original three projects each instantiated their own
`SentenceTransformer("all-MiniLM-L6-v2")`:
  - RESUME PARSER/skill_extractor.py
  - JOB ANALYZER/feature_extraction.py
  - RAG_MODULE/embedder.py

That meant the (multi-hundred-MB) model was loaded into memory up to three
times per process. `EmbeddingService` is a process-wide singleton that loads
the model exactly once and is injected into every module that needs
embeddings (resume parsing, RAG, job analyzer), satisfying the
"load once, cache" performance requirement.
"""
from __future__ import annotations

from functools import lru_cache
from typing import List, Sequence

import numpy as np

from config import settings
from utils.logging_config import get_logger

logger = get_logger(__name__)


class EmbeddingService:
    """Thin, cached wrapper around a SentenceTransformer model."""

    def __init__(self, model_name: str | None = None) -> None:
        self.model_name = model_name or settings.embedding.model_name
        logger.info("Loading embedding model '%s' (once per process)...", self.model_name)
        # Imported lazily so environments that only need non-embedding parts
        # of the codebase (e.g. simple unit tests) don't pay the import cost.
        from sentence_transformers import SentenceTransformer

        self._model = SentenceTransformer(self.model_name)
        logger.info("Embedding model '%s' loaded.", self.model_name)

    def encode(self, text: str) -> List[float]:
        """Encode a single string into a dense vector (list of floats)."""
        cleaned = (text or "").strip() or "empty document"
        vector = self._model.encode(cleaned, convert_to_numpy=True)
        return vector.tolist()

    def encode_many(self, texts: Sequence[str]) -> List[List[float]]:
        """Encode a batch of strings in a single forward pass (more efficient
        than calling `encode` in a loop)."""
        cleaned = [(t or "").strip() or "empty document" for t in texts]
        vectors: np.ndarray = self._model.encode(cleaned, convert_to_numpy=True)
        return vectors.tolist()


@lru_cache(maxsize=1)
def get_embedding_service() -> EmbeddingService:
    """
    Return the process-wide singleton EmbeddingService instance.

    `lru_cache(maxsize=1)` guarantees the (expensive) model load happens at
    most once per process, regardless of how many modules call this.
    """
    return EmbeddingService()
