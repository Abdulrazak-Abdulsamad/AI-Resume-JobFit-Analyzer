"""
api.py

The FastAPI presentation layer for the AI Resume Analyzer. This is the ONLY
thing that changed to support the new React frontend - every backend stage
(Resume Parsing -> RAG retrieval -> Job Analysis -> Skill Gap Detection ->
Course Recommendations -> Learning Roadmap) is untouched and reached through
the exact same `ResumeAnalysisService` facade the old Streamlit `app.py`
used and the CLI (`main.py`) still uses.

Run with:

    uvicorn api:app --reload --host 0.0.0.0 --port 8000

or simply `python api.py` for a quick start without the reload flag.
"""
from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.encoders import jsonable_encoder
from fastapi.middleware.cors import CORSMiddleware

from config import settings
from services.resume_analysis_service import get_resume_analysis_service
from utils.file_utils import save_uploaded_file
from utils.logging_config import get_logger

logger = get_logger(__name__)

# Extensions the resume_parsing.text_extractor module knows how to read.
_ALLOWED_EXTENSIONS = {".pdf", ".docx"}

app = FastAPI(
    title="AI Resume Analyzer API",
    description=(
        "Resume Parsing -> RAG Job Retrieval -> Job Analysis -> "
        "Skill Gap Detection -> Course Recommendations -> Learning Roadmap"
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.api.cors_origins),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health_check() -> dict:
    """Lightweight readiness probe for the frontend / load balancers."""
    return {"status": "ok"}


@app.post("/api/analyze")
async def analyze_resume(file: UploadFile = File(...)) -> dict:
    """
    Accept a resume file (.pdf or .docx) and run it through the full
    pipeline, returning the parsed resume plus every ranked job match
    (similarity, skill gap, ATS score, insights, course recommendations,
    and learning roadmap) as JSON.
    """
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in _ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{suffix or 'unknown'}'. Upload a .pdf or .docx resume.",
        )

    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    tmp_path = save_uploaded_file(contents, file.filename)
    try:
        service = get_resume_analysis_service()
        report = service.analyze_resume_file(str(tmp_path))
        return jsonable_encoder(report)
    except ValueError as exc:
        # Raised by the resume parsing layer for unreadable/corrupt files.
        logger.warning("Rejected resume '%s': %s", file.filename, exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        logger.error("Pipeline execution failed for '%s': %s", file.filename, exc)
        raise HTTPException(status_code=500, detail="Failed to analyze resume.") from exc
    finally:
        tmp_path.unlink(missing_ok=True)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("api:app", host=settings.api.host, port=settings.api.port, reload=True)
