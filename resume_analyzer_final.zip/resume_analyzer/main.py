"""
main.py

Command-line entry point. Run the full pipeline against a resume file:

    python main.py path/to/resume.pdf

Prints the parsed resume and ranked job matches as JSON.
"""
from __future__ import annotations

import argparse
import json
import sys

from services.resume_analysis_service import get_resume_analysis_service
from utils.logging_config import get_logger

logger = get_logger(__name__)


def main() -> None:
    parser = argparse.ArgumentParser(description="AI Resume Analyzer (Resume Parsing -> RAG -> Job Analysis)")
    parser.add_argument("resume_path", help="Path to a .pdf or .docx resume file")
    parser.add_argument("--top-k", type=int, default=None, help="Number of jobs to retrieve/rank")
    args = parser.parse_args()

    service = get_resume_analysis_service()

    try:
        report = service.analyze_resume_file(args.resume_path, top_k=args.top_k)
    except Exception as exc:  # noqa: BLE001
        logger.error("Pipeline execution failed: %s", exc)
        sys.exit(1)

    output = {
        "parsed_resume": report.parsed_resume.model_dump(),
        "job_matches": [match.model_dump() for match in report.job_matches],
    }
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
