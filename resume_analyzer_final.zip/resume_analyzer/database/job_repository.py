"""
job_repository.py

Centralized access to the job database (`data/job_db.json`).

This is the ONE place in the codebase that reads job data from disk. The RAG
module ingests jobs through this repository (instead of reading the file
itself), and nothing else in the application is allowed to read job_db.json
directly. This guarantees a single source of truth and makes it trivial to
swap the backing store later (e.g. for a real database) without touching
the RAG or Job Analyzer modules.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List

from config import settings
from utils.logging_config import get_logger

logger = get_logger(__name__)


class JobRecord(Dict[str, Any]):
    """
    A job record, structurally shaped like:
        {
            "job_id": str,
            "title": str,
            "required_skills": List[str],
            "minimum_work_experience_years": int,
        }
    Kept as a plain dict subclass (rather than a heavier model) since it is
    passed straight through to the vector store / retriever layers.
    """


class JobRepository:
    """Loads and serves job records from the single JSON source of truth."""

    def __init__(self, db_path: Path | None = None) -> None:
        self.db_path = db_path or settings.job_db_path
        self._jobs: List[JobRecord] = self._load()

    def _load(self) -> List[JobRecord]:
        if not self.db_path.exists():
            raise FileNotFoundError(f"Job database not found at: {self.db_path}")

        with self.db_path.open("r", encoding="utf-8") as fh:
            raw_jobs = json.load(fh)

        jobs: List[JobRecord] = []
        for index, job in enumerate(raw_jobs, start=1):
            record = JobRecord(job)
            record.setdefault("job_id", f"job_{index}")
            record.setdefault("required_skills", [])
            record.setdefault("minimum_work_experience_years", 0)
            jobs.append(record)

        logger.info("Loaded %d job records from %s", len(jobs), self.db_path)
        return jobs

    def all_jobs(self) -> List[JobRecord]:
        """Return every job record."""
        return list(self._jobs)

    def get_by_id(self, job_id: str) -> JobRecord | None:
        for job in self._jobs:
            if job["job_id"] == job_id:
                return job
        return None

    def get_by_title(self, title: str) -> JobRecord | None:
        for job in self._jobs:
            if job["title"].lower() == title.lower():
                return job
        return None


@lru_cache(maxsize=1)
def get_job_repository() -> JobRepository:
    """Process-wide singleton so job_db.json is parsed from disk exactly once."""
    return JobRepository()
