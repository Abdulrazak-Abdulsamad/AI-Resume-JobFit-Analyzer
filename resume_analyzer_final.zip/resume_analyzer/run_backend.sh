#!/usr/bin/env bash
# Starts the FastAPI backend (api.py) with auto-reload for development.
# Run from anywhere; this script cd's into the project root itself.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
uvicorn api:app --reload --host "${RESUME_ANALYZER_API_HOST:-0.0.0.0}" --port "${RESUME_ANALYZER_API_PORT:-8000}"
