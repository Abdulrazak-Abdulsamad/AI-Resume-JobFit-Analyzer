"""
education_experience_extractor.py

Extracts structured education and work-experience entries from the
"education" and "experience" resume sections produced by
`preprocessor.split_into_sections`.
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional

from resume_parsing.nlp_model import get_nlp

_IGNORE_EDUCATION_KEYWORDS = {
    "linux", "python", "bash", "r", "java", "javascript", "html", "css", "sql",
    "self-directed learning", "administration", "programming", "data analysis",
}

_DEGREE_KEYWORDS = [
    r"bachelor", r"master", r"b\.s\.", r"m\.s\.", r"phd", r"degree", r"diploma",
    r"b\.sc", r"m\.sc", r"university", r"college", r"institute",
]

_EDUCATION_FALLBACK_KEYWORDS = [
    "university", "bachelor", "master", "bsc", "msc", "degree", "graduated",
    "learning", "self-directed",
]

_ACTION_VERBS = (
    "built", "developed", "collaborated", "created", "managed", "utilizing",
    "analyzed", "designed", "implemented", "led", "worked", "integrated",
    "assisted", "trained",
)

_DATE_RANGE_HEADER_PATTERN = re.compile(
    r"\b(19|20)\d{2}\s*[-\u2013]\s*(Present|\b(19|20)\d{2})\b", re.IGNORECASE
)


def extract_education(education_text: str) -> List[Dict[str, Optional[str]]]:
    """Extract structured education entries, filtering out standalone skills."""
    if not education_text.strip():
        return []

    nlp = get_nlp()
    entries: List[Dict[str, Optional[str]]] = []

    for line in education_text.split("\n"):
        line_clean = line.strip()
        if not line_clean:
            continue
        if any(ignored in line_clean.lower() for ignored in _IGNORE_EDUCATION_KEYWORDS):
            continue

        line_doc = nlp(line_clean)
        has_degree = any(re.search(kw, line_clean, re.IGNORECASE) for kw in _DEGREE_KEYWORDS)

        institution, dates = None, None
        for ent in line_doc.ents:
            if ent.label_ == "ORG" and not institution:
                institution = ent.text
            elif ent.label_ == "DATE" and not dates:
                dates = ent.text

        if institution or has_degree:
            entries.append({
                "institution": institution or line_clean,
                "degree": line_clean if has_degree else "Coursework / Qualification",
                "dates": dates,
            })

    return entries


def extract_education_with_fallback(education_text: str, full_cleaned_text: str) -> List[Dict[str, Optional[str]]]:
    """
    `extract_education`, with a line-scanning fallback over the full resume
    text for resumes where education wasn't cleanly segmented into its own
    section (e.g. a single "Education: X University, 2021" line embedded
    elsewhere).
    """
    education_data = extract_education(education_text)
    if education_data:
        return education_data

    lines = full_cleaned_text.split("\n")
    for i, line in enumerate(lines):
        if not any(keyword in line.lower() for keyword in _EDUCATION_FALLBACK_KEYWORDS):
            continue

        next_line = lines[i + 1] if i + 1 < len(lines) else ""
        combined_snippet = f"{line} {next_line}"
        has_year = any(str(year) in combined_snippet for year in range(2000, 2031))
        is_ongoing = "present" in combined_snippet.lower()

        if has_year or is_ongoing:
            education_data.append({"institution": line.strip(), "degree": None, "dates": None})
            break

    return education_data


def extract_experience(experience_text: str) -> List[Dict[str, Optional[str]]]:
    """
    Group project/role titles and their multi-line bullet descriptions into
    unified experience entries.
    """
    if not experience_text.strip():
        return []

    entries: List[Dict[str, Optional[str]]] = []
    lines = [l.strip() for l in experience_text.split("\n") if l.strip()]

    current_title: Optional[str] = None
    current_desc_parts: List[str] = []

    def _flush() -> None:
        if current_title:
            entries.append({
                "company": current_title,
                "role": " ".join(current_desc_parts) if current_desc_parts else current_title,
                "dates": None,
            })

    for line in lines:
        lower_line = line.lower()
        is_docx_header = "|" in line or bool(_DATE_RANGE_HEADER_PATTERN.search(line))
        is_bullet = line.startswith(("-", "\u2022", "*"))
        starts_with_action = any(lower_line.startswith(verb) for verb in _ACTION_VERBS)
        starts_with_lowercase = line[0].islower() if line else False
        is_long_sentence = len(line.split()) > 10

        if is_docx_header:
            is_continuation = False
        else:
            is_continuation = is_bullet or starts_with_action or starts_with_lowercase or is_long_sentence

        if not is_continuation:
            _flush()
            current_desc_parts = []
            current_title = line
        else:
            if not current_title:
                current_title = "Project / Experience"
            current_desc_parts.append(line)

    _flush()
    return entries
