"""
text_extractor.py

Extraction-only responsibility: turns a resume file on disk (.pdf or .docx)
into a raw, continuous text string. Nothing in this module cleans,
segments, or interprets the text - that belongs to `preprocessor.py` and the
various extractor modules.

Adds an OCR fallback (via PyMuPDF page rasterization + pytesseract) for
scanned/image-only PDFs that yield no extractable text layer, fulfilling the
"PDF/DOCX/OCR" scope for this module.
"""
from __future__ import annotations

import os

import docx
import fitz  # PyMuPDF

from utils.logging_config import get_logger

logger = get_logger(__name__)

# A PDF page is treated as "image-only" (and routed to OCR) if fewer than
# this many non-whitespace characters were extracted natively.
_MIN_NATIVE_CHARS_PER_PAGE = 20


def _extract_text_from_pdf(file_path: str) -> str:
    """Extract text from a PDF, falling back to OCR for scanned pages."""
    text_parts: list[str] = []
    try:
        with fitz.open(file_path) as doc:
            for page in doc:
                page_text = page.get_text()
                if len(page_text.strip()) < _MIN_NATIVE_CHARS_PER_PAGE:
                    page_text = _ocr_page(page)
                text_parts.append(page_text)
    except Exception as exc:  # noqa: BLE001 - surfaced to caller as an error
        raise ValueError(f"Failed to read PDF '{file_path}': {exc}") from exc

    return "\n".join(text_parts)


def _ocr_page(page: "fitz.Page") -> str:
    """Rasterize a single PDF page and run OCR on it as a fallback."""
    try:
        import pytesseract
        from PIL import Image
        import io

        pix = page.get_pixmap(dpi=300)
        image = Image.open(io.BytesIO(pix.tobytes("png")))
        return pytesseract.image_to_string(image)
    except Exception as exc:  # noqa: BLE001
        logger.warning("OCR fallback failed for a page: %s", exc)
        return ""


def _extract_text_from_docx(file_path: str) -> str:
    """Extract text from a Word (.docx) document."""
    try:
        document = docx.Document(file_path)
        return "\n".join(p.text for p in document.paragraphs if p.text.strip())
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"Failed to read DOCX '{file_path}': {exc}") from exc


def extract_text(file_path: str) -> str:
    """
    Detect the file format from its extension and route to the appropriate
    extractor. Raises ValueError for unsupported formats.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        return _extract_text_from_pdf(file_path)
    if ext in (".docx", ".doc"):
        return _extract_text_from_docx(file_path)

    raise ValueError(f"Unsupported file format: '{ext}'. Please use PDF or DOCX.")
