"""
pipeline.py

Orchestrates the Resume Parsing module end-to-end:

    file (PDF/DOCX) -> raw text -> cleaned text -> sections
        -> contact/name/education/experience/skills -> ParsedResume

This is the only public entry point other modules (the analysis service,
the UI) should call into the Resume Parsing package.
"""
from __future__ import annotations

from resume_parsing.contact_extractor import extract_contact_info, extract_name
from resume_parsing.education_experience_extractor import (
    extract_education_with_fallback,
    extract_experience,
)
from resume_parsing.experience_duration import extract_total_experience
from resume_parsing.preprocessor import clean_text, split_into_sections
from resume_parsing.schema import ParsedResume
from resume_parsing.skill_extractor import SkillExtractor
from resume_parsing.text_extractor import extract_text
from utils.logging_config import get_logger

logger = get_logger(__name__)


class ResumeParsingPipeline:
    """Stateful pipeline that reuses a single SkillExtractor (and therefore a
    single embedding model load) across many resumes."""

    def __init__(self, skill_extractor: SkillExtractor | None = None) -> None:
        self.skill_extractor = skill_extractor or SkillExtractor()

    def run(self, file_path: str) -> ParsedResume:
        logger.info("Parsing resume: %s", file_path)

        raw_text = extract_text(file_path)
        cleaned_text = clean_text(raw_text)
        sections = split_into_sections(cleaned_text)

        contacts = extract_contact_info(cleaned_text)
        candidate_name = extract_name(cleaned_text)
        education_data = extract_education_with_fallback(sections["education"], cleaned_text)
        experience_data = extract_experience(sections["experience"])
        skills = self.skill_extractor.extract_skills(sections["skills"] or cleaned_text)
        total_years_experience = extract_total_experience(cleaned_text, experience_data)

        return ParsedResume(
            name=candidate_name,
            email=contacts.get("email"),
            phone=contacts.get("phone"),
            total_experience_years=total_years_experience,
            education=education_data,
            experience=experience_data,
            skills=skills,
        )


def run_parser_pipeline(file_path: str) -> str:
    """Convenience function mirroring the original API: parse a resume file
    and return the result as a JSON string."""
    pipeline = ResumeParsingPipeline()
    return pipeline.run(file_path).model_dump_json(indent=2)
