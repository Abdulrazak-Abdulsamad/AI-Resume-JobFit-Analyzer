"""
contact_extractor.py

Regex + spaCy based extraction of a candidate's name, email, and phone
number from resume text.
"""
from __future__ import annotations

import re
from typing import Dict, Optional

from resume_parsing.nlp_model import get_nlp

_EMAIL_PATTERN = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
_PHONE_PATTERN = r"\(?\+?\d{1,4}\)?[\s.-]?\(?\d{1,3}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,4}"
_TITLE_PREFIX_PATTERN = r"(?i)^(CV|Resume|Curriculum Vitae)[\s:-]*"


def extract_contact_info(text: str) -> Dict[str, Optional[str]]:
    """Extract an email address and phone number using regex."""
    email_match = re.search(_EMAIL_PATTERN, text)
    phone_match = re.search(_PHONE_PATTERN, text)
    return {
        "email": email_match.group(0) if email_match else None,
        "phone": phone_match.group(0) if phone_match else None,
    }


def extract_name(text: str) -> str:
    """Extract the candidate's name from the top of the resume."""
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    first_few_lines = "\n".join(lines[:5])
    cleaned_text = re.sub(_TITLE_PREFIX_PATTERN, "", first_few_lines)

    nlp = get_nlp()
    doc = nlp(cleaned_text)
    for ent in doc.ents:
        if ent.label_ == "PERSON" and 2 <= len(ent.text.split()) <= 3:
            return ent.text.strip()

    fallback_name = lines[0] if lines else "Unknown Candidate"
    return re.sub(_TITLE_PREFIX_PATTERN, "", fallback_name).strip()
