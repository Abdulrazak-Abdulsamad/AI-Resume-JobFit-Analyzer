"""
nlp_model.py

Loads the spaCy NLP model exactly once and shares it between
`contact_extractor.py` and `education_experience_extractor.py`, instead of
each module loading (and potentially auto-downloading) its own copy.
"""
from __future__ import annotations

from functools import lru_cache

from utils.logging_config import get_logger

logger = get_logger(__name__)

_MODEL_NAME = "en_core_web_sm"


@lru_cache(maxsize=1)
def get_nlp():
    """Return the process-wide singleton spaCy pipeline."""
    import spacy

    try:
        return spacy.load(_MODEL_NAME)
    except OSError:
        logger.info("spaCy model '%s' not found locally, downloading...", _MODEL_NAME)
        import spacy.cli

        spacy.cli.download(_MODEL_NAME)
        return spacy.load(_MODEL_NAME)
