"""
experience_duration.py

Computes a candidate's total years of professional experience by summing
the duration of each detected employment date range.

The original `ner.py` accidentally defined `parse_date` four separate times
(a copy-paste artifact); this module keeps a single, tested definition.
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import Dict, List, Optional

_DATE_RANGE_PATTERN = re.compile(
    r"([a-zA-Z]+\s\d{4}|\d{4})\s*[-\u2013to]+\s*([a-zA-Z]+\s\d{4}|\d{4}|present|current|now)",
    re.IGNORECASE,
)

_ONGOING_TOKENS = {"present", "current", "now"}


def parse_date(date_str: str) -> Optional[datetime]:
    """Parse a loosely-formatted date string ('June 2023', '2021', 'Present')."""
    normalized = date_str.strip().lower()

    if normalized in _ONGOING_TOKENS:
        return datetime.now()

    for fmt in ("%B %Y", "%b %Y", "%Y"):
        try:
            return datetime.strptime(normalized, fmt)
        except ValueError:
            continue

    return None


def extract_total_experience(full_text: str, experience_entries: List[Dict[str, Optional[str]]]) -> int:
    """
    Calculate total years of experience by summing the exact duration (in
    months, then rounded to years) of every detected date range across the
    parsed experience entries.
    """
    exp_text_block = " ".join(
        f"{entry.get('company', '')} {entry.get('role', '')} {entry.get('dates', '')}"
        for entry in experience_entries
    )
    # Also scan the raw text in case dates live outside the segmented entries.
    combined_text = f"{exp_text_block} {full_text}"

    total_months = 0
    seen_ranges = set()
    for start_str, end_str in _DATE_RANGE_PATTERN.findall(combined_text):
        range_key = (start_str.lower(), end_str.lower())
        if range_key in seen_ranges:
            continue
        seen_ranges.add(range_key)

        start_date = parse_date(start_str)
        end_date = parse_date(end_str)

        if start_date and end_date and end_date >= start_date:
            months_worked = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_months += months_worked

    return round(total_months / 12) if total_months > 0 else 0
