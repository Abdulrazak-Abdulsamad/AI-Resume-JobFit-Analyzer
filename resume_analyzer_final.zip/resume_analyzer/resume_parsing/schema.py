"""
schema.py

Pydantic models describing the structured output of the Resume Parsing
module. This is the contract every downstream module (RAG, Job Analyzer,
UI) relies on.
"""
from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class EducationEntry(BaseModel):
    institution: Optional[str] = None
    degree: Optional[str] = None
    dates: Optional[str] = None


class ExperienceEntry(BaseModel):
    company: Optional[str] = None
    role: Optional[str] = None
    dates: Optional[str] = None


class ParsedResume(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    total_experience_years: int = 0
    education: List[EducationEntry] = Field(default_factory=list)
    experience: List[ExperienceEntry] = Field(default_factory=list)
    skills: List[str] = Field(default_factory=list)
