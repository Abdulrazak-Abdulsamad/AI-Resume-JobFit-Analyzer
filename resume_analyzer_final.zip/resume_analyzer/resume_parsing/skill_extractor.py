"""
skill_extractor.py

Extracts skills mentioned in resume text using:
  1. Exact taxonomy lookup (fast, precise).
  2. Embedding-based fuzzy matching against the same taxonomy (catches
     synonyms/variants the exact match misses).

Uses the shared `EmbeddingService` (see services/embedding_service.py)
instead of loading its own SentenceTransformer instance, and the shared
`SKILL_TAXONOMY` (see utils/skills_taxonomy.py) so the Job Analyzer matches
skills against the exact same vocabulary the parser extracts.
"""
from __future__ import annotations

from typing import List

import numpy as np

from config import settings
from services.embedding_service import EmbeddingService, get_embedding_service
from utils.skills_taxonomy import SKILL_TAXONOMY
import re


class SkillExtractor:
    def __init__(self, embedding_service: EmbeddingService | None = None) -> None:
        self.embedding_service = embedding_service or get_embedding_service()
        self._taxonomy_embeddings = np.array(
            self.embedding_service.encode_many(SKILL_TAXONOMY)
        )

    def extract_skills(self, text: str, similarity_threshold: float | None = None) -> List[str]:
        threshold = similarity_threshold or settings.skill_extraction.similarity_threshold
        text_lower = text.lower()
        found_skills: set[str] = set()

        # 1. Exact taxonomy lookup.
        for skill in SKILL_TAXONOMY:
            pattern = r"\b" + re.escape(skill.lower()) + r"\b"
            if re.search(pattern, text_lower):
                found_skills.add(skill)

        # 2. Embedding-based fuzzy matching for anything the exact pass missed.
        words = list({w.strip(",.()") for w in text_lower.split() if len(w) > 2})
        if words:
            word_embeddings = np.array(self.embedding_service.encode_many(words))
            similarity_matrix = _cosine_similarity(word_embeddings, self._taxonomy_embeddings)

            for idx, _word in enumerate(words):
                best_idx = int(np.argmax(similarity_matrix[idx]))
                best_score = float(similarity_matrix[idx][best_idx])
                if best_score >= threshold:
                    found_skills.add(SKILL_TAXONOMY[best_idx])

        return sorted(found_skills)


def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Lightweight cosine-similarity matrix, avoids pulling in sklearn here."""
    a_norm = a / (np.linalg.norm(a, axis=1, keepdims=True) + 1e-10)
    b_norm = b / (np.linalg.norm(b, axis=1, keepdims=True) + 1e-10)
    return a_norm @ b_norm.T
