"""
preprocessor.py

Normalizes raw extracted text and segments it into logical resume sections
(education / experience / skills / general). Purely text-level work - no
NLP models involved, so it stays fast and dependency-free.
"""
from __future__ import annotations

import re
from typing import Dict

_SECTION_PATTERNS: Dict[str, str] = {
    "education": r"(?i)\b(education|academic|qualification|coursework)\b",
    "experience": r"(?i)\b(experience|work history|projects|employment)\b",
    "skills": r"(?i)\b(skills|technical skills|technologies|competencies)\b",
}


def clean_text(text: str) -> str:
    """Normalize whitespace and bullet characters in raw extracted text."""
    text = re.sub(r"[\t\r\f\v]", " ", text)
    text = re.sub(r"[•●▪■–—]", "-", text)
    text = re.sub(r" +", " ", text)
    text = re.sub(r"\n\s*\n", "\n", text)
    return text.strip()


def split_into_sections(text: str) -> Dict[str, str]:
    """
    Segment cleaned resume text into named sections using flexible header
    matching. Any line under 5 words that matches a section keyword is
    treated as a header and switches the current section.
    """
    lines = text.split("\n")
    sections: Dict[str, list[str]] = {"general": [], "education": [], "experience": [], "skills": []}
    current_section = "general"

    for line in lines:
        line_str = line.strip()
        if not line_str:
            continue

        matched_header = False
        for section_name, pattern in _SECTION_PATTERNS.items():
            if re.search(pattern, line_str) and len(line_str.split()) < 5:
                current_section = section_name
                matched_header = True
                break

        if not matched_header:
            sections[current_section].append(line_str)

    return {name: "\n".join(lines_) for name, lines_ in sections.items()}
