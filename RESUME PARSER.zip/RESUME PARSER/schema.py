from pydantic import BaseModel, Field
from typing import List, Optional

class EducationEntry(BaseModel):
    institution: Optional[str] = None
    degree: Optional[str] = None
    dates: Optional[str] = None

class ExperienceEntry(BaseModel):
    company: Optional[str] = None
    role: Optional[str] = None
    dates: Optional[str] = None

class ParsedResume(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    education: List[EducationEntry] = Field(default_factory=list)
    experience: List[ExperienceEntry] = Field(default_factory=list)
    skills: List[str] = Field(default_factory=list)