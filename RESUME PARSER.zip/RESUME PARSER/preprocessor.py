import re

def clean_text(text: str) -> str:
    """Normalizes raw extracted text."""
    text = re.sub(r'[\t\r\f\v]', ' ', text)
    text = re.sub(r'[•●▪■–—]', '-', text)
    text = re.sub(r' +', ' ', text)
    text = re.sub(r'\n\s*\n', '\n', text)
    return text.strip()

def split_into_sections(text: str) -> dict:
    """Segments document text using header regex boundaries."""
    # Common standard section headers
    section_patterns = {
        'education': r'(?i)\b(education|academic background|qualification|coursework)\b',
        'experience': r'(?i)\b(experience|work history|projects|key projects|employment)\b',
        'skills': r'(?i)\b(skills|technical skills|technologies|core competencies)\b'
    }
    
    lines = text.split('\n')
    sections = {'general': [], 'education': [], 'experience': [], 'skills': []}
    current_section = 'general'
    
    for line in lines:
        line_str = line.strip()
        if not line_str:
            continue
            
        matched_header = False
        for sec_name, pattern in section_patterns.items():
            # Check if line acts as a header (short length and matches keyword)
            if re.search(pattern, line_str) and len(line_str.split()) <= 4:
                current_section = sec_name
                matched_header = True
                break
                
        if not matched_header:
            sections[current_section].append(line_str)
            
    return {k: "\n".join(v) for k, v in sections.items()}