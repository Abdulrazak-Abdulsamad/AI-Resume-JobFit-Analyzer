import re
import spacy

try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    import spacy.cli
    spacy.cli.download("en_core_web_sm")
    nlp = spacy.load("en_core_web_sm")

IGNORE_EDUCATION_KEYWORDS = {
    "linux", "python", "bash", "r", "java", "javascript", "html", "css", "sql", 
    "self-directed learning", "administration", "programming", "data analysis"
}

def extract_contact_info(text: str) -> dict:
    """Extracts email and phone numbers using Regex."""
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    phone_pattern = r'\(?\+?\d{1,4}\)?[\s.-]?\(?\d{1,3}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,4}'
    
    email_match = re.search(email_pattern, text)
    phone_match = re.search(phone_pattern, text)
    
    return {
        "email": email_match.group(0) if email_match else None,
        "phone": phone_match.group(0) if phone_match else None
    }

def extract_name(text: str) -> str:
    """Extracts candidate name, stripping out 'CV' or 'Resume' prefixes."""
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    first_few_lines = "\n".join(lines[:5])
    
    # Strip common prefixes so spaCy doesn't get confused
    cleaned_text = re.sub(r'(?i)^(CV|Resume|Curriculum Vitae)[\s:-]*', '', first_few_lines)
    
    doc = nlp(cleaned_text)
    
    for ent in doc.ents:
        if ent.label_ == "PERSON" and 2 <= len(ent.text.split()) <= 3:
            return ent.text.strip()
            
    # Fallback to the first line, ensuring 'CV:' is removed
    fallback_name = lines[0] if lines else "Unknown Candidate"
    return re.sub(r'(?i)^(CV|Resume|Curriculum Vitae)[\s:-]*', '', fallback_name).strip()

def extract_education(edu_text: str) -> list:
    """Extracts structured education entries, filtering out standalone skills."""
    if not edu_text.strip():
        return []
    
    entries = []
    degree_keywords = [r"bachelor", r"master", r"b\.s\.", r"m\.s\.", r"phd", r"degree", r"diploma", r"b\.sc", r"m\.sc", r"university", r"college", r"institute"]
    
    for line in edu_text.split('\n'):
        line_clean = line.strip()
        if not line_clean:
            continue
            
        if any(ignore_word in line_clean.lower() for ignore_word in IGNORE_EDUCATION_KEYWORDS):
            continue
            
        line_doc = nlp(line_clean)
        has_degree = any(re.search(kw, line_clean, re.IGNORECASE) for kw in degree_keywords)
        
        inst, dates = None, None
        for ent in line_doc.ents:
            if ent.label_ == "ORG" and not inst:
                inst = ent.text
            elif ent.label_ == "DATE" and not dates:
                dates = ent.text
                
        if inst or has_degree:
            entries.append({
                "institution": inst or line_clean,
                "degree": line_clean if has_degree else "Coursework / Qualification",
                "dates": dates
            })
            
    return entries

def extract_experience(exp_text: str) -> list:
    """Groups project titles and multi-line descriptions into unified objects, handling DOCX formats."""
    if not exp_text.strip():
        return []
        
    entries = []
    lines = [l.strip() for l in exp_text.split('\n') if l.strip()]
    
    current_title = None
    current_desc_parts = []
    
    # Action verbs commonly used to start resume bullets
    action_verbs = ('built', 'developed', 'collaborated', 'created', 'managed', 
                    'utilizing', 'analyzed', 'designed', 'implemented', 'led', 'worked', 'integrated', 'assisted', 'trained')
    
    for line in lines:
        lower_line = line.lower()
        
        # DOCX Check: If a line contains a pipe (|) or a date range (- Present), it is definitely a Header!
        is_docx_header = '|' in line or bool(re.search(r'\b(19|20)\d{2}\s*[-–]\s*(Present|\b(19|20)\d{2})\b', line, re.IGNORECASE))
        
        is_bullet = line.startswith(('-', '•', '*'))
        starts_with_action = any(lower_line.startswith(verb) for verb in action_verbs)
        starts_with_lowercase = line[0].islower() if line else False
        is_long_sentence = len(line.split()) > 10
        
        # If we know it's a DOCX header, explicitly force it NOT to be a continuation
        if is_docx_header:
            is_continuation = False
        else:
            is_continuation = is_bullet or starts_with_action or starts_with_lowercase or is_long_sentence
        
        if not is_continuation:
            # Save the previous project block before starting a new one
            if current_title:
                entries.append({
                    "company": current_title,
                    "role": " ".join(current_desc_parts) if current_desc_parts else current_title,
                    "dates": None
                })
                current_desc_parts = []
                
            current_title = line
        else:
            # Append continuous text to the description buffer
            if current_title:
                current_desc_parts.append(line)
            else:
                current_title = "Project / Experience"
                current_desc_parts.append(line)
                
    # Append the final block when the loop finishes
    if current_title:
        entries.append({
            "company": current_title,
            "role": " ".join(current_desc_parts) if current_desc_parts else current_title,
            "dates": None
        })
        
    return entries