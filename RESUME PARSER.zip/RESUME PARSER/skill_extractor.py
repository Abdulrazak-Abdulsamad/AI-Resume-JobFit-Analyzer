import re
import numpy as np
from sentence_transformers import SentenceTransformer, util

SKILL_TAXONOMY = [
    "python", "java", "c++", "sql", "javascript", "react", "fastapi", "docker", 
    "kubernetes", "aws", "azure", "gcp", "postgresql", "mongodb", "scikit-learn", 
    "pandas", "numpy", "spacy", "pytorch", "tensorflow", "git", "rest api", "linux",
    "bash", "r", "tableau", "power bi", "html", "css", "ci/cd", "machine learning"
]

class SkillExtractor:
    def __init__(self):
        # Local lightweight model
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.taxonomy_embeddings = self.model.encode(SKILL_TAXONOMY, convert_to_tensor=True)

    def extract_skills(self, text: str, similarity_threshold: float = 0.68) -> list:
        found_skills = set()
        text_lower = text.lower()
        
        # 1. Exact Taxonomy Lookup
        for skill in SKILL_TAXONOMY:
            pattern = r'\b' + re.escape(skill) + r'\b'
            if re.search(pattern, text_lower):
                found_skills.add(skill.title())

        # 2. Vector Embedding Similarity
        words = list(set([w.strip(',.()') for w in text_lower.split() if len(w) > 2]))
        if words:
            word_embeddings = self.model.encode(words, convert_to_tensor=True)
            cosine_scores = util.cos_sim(word_embeddings, self.taxonomy_embeddings)
            
            for idx, word in enumerate(words):
                max_score_idx = int(np.argmax(cosine_scores[idx].cpu()))
                max_score = float(cosine_scores[idx][max_score_idx])
                
                if max_score >= similarity_threshold:
                    found_skills.add(SKILL_TAXONOMY[max_score_idx].title())

        return sorted(list(found_skills))