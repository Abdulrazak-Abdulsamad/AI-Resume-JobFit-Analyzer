import streamlit as st
import tempfile
import json
from main import run_parser_pipeline

st.set_page_config(page_title="AI Resume Parser", layout="wide")

st.title("📄 AI-Powered Resume Parser Pipeline")
st.write("Upload a PDF or Word resume to extract structured data locally.")

uploaded_file = st.file_uploader("Choose a file (PDF or DOCX)", type=["pdf", "docx"])

if uploaded_file is not None:
    # Save uploaded file temporarily
    with tempfile.NamedTemporaryFile(delete=False, suffix=f".{uploaded_file.name.split('.')[-1]}") as tmp_file:
        tmp_file.write(uploaded_file.getvalue())
        tmp_path = tmp_file.name

    with st.spinner("Parsing resume..."):
        try:
            json_str = run_parser_pipeline(tmp_path)
            parsed_data = json.loads(json_str)

            col1, col2 = st.columns([1, 1])

            with col1:
                st.subheader("👤 Personal Details")
                st.write(f"**Name:** {parsed_data.get('name', 'N/A')}")
                st.write(f"**Email:** {parsed_data.get('email', 'N/A')}")
                st.write(f"**Phone:** {parsed_data.get('phone', 'N/A')}")

                st.subheader("🛠️ Extracted Skills")
                st.write(", ".join(parsed_data.get('skills', [])))

            with col2:
                st.subheader("📊 Raw JSON Output")
                st.json(parsed_data)

            st.success("Resume parsed successfully!")
        except Exception as e:
            st.error(f"Error processing document: {e}")