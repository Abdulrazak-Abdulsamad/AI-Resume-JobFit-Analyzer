import json
from extractor import extract_text
from preprocessor import clean_text, split_into_sections
from ner import extract_contact_info, extract_name, extract_education, extract_experience
from skill_extractor import SkillExtractor
from schema import ParsedResume

def run_parser_pipeline(file_path: str) -> str:
    print(f"[*] Processing File: {file_path}")
    
    # Step 1: Text extraction
    raw_text = extract_text(file_path)
    
    # Step 2: Cleaning & Segmentation
    cleaned_text = clean_text(raw_text)
    sections = split_into_sections(cleaned_text)
    
    # Step 3: Information Extraction
    contacts = extract_contact_info(cleaned_text)
    candidate_name = extract_name(cleaned_text)
    education_data = extract_education(sections['education'])
    experience_data = extract_experience(sections['experience'])
    
    # Step 4: Skill Extraction
    skill_engine = SkillExtractor()
    skills = skill_engine.extract_skills(sections['skills'] or cleaned_text)
    
    # Step 5: Pydantic Validation & JSON Output
    parsed_data = ParsedResume(
        name=candidate_name,
        email=contacts.get("email"),
        phone=contacts.get("phone"),
        education=education_data,
        experience=experience_data,
        skills=skills
    )
    
    return parsed_data.model_dump_json(indent=2)

if __name__ == "__main__":
    # Enter the docx/pdf file, ensuring the directory is correct
    sample_file = "/Users/cookie/Documents/SPYDA/RESUME PARSER/Sample_cv.docx" 
    try:
        json_output = run_parser_pipeline(sample_file)
        print("\n=== Parsed Resume Output (JSON) ===")
        print(json_output)
    except Exception as e:
        print(f"Pipeline Execution Error: {e}")